--drop table if exists dw_uat.dw_olea_pub_pub_email_template;
create table if not exists dw_uat.dw_olea_pub_pub_email_template
(`id`                                string               comment '                                                  '
,`type`                              string               comment '类型                                                '
,`name`                              string               comment '名称                                                '
,`title_template`                    string               comment '标题模板                                              '
,`content_template`                  string               comment '内容模板                                              '
,`parent_id`                         string               comment '父类模板id                                            '
,`replace_column`                    string               comment '父类替换字段                                            '
,`file_external_key`                 string               comment '模板文件                                              '
,`create_time`                       timestamp            comment '创建时间                                              '
,`create_by`                         string               comment '创建人                                               '
,`update_time`                       timestamp            comment '修改时间                                              '
,`update_by`                         string               comment '修改人                                               '
) comment '邮件模板'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_pub_email_template partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`type`                             
,`name`                             
,`title_template`                   
,`content_template`                 
,`parent_id`                        
,`replace_column`                   
,`file_external_key`                
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        

from ods.ods_olea_pub_pub_email_template;