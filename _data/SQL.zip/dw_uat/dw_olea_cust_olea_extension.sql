--alter table dw_uat.dw_olea_cust_olea_extension  		 change estimated_maturity_date   extended_maturity_date  	date comment'展期完成后的融资到期日';
--alter table dw_uat.dw_olea_cust_olea_extension  		 change estimated_maturity_date_lasted prev_extend_maturity_date date comment'最新的融资到期日（原始记录）/上一次展期完成后的发票到期日（展期纪录）';


--alter table dw_uat.dw_olea_cust_olea_extension add columns(disbursement_package_id  string comment'关联的disbursement package Id'); 
--alter table dw_uat.dw_olea_cust_olea_extension add columns(repayment_package_id  	  string comment'关联的repayment package Id');
--alter table dw_uat.dw_olea_cust_olea_extension add columns(extension_overdue_rate   string comment'extension逾期利息'); 
--alter table dw_uat.dw_olea_cust_olea_extension add columns(debit_status   string comment'记录该展期是否已经debit （YES/NO）'); 



create table if not exists dw_uat.dw_olea_cust_olea_extension
(  id                              string comment 'primary key id'
  ,financing_id                    string comment 'financing id'
  ,invoice_due_date                string comment 'The due date of the invoice filled in during the extension operation'
  ,invoice_due_date_final          string comment 'Invoice due date determined after rollover is complete'
  ,invoice_due_date_lasted         string comment 'Latest invoice due date (original record) / invoice due date after last extension (extension record)'
  ,past_buffer                     string comment 'whether beyond the investor`s default consent period'
  ,send_email                      string comment 'whether send email'
  ,investor_consent                string comment 'Investor Consent Status'
  ,estimated_maturity_date         string comment 'Financing Maturity Date After Rollover Completion'
  ,estimated_maturity_date_lasted  string comment 'Latest Financing Due Date (Original Record) / Invoice Due Date after Last Renewal Completed (Renewal Record)'
  ,extension_period                string comment 'extension period'
  ,extension_rate                  string comment 'extension_rate'
  ,extension_interest              string comment 'extension interest'
  ,extension_time                  string comment 'extension time'
  ,extension_status                string comment 'extension status,yes or no'
  ,repayment_status                string comment 'repayment status'
  ,record_type                     string comment 'original/extension/un_extension'
  ,operable                        string comment 'Whether the record can be extended YES/NO (the latest record can be operated)'
  ,media_busi_key                  string comment 'image busiKey'
  ,remark                          string comment ''
  ,create_by                       string comment 'creator id'
  ,create_by_name                  string comment 'creator name'
  ,create_time                     string comment 'create time'
  ,update_by                       string comment 'updator id'
  ,update_by_name                  string comment 'updator name'
  ,update_time                     string comment 'update time'
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_cust_olea_extension  change   invoice_due_date   invoice_due_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_extension  change   invoice_due_date_final   invoice_due_date_final  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_extension  change   invoice_due_date_lasted   invoice_due_date_lasted  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_extension  change   estimated_maturity_date   estimated_maturity_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_extension  change   estimated_maturity_date_lasted   estimated_maturity_date_lasted  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_extension  change   extension_time   extension_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_extension  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_extension  change   update_time   update_time  timestamp      comment'' ;
insert overwrite table dw_uat.dw_olea_cust_olea_extension partition(data_date='${hiveconf:DATA_DATE}')
select 
     id                             
    ,financing_id                   
    ,from_unixtime(cast(invoice_due_date/1000 as bigint),'yyyy-MM-dd')  as invoice_due_date               
    ,from_unixtime(cast(invoice_due_date_final/1000 as bigint),'yyyy-MM-dd') as invoice_due_date_final         
    ,from_unixtime(cast(invoice_due_date_lasted/1000 as bigint),'yyyy-MM-dd') as invoice_due_date_lasted        
    ,past_buffer                    
    ,send_email                     
    ,investor_consent               
    ,from_unixtime(cast(extended_maturity_date/1000 as bigint),'yyyy-MM-dd') as extended_maturity_date        
    ,from_unixtime(cast(prev_extend_maturity_date/1000 as bigint),'yyyy-MM-dd') as prev_extend_maturity_date 
    ,extension_period               
    ,extension_rate                 
    ,extension_interest             
    ,from_unixtime(cast(extension_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as  extension_time                 
    ,extension_status               
    ,repayment_status               
    ,record_type                    
    ,operable                       
    ,media_busi_key                 
    ,remark                         
    ,create_by                      
    ,create_by_name                 
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')    as create_time                    
    ,update_by                      
    ,from_unixtime(cast(update_by_name/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_by_name                 
    ,update_time                    
	  ,disbursement_package_id 
	  ,repayment_package_id  	
	  ,extension_overdue_rate 
	  ,debit_status
	  ,from_unixtime(cast(cooling_period_end_date/1000 as bigint),'yyyy-MM-dd') as cooling_period_end_date
 from ods.ods_olea_cust_olea_extension
 ;
