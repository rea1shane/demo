--drop table if exists dw_uat.dw_olea_cust_olea_model_version;
create table if not exists dw_uat.dw_olea_cust_olea_model_version
(`id`                                string               comment '                                                  '
,`model_id`                          string               comment '模型表id                                             '
,`version_no`                        string               comment '版本号                                               '
,`comment`                           string               comment '评论                                                '
,`valid_time`                        timestamp            comment '置有效时间                                             '
,`invalid_time`                      timestamp            comment '置无效时间                                             '
,`status`                            string               comment '状态 new/valid/invalid                              '
,`code_update_time`                  timestamp            comment '代码更新时间                                            '
,`update_user`                       string               comment '更新人                                               '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment '版本表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_model_version partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`model_id`                         
,`version_no`                       
,`comment`                          
,nvl(from_unixtime(cast(`valid_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`valid_time`) as valid_time
,nvl(from_unixtime(cast(`invalid_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`invalid_time`) as invalid_time
,`status`                           
,nvl(from_unixtime(cast(`code_update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`code_update_time`) as code_update_time
,`update_user`                      
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,version_url
from ods.ods_olea_cust_olea_model_version
;