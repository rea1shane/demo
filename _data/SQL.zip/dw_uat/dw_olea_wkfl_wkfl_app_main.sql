--drop table if exists dw_uat.dw_olea_wkfl_wkfl_app_main;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_app_main
(`app_no`                            string               comment '申请件编号                                             '
,`channel`                           string               comment '渠道号 1.PC 2.MOB                                    '
,`app_type`                          string               comment '流程类型                                              '
,`business_id`                       string               comment '关键业务id (与流程类型相关)                                  '
,`audit_state`                       string               comment '当前审批状态                                            '
,`proc_def_id`                       string               comment '流程实例定义编号                                          '
,`proc_inst_id`                      string               comment '流程实例号                                             '
,`status`                            string               comment '流程状态                                              '
,`pre_task_def_key`                  string               comment '前一次流程节点定义                                         '
,`pre_task_def_name`                 string               comment '前一次流程节点名称                                         '
,`pre_user_id`                       string               comment '前一个任务处理人id                                        '
,`pre_user_name`                     string               comment '前一个任务处理人id                                        '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_user`                       string               comment '创建人名称                                             '
,`create_by`                         string               comment '创建人id                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_user`                       string               comment '修改人名称                                             '
,`update_by`                         string               comment '修改人id                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_app_main partition(data_date='${hiveconf:DATA_DATE}')
select
`app_no`                           
,`channel`                          
,`app_type`                         
,`business_id`                      
,`audit_state`                      
,`proc_def_id`                      
,`proc_inst_id`                     
,`status`                           
,`pre_task_def_key`                 
,`pre_task_def_name`                
,`pre_user_id`                      
,`pre_user_name`                    
,`enable`                           
,`remark`                           
,`create_user`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_user`                      
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_wkfl_wkfl_app_main;