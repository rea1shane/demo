--alter table dw_uat.dw_olea_data_ansi_olea_ref_public_holiday   add columns (currency_code     string  comment'币种');
--alter table dw_uat.dw_olea_data_ansi_olea_ref_public_holiday   add columns (`year`            int     comment'年份');

--alter table dw_uat.dw_olea_data_ansi_olea_ref_public_holiday  change   `date`   	 `date`  	   date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_public_holiday  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_public_holiday  change   create_time   create_time  timestamp comment'' ;

create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_public_holiday
(
 id				   string comment 'id'
,`date`		       string comment 'date'
,holiday		   string comment 'holiday'
,weekday		   string comment 'weekday'
,country		   string comment 'countrycode'
,update_date	   string comment 'update_date'
,create_by	   	   string comment 'create_by'
,create_time	   string comment 'create_time'
)partitioned by (data_date string)
stored as parquet;
                                      
insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_public_holiday partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id			
	,from_unixtime(cast(`date` /1000 as bigint),'yyyy-MM-dd') as `date`        
	,holiday     
	,weekday     
	,country as countrycode 
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date  
    ,create_by                 
	,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time	
    ,currency_code
    ,`year`         	
 from ods.ods_olea_data_ansi_olea_ref_public_holiday
;
