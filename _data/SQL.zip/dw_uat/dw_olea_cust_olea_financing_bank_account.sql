--drop table if exists dw_uat.dw_olea_cust_olea_financing_bank_account;
create table if not exists dw_uat.dw_olea_cust_olea_financing_bank_account
(`id`                                string               comment ' '
,`financing_id`                      string               comment 'financing id '
,`data_source`                       string               comment 'data source :TTP Name : LLSI/Infor Nexus '
,`program_id`                        string               comment 'program id '
,`company_id`                        string               comment 'company id  '
,`account_name`                      string               comment 'account name'
,`account_currency`                  string               comment 'account currency '
,`account_no`                        string               comment 'account no '
,`bank_swift_code`                   string               comment 'bank swift code '
,`bank_address`                      string               comment 'bank address'                                             
,`bank_name`                         string               comment 'bank name'                                         
,`intermediary_swift_code`           string               comment 'intermediary swift code '
,`bank_branch`                       string               comment 'bank branch '
,`create_by`                         string               comment 'creator id  '
,`create_by_name`                    string               comment 'creator name '
,`create_time`                       timestamp            comment 'create time'
,`update_by`                         string               comment 'updator id'
,`update_by_name`                    string               comment 'updator name '
,`update_time`                       timestamp            comment 'update time '
) comment 'Asset Collection Account Table'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_financing_bank_account partition(data_date='${hiveconf:DATA_DATE}')
		select
		`id`                               
		,`financing_id`                     
		,`data_source`                      
		,`program_id`                       
		,`company_id`                       
		,`account_name`                     
		,`account_currency`                 
		,`account_no`                       
		,`bank_swift_code`                  
		,`bank_address`                     
		,`bank_name`                        
		,`intermediary_swift_code`          
		,`bank_branch`                      
		,`create_by`                        
		,`create_by_name`                   
		,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
		,`update_by`                        
		,`update_by_name`                   
		,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
		,project_code
		,account_type
		,account_id
		,participant_id
		,ffc_account_name
	 ,ffc_account_no
from ods.ods_olea_cust_olea_financing_bank_account;