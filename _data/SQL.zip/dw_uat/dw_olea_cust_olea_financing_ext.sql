create table if not exists dw_uat.dw_olea_cust_olea_financing_ext
( 
	 id               	      string					comment ''
    ,repayment_status      string           comment 'repayemnt status: Not Repaid/Partial Repaid/Full Repaid'
    ,repayment_date   	   date             comment 'actual repayment date'
    ,create_by             string           comment 'creator id'
    ,create_by_name        string           comment 'creator name'
    ,create_time           timestamp 				comment 'create time'
    ,update_by             string           comment 'updator id'
    ,update_by_name        string           comment 'updator name'
    ,update_time           timestamp 				comment 'update time'

)
comment ''
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_ext  partition(data_date='${hiveconf:DATA_DATE}')
select 
	  id               
     ,repayment_status
	 ,from_unixtime(cast(repayment_date/1000 as bigint),'yyyy-MM-dd')  		 as repayment_date  
     ,create_by                          
     ,create_by_name                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                        
     ,update_by                          
     ,update_by_name                     
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time 
	 ,min_disbursement_amount           
     ,actual_adjusted_interest          
     ,actual_interest_adjustment        
     ,financing_program_adjusted_rate_id	
     ,company_person_role_option 
	 ,cooling_period_days
	 ,from_unixtime(cast(cooling_period_start_date/1000 as bigint),'yyyy-MM-dd') as cooling_period_start_date
	 ,from_unixtime(cast(cooling_period_end_date/1000 as bigint),'yyyy-MM-dd') as cooling_period_end_date
	 ,nominal_rate_type
	 ,manual_input_nominal_rate
	 ,olea_share 
	 ,investor_share 
	 ,olea_share_adjustment 
	 ,investor_share_adjustment
	 ,`type`
	 ,buyer_program
	 ,early_alert_monitoring_flag
	 ,send_email_flag
	 ,account_id
  from ods.ods_olea_cust_olea_financing_ext 
;