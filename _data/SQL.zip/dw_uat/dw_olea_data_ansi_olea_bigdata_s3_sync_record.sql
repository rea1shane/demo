create table if not exists dw_uat.dw_olea_data_ansi_olea_bigdata_s3_sync_record
(  
   id                               string    comment '唯一主键，自增雪花id'
  ,bigdata_object_key				string    comment '文件在bigdata s3的key值'
  ,olea_object_key					string    comment '文件在olea s3的key值'
  ,file_last_modified_time          timestamp comment '文件在s3的最后修改时间'
  ,table_name  			            string    comment '同步数据对应的静态表名'
  ,sync_result 			            string    comment '同步结果'
  ,sync_time 				        timestamp comment '同步时间'
)
COMMENT'olea静态数据与大数据S3同步记录表'
partitioned by (data_date string)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_data_ansi_olea_bigdata_s3_sync_record partition(data_date='${hiveconf:DATA_DATE}')
select 
     id                             
    ,bigdata_object_key 
	,olea_object_key	
    ,from_unixtime(cast(file_last_modified_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as file_last_modified_time  
    ,table_name  			    
    ,sync_result 			     
    ,from_unixtime(cast(sync_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as sync_time 					           
 from ods.ods_olea_data_ansi_olea_bigdata_s3_sync_record
 ;
