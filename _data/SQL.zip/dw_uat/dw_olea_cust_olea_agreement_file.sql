--drop table if exists dw_uat.dw_olea_cust_olea_agreement_file;
create table if not exists dw_uat.dw_olea_cust_olea_agreement_file
(`id`                                string               comment '  '
,`agreement_id`                      string               comment 'Contract subject company id '
,`file_id`                           string               comment 'archive attachment id'
,`name`                              string               comment 'attachment name'
,`agreement_temp_type`               string               comment 'Contract template type '
,`executed_on`                       date                 comment 'effective date  '
,`upload_time`                       timestamp            comment 'upload time '
,`create_time`                       timestamp            comment 'create time'
,`create_by`                         string               comment 'creator id'
,`update_time`                       timestamp            comment 'update time'
,`update_by`                         string               comment 'updater id'
) comment 'Investor contract document form'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_agreement_file partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`agreement_id`                     
,`file_id`                          
,`name`                             
,`agreement_temp_type`              
,nvl(from_unixtime(cast(`executed_on`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`executed_on`) as executed_on
,nvl(from_unixtime(cast(`upload_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`upload_time`) as upload_time
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        

from ods.ods_olea_cust_olea_agreement_file;