create table if not exists dw_uat.dw_olea_cust_olea_overdue_record
( 
  id              			          string  
  ,financing_id                       string  		COMMENT 'olea_financing表id'
  ,asset_id               	          string  		COMMENT 'internal transfer type'
  ,invoice_no             	          string  		COMMENT '发票编号'
  ,supplier_name                      string  		COMMENT 'supplier名称 company表name'
  ,buyer_name             	          string  		COMMENT 'buyer名称 company表name'
  ,fund_name             	          string  		COMMENT 'investor名称 company表name'
  ,fr_template            	          string  		COMMENT 'FR Template'
  ,principal_amount                   double  		COMMENT '本金'
  ,currency             		      string  		COMMENT '币种'
  ,financing_period 			      int   		COMMENT 'financing正常时间'
  ,latest_invoice_due_date 	          date  		COMMENT '最终的发票时间'
  ,latest_estimated_maturity_date 	  date   		COMMENT '最终的到期日'
  ,overdue_days 					  int   		COMMENT '逾期时间'
  ,overdue_interest             	  double  		COMMENT '逾期利息'
  ,overdue_repayment             	  string   		COMMENT '逾期金额还款状态'
  ,program_end_date 				  date 			COMMENT '项目到期日'
  ,product_type           		      string  		COMMENT '产品类型'
  ,nominal_rate_type                  string  		COMMENT '名义利率类型：Fixed、Floating'
  ,risk_free_rate_option              string  		COMMENT '最低风险利率选项：TermsSofa'
  ,manual_input_nominal_rate          double  		COMMENT '手动输入的名义利率值'
  ,overdue_agree_rate                 double  		COMMENT '逾期约定利率（即financingProgram创建时输入框写入的利率值）'
  ,advance_ratio             	      double  		COMMENT '融资比例(Advance Ratio)'
  ,nominal_rate             	      double  		COMMENT 'financingProgram正常费率nominal rate'
  ,overdue_rate             	      double  		COMMENT 'financingProgram逾期费率overdue radio'
  ,full_repayment_date 		          date    		COMMENT 'fullRepayment 时间'
  ,create_by             		      string  		COMMENT '创建人id'
  ,create_by_name                     string        COMMENT '创建人名称'
  ,create_time 				          timestamp  	COMMENT '创建时间'
  ,update_by              		      string  	    COMMENT '修改人id'
  ,update_by_name                     string  	    COMMENT '修改人名称'
  ,update_time 				          timestamp     COMMENT '修改时间'
)
comment '逾期表'
partitioned by (data_date date)
stored as parquet
;


insert overwrite table dw_uat.dw_olea_cust_olea_overdue_record  partition(data_date='${hiveconf:DATA_DATE}')
select 
	id              			       
    ,financing_id                    
    ,asset_id               	       
    ,invoice_no             	       
    ,supplier_name                   
    ,buyer_name             	       
    ,fund_name             	       
    ,fr_template            	       
    ,principal_amount                
    ,currency             		   
    ,financing_period 			   
    ,from_unixtime(cast(latest_invoice_due_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') 	      as latest_invoice_due_date 	       
    ,from_unixtime(cast(latest_estimated_maturity_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as latest_estimated_maturity_date 	
    ,overdue_days 					
    ,overdue_interest             	
    ,overdue_repayment             	
    ,from_unixtime(cast(program_end_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as program_end_date 				
    ,product_type           		   
    ,nominal_rate_type               
    ,risk_free_rate_option           
    ,manual_input_nominal_rate       
    ,overdue_agree_rate              
    ,advance_ratio             	   
    ,nominal_rate             	   
    ,overdue_rate             	   
    ,from_unixtime(cast(full_repayment_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as full_repayment_date 		       	 
    ,create_by                          
    ,create_by_name                     
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                        
    ,update_by                          
    ,update_by_name                     
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time
    ,disbursement_package_id	
    ,comment
	,from_unixtime(cast(cooling_period_end_date/1000 as bigint),'yyyy-MM-dd') as cooling_period_end_date
	,manual_operation
	,calculate_status  
  from ods.ods_olea_cust_olea_overdue_record
;