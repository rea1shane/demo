--drop table if exists dw_uat.dw_olea_scb_host_accounting_report;
create table if not exists dw_uat.dw_olea_scb_host_accounting_report
(`id`                                string               comment '                                                  '
,`file_id`                           string               comment 'host_file主键id                                     '
,`report_id`                         string               comment '取值：Rpt-Id，可以和host_file.report_id关联                '
,`bank_acct_id`                      string               comment '取值：Rpt-Acct-Id-Othr-Id                            '
,`bank_acct_ccy`                     string               comment '取值：Rpt-Acct-Ccy                                   '
,`bank_acct_name`                    string               comment '取值：Rpt-Acct-Nm                                    '
,`bank_acct_bic`                     string               comment '取值：Rpt-Acct-FinInstnId-BIC                        '
,`no_of_ntries`                      string               comment '取值：Rpt-TxsSummry-TtlNtries-NbOfNtries             '
,`bal_type_code`                     string               comment '取值：Rpt-Bal-Tp-CdOrPrtry-Cd                        '
,`bal_amt`                           string               comment '取值：Rpt-Bal-Amt                                    '
,`bal_ccy`                           string               comment '取值：Rpt-Bal-Amt.Ccy                                '
,`bal_cdt_dbt_ind`                   string               comment '取值：Rpt-Bal-CdtDbtInd                              '
,`bal_date`                          date                 comment '取值：Rpt-Bal-Dt                                     '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_scb_host_accounting_report partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`file_id`                          
,`report_id`                        
,`bank_acct_id`                     
,`bank_acct_ccy`                    
,`bank_acct_name`                   
,`bank_acct_bic`                    
,`no_of_ntries`                     
,`bal_type_code`                    
,`bal_amt`                          
,`bal_ccy`                          
,`bal_cdt_dbt_ind`                  
,nvl(from_unixtime(cast(`bal_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`bal_date`) as bal_date
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_scb_host_accounting_report;