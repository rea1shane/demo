create table if not exists dw_uat.dw_olea_cust_olea_financing_program_buyer_initiated
 (
	id 								     int        comment  '唯一主键，自增雪花id'
	,financing_program_id  int        comment '融资项目ID'
	,buyer_group_id        int 	      comment '买方集团id(buyer group id) link to olea_company.id'
	,buyer_entity_id 		   int        comment '买方子公司ID link to olea_company.id '
	,buyer_entity_name     string     comment '买方子公司名称 for front Buyer Entity Name'
	,buyer_program 		     string     comment '买方发起流程类型，Programmatic、Selective、Supplier Upload（置灰）、Not Applicable'
	,advance_ratio         double     comment '融资比率,Buyer Initiated Advance Ratio(%)'
	,create_by 				     int      	comment '创建人userId'
	,create_by_name 		   string  	  comment '创建人'
	,create_time           timestamp  comment '创建时间'
	,update_by 				     int       	comment '更新人userId'
	,update_by_name        string   	comment '更新人'
	,update_time           timestamp 	comment '最后更新时间'
)comment '融资项目买方业务类型'
partitioned by(data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_program_buyer_initiated  partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id 							
	,financing_program_id
	,buyer_group_id        
	,buyer_entity_id 		
	,buyer_entity_name   
	,buyer_program 		  
	,advance_ratio           
	,create_by 				  
	,create_by_name 		  
	,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd') as create_time               
	,update_by 				  
	,update_by_name      
	,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd') as update_time       
from ods.ods_olea_cust_olea_financing_program_buyer_initiated
;