--drop table if exists dw_uat.dw_olea_wkfl_wkfl_ext_data_def;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_ext_data_def
(`id`                                string               comment '                                                  '
,`app_type`                          string               comment '流程类型                                              '
,`ext_name1`                         string               comment '                                                  '
,`ext_name2`                         string               comment '                                                  '
,`ext_name3`                         string               comment '                                                  '
,`ext_name4`                         string               comment '                                                  '
,`ext_name5`                         string               comment '                                                  '
,`ext_name6`                         string               comment '                                                  '
,`ext_name7`                         string               comment '                                                  '
,`ext_name8`                         string               comment '                                                  '
,`ext_name9`                         string               comment '                                                  '
,`ext_name10`                        string               comment '                                                  '
,`ext_name11`                        string               comment '                                                  '
,`ext_name12`                        string               comment '                                                  '
,`ext_name13`                        string               comment '                                                  '
,`ext_name14`                        string               comment '                                                  '
,`ext_name15`                        string               comment '                                                  '
,`ext_name16`                        string               comment '                                                  '
,`ext_name17`                        string               comment '                                                  '
,`ext_name18`                        string               comment '                                                  '
,`ext_name19`                        string               comment '                                                  '
,`ext_name20`                        string               comment '                                                  '
,`ext_name21`                        string               comment '                                                  '
,`ext_name22`                        string               comment '                                                  '
,`ext_name23`                        string               comment '                                                  '
,`ext_name24`                        string               comment '                                                  '
,`ext_name25`                        string               comment '                                                  '
,`ext_name26`                        string               comment '                                                  '
,`ext_name27`                        string               comment '                                                  '
,`ext_name28`                        string               comment '                                                  '
,`ext_name29`                        string               comment '                                                  '
,`ext_name30`                        string               comment '                                                  '
,`ext_type1`                         string               comment '                                                  '
,`ext_type2`                         string               comment '                                                  '
,`ext_type3`                         string               comment '                                                  '
,`ext_type4`                         string               comment '                                                  '
,`ext_type5`                         string               comment '                                                  '
,`ext_type6`                         string               comment '                                                  '
,`ext_type7`                         string               comment '                                                  '
,`ext_type8`                         string               comment '                                                  '
,`ext_type9`                         string               comment '                                                  '
,`ext_type10`                        string               comment '                                                  '
,`ext_type11`                        string               comment '                                                  '
,`ext_type12`                        string               comment '                                                  '
,`ext_type13`                        string               comment '                                                  '
,`ext_type14`                        string               comment '                                                  '
,`ext_type15`                        string               comment '                                                  '
,`ext_type16`                        string               comment '                                                  '
,`ext_type17`                        string               comment '                                                  '
,`ext_type18`                        string               comment '                                                  '
,`ext_type19`                        string               comment '                                                  '
,`ext_type20`                        string               comment '                                                  '
,`ext_type21`                        string               comment '                                                  '
,`ext_type22`                        string               comment '                                                  '
,`ext_type23`                        string               comment '                                                  '
,`ext_type24`                        string               comment '                                                  '
,`ext_type25`                        string               comment '                                                  '
,`ext_type26`                        string               comment '                                                  '
,`ext_type27`                        string               comment '                                                  '
,`ext_type28`                        string               comment '                                                  '
,`ext_type29`                        string               comment '                                                  '
,`ext_type30`                        string               comment '                                                  '
,`query_by_like1`                    string               comment '                                                  '
,`query_by_like2`                    string               comment '                                                  '
,`query_by_like3`                    string               comment '                                                  '
,`query_by_like4`                    string               comment '                                                  '
,`query_by_like5`                    string               comment '                                                  '
,`query_by_like6`                    string               comment '                                                  '
,`query_by_like7`                    string               comment '                                                  '
,`query_by_like8`                    string               comment '                                                  '
,`query_by_like9`                    string               comment '                                                  '
,`query_by_like10`                   string               comment '                                                  '
,`query_by_like11`                   string               comment '                                                  '
,`query_by_like12`                   string               comment '                                                  '
,`query_by_like13`                   string               comment '                                                  '
,`query_by_like14`                   string               comment '                                                  '
,`query_by_like15`                   string               comment '                                                  '
,`query_by_like16`                   string               comment '                                                  '
,`query_by_like17`                   string               comment '                                                  '
,`query_by_like18`                   string               comment '                                                  '
,`query_by_like19`                   string               comment '                                                  '
,`query_by_like20`                   string               comment '                                                  '
,`query_by_like21`                   string               comment '                                                  '
,`query_by_like22`                   string               comment '                                                  '
,`query_by_like23`                   string               comment '                                                  '
,`query_by_like24`                   string               comment '                                                  '
,`query_by_like25`                   string               comment '                                                  '
,`query_by_like26`                   string               comment '                                                  '
,`query_by_like27`                   string               comment '                                                  '
,`query_by_like28`                   string               comment '                                                  '
,`query_by_like29`                   string               comment '                                                  '
,`query_by_like30`                   string               comment '                                                  '
,`must1`                             string               comment '                                                  '
,`must2`                             string               comment '                                                  '
,`must3`                             string               comment '                                                  '
,`must4`                             string               comment '                                                  '
,`must5`                             string               comment '                                                  '
,`must6`                             string               comment '                                                  '
,`must7`                             string               comment '                                                  '
,`must8`                             string               comment '                                                  '
,`must9`                             string               comment '                                                  '
,`must10`                            string               comment '                                                  '
,`must11`                            string               comment '                                                  '
,`must12`                            string               comment '                                                  '
,`must13`                            string               comment '                                                  '
,`must14`                            string               comment '                                                  '
,`must15`                            string               comment '                                                  '
,`must16`                            string               comment '                                                  '
,`must17`                            string               comment '                                                  '
,`must18`                            string               comment '                                                  '
,`must19`                            string               comment '                                                  '
,`must20`                            string               comment '                                                  '
,`must21`                            string               comment '                                                  '
,`must22`                            string               comment '                                                  '
,`must23`                            string               comment '                                                  '
,`must24`                            string               comment '                                                  '
,`must25`                            string               comment '                                                  '
,`must26`                            string               comment '                                                  '
,`must27`                            string               comment '                                                  '
,`must28`                            string               comment '                                                  '
,`must29`                            string               comment '                                                  '
,`must30`                            string               comment '                                                  '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_user`                       string               comment '创建人名称                                             '
,`create_by`                         string               comment '创建人id                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_user`                       string               comment '修改人名称                                             '
,`update_by`                         string               comment '修改人id                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_ext_data_def partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`app_type`                         
,`ext_name1`                        
,`ext_name2`                        
,`ext_name3`                        
,`ext_name4`                        
,`ext_name5`                        
,`ext_name6`                        
,`ext_name7`                        
,`ext_name8`                        
,`ext_name9`                        
,`ext_name10`                       
,`ext_name11`                       
,`ext_name12`                       
,`ext_name13`                       
,`ext_name14`                       
,`ext_name15`                       
,`ext_name16`                       
,`ext_name17`                       
,`ext_name18`                       
,`ext_name19`                       
,`ext_name20`                       
,`ext_name21`                       
,`ext_name22`                       
,`ext_name23`                       
,`ext_name24`                       
,`ext_name25`                       
,`ext_name26`                       
,`ext_name27`                       
,`ext_name28`                       
,`ext_name29`                       
,`ext_name30`                       
,`ext_type1`                        
,`ext_type2`                        
,`ext_type3`                        
,`ext_type4`                        
,`ext_type5`                        
,`ext_type6`                        
,`ext_type7`                        
,`ext_type8`                        
,`ext_type9`                        
,`ext_type10`                       
,`ext_type11`                       
,`ext_type12`                       
,`ext_type13`                       
,`ext_type14`                       
,`ext_type15`                       
,`ext_type16`                       
,`ext_type17`                       
,`ext_type18`                       
,`ext_type19`                       
,`ext_type20`                       
,`ext_type21`                       
,`ext_type22`                       
,`ext_type23`                       
,`ext_type24`                       
,`ext_type25`                       
,`ext_type26`                       
,`ext_type27`                       
,`ext_type28`                       
,`ext_type29`                       
,`ext_type30`                       
,`query_by_like1`                   
,`query_by_like2`                   
,`query_by_like3`                   
,`query_by_like4`                   
,`query_by_like5`                   
,`query_by_like6`                   
,`query_by_like7`                   
,`query_by_like8`                   
,`query_by_like9`                   
,`query_by_like10`                  
,`query_by_like11`                  
,`query_by_like12`                  
,`query_by_like13`                  
,`query_by_like14`                  
,`query_by_like15`                  
,`query_by_like16`                  
,`query_by_like17`                  
,`query_by_like18`                  
,`query_by_like19`                  
,`query_by_like20`                  
,`query_by_like21`                  
,`query_by_like22`                  
,`query_by_like23`                  
,`query_by_like24`                  
,`query_by_like25`                  
,`query_by_like26`                  
,`query_by_like27`                  
,`query_by_like28`                  
,`query_by_like29`                  
,`query_by_like30`                  
,`must1`                            
,`must2`                            
,`must3`                            
,`must4`                            
,`must5`                            
,`must6`                            
,`must7`                            
,`must8`                            
,`must9`                            
,`must10`                           
,`must11`                           
,`must12`                           
,`must13`                           
,`must14`                           
,`must15`                           
,`must16`                           
,`must17`                           
,`must18`                           
,`must19`                           
,`must20`                           
,`must21`                           
,`must22`                           
,`must23`                           
,`must24`                           
,`must25`                           
,`must26`                           
,`must27`                           
,`must28`                           
,`must29`                           
,`must30`                           
,`enable`                           
,`remark`                           
,`create_user`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_user`                      
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_wkfl_wkfl_ext_data_def;