create table if not exists dw_uat.dw_olea_data_ansi_olea_black_list
(
  id                       string comment '' 
 ,entity_name              string comment 'EntityName'
 ,reason_for_black_list    string comment 'ReasonForBlackList'
 ,person_created           string comment 'PersonCreated'
 ,date_of_creation         string comment 'DateOfCreation'
 ,update_date              string comment 'update_date'
 ,create_time              string comment ''
 ,create_by                string comment ''
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_data_ansi_olea_black_list  change   date_of_creation   date_of_creation  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_black_list  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_black_list  change   create_time   create_time timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_data_ansi_olea_black_list partition(data_date='${hiveconf:DATA_DATE}')
select 
       id                      
      ,entity_name             
      ,reason_for_black_list   
      ,person_created          
      ,cast(from_unixtime(cast(date_of_creation/1000 as bigint),'yyyy-MM-dd')   as date) as  date_of_creation                   
      ,cast(from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd')      as date) as  update_date
      ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time             
      ,create_by                        
 from ods.ods_olea_data_ansi_olea_black_list
 ;

