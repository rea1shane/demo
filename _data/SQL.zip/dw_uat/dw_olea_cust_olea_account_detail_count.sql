create table if not exists dw_uat.dw_olea_cust_olea_account_detail_count
( 
  id 						  						string    comment 'id'
  ,account_detail_id 		  		string    comment 'olea_account_detail_record.id'
  ,`type` 					  			  string    comment 'internal transfer type'
  ,internal_transfer_status   string    comment 'internal transfer status'
  ,create_by 	 			  				string 	  comment 'creator id'
  ,create_by_name 			  		string    comment 'creator name'
  ,create_time 				  			timestamp	comment 'create time'
  ,update_by 				  				string    comment 'Modifier id'
  ,update_by_name		      		string    comment 'Modifier name'
  ,update_time 		          	timestamp comment	'update time'
 )
 COMMENT'Accounting Details Statistical Status Table'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_account_detail_count partition(data_date='${hiveconf:DATA_DATE}')
select 
  id 						
  ,account_detail_id 		
  ,`type` 						
  ,internal_transfer_status 
  ,create_by 	 			
  ,create_by_name 			
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
  ,update_by 
  ,update_by_name	  
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
  ,amount  
  ,currency
  ,param_json
from ods.ods_olea_cust_olea_account_detail_count a 
;


















