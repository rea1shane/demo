--drop table if exists dw_uat.dw_olea_pub_olea_template;
create table if not exists dw_uat.dw_olea_pub_olea_template
(`id`                                string               comment '                                                  '
,`type`                              string               comment '类型                                                '
,`template_name`                     string               comment '模版名称                                              '
,`template_no`                       string               comment '模版编号                                              '
,`file_name`                         string               comment '文件名                                               '
,`file_external_key`                 string               comment '文件外部唯一编号                                          '
,`file_dir`                          string               comment '模版所在目录                                            '
,`remark`                            string               comment '备注                                                '
,`create_time`                       timestamp            comment '                                                  '
,`create_by`                         string               comment '                                                  '
,`create_by_name`                    string               comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
,`update_by`                         string               comment '                                                  '
,`update_by_name`                    string               comment '                                                  '
) comment '通用模版表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_olea_template partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`type`                             
,`template_name`                    
,`template_no`                      
,`file_name`                        
,`file_external_key`                
,`file_dir`                         
,`remark`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        
,`update_by_name`                   

from ods.ods_olea_pub_olea_template;