--drop table if exists dw_uat.dw_olea_wkfl_wkfl_app_type;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_app_type
(`dict_key`                          string               comment '流程类型                                              '
,`display_name`                      string               comment '展示名称                                              '
,`tenant`                            string               comment '租户                                                '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_user`                       string               comment '创建人名称                                             '
,`create_by`                         string               comment '创建人id                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_user`                       string               comment '修改人名称                                             '
,`update_by`                         string               comment '修改人id                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_app_type partition(data_date='${hiveconf:DATA_DATE}')
select
`dict_key`                         
,`display_name`                     
,`tenant`                           
,`enable`                           
,`remark`                           
,`create_user`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_user`                      
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_wkfl_wkfl_app_type;