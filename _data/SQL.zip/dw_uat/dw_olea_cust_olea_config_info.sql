--drop table if exists dw_uat.dw_olea_cust_olea_config_info;
create table if not exists dw_uat.dw_olea_cust_olea_config_info
(`id`                                string               comment '   '
,`config_key`                        string               comment 'config key  '
,`config_value`                      string               comment 'config value '
,`expire_date`                       date                 comment 'expire date '
,`create_time`                       timestamp            comment 'create time '
,`create_by`                         string               comment 'creator id  '
,`update_time`                       timestamp            comment 'updator time'
,`update_by`                         string               comment 'updator id '
) comment 'configuration information table'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_config_info partition(data_date='${hiveconf:DATA_DATE}')
select
		`id`                               
		,`config_key`                       
		,`config_value`                     
		,nvl(from_unixtime(cast(`expire_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`expire_date`) as expire_date
		,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
		,`create_by`                        
		,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
		,`update_by`                        
from ods.ods_olea_cust_olea_config_info;