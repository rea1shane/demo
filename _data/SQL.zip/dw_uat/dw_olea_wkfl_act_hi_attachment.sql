--drop table if exists dw_uat.dw_olea_wkfl_act_hi_attachment;
create table if not exists dw_uat.dw_olea_wkfl_act_hi_attachment
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`USER_ID_`                          string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`DESCRIPTION_`                      string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  '
,`TASK_ID_`                          string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`URL_`                              string               comment '                                                  '
,`CONTENT_ID_`                       string               comment '                                                  '
,`TIME_`                             timestamp            comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_hi_attachment partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`USER_ID_`                         
,`NAME_`                            
,`DESCRIPTION_`                     
,`TYPE_`                            
,`TASK_ID_`                         
,`PROC_INST_ID_`                    
,`URL_`                             
,`CONTENT_ID_`                      
,nvl(from_unixtime(cast(`TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`TIME_`) as TIME_

from ods.ods_olea_wkfl_act_hi_attachment;