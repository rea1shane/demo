--drop table if exists dw_uat.dw_olea_wkfl_act_id_membership;
create table if not exists dw_uat.dw_olea_wkfl_act_id_membership
(`USER_ID_`                          string               comment '                                                  '
,`GROUP_ID_`                         string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_id_membership partition(data_date='${hiveconf:DATA_DATE}')
select
`USER_ID_`                         
,`GROUP_ID_`                        

from ods.ods_olea_wkfl_act_id_membership;