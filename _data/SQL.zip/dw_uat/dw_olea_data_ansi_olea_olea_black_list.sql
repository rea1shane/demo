create table if not exists dw_uat.dw_olea_data_ansi_olea_black_list
(
 id						string  comment  'id'
,entityname             string  comment  'EntityName'
,reasonforblacklist     string  comment  'ReasonForBlackList'
,personcreated          string  comment  'PersonCreated'
,dateofcreation         string  comment  'DateOfCreation'
,update_date            string  comment  'update_date'
,update_by              string  comment  'update_by'
)partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_data_ansi_olea_black_list partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id					
	,entity_name 				as entityname         
	,reason_for_black_list  	as reasonforblacklist 
	,person_created 			as personcreated      
	,date_of_creation 			as dateofcreation     
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_date      
	,update_by			
 from ods.ods_olea_data_ansi_olea_black_list
;








