--drop table if exists dw_uat.dw_olea_scb_host_file_config;
create table if not exists dw_uat.dw_olea_scb_host_file_config
(`id`                                string               comment '                                                  '
,`dir_path`                          string               comment '目录路径                                              '
,`type`                              string               comment '类型                                                '
,`need_delete`                       string               comment '是否需要删除                                            '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment '文件配置'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_scb_host_file_config partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`dir_path`                         
,`type`                             
,`need_delete`                      
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_scb_host_file_config;