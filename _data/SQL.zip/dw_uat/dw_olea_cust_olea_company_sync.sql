--drop table if exists dw_uat.dw_olea_cust_olea_company_sync;
create table if not exists dw_uat.dw_olea_cust_olea_company_sync
(`id`                                string               comment '   '
,`supplier_name`                     string               comment 'supplier name '
,`country`                           string               comment 'country'
,`country_code`                      string               comment 'country code'
,`object_key`                        string               comment 'object key '
,`status`                            string               comment 'status  '
,`push_time`                         timestamp            comment 'push time'
,`process_time`                      timestamp            comment 'process time '
,`seq`                               string               comment ' '
,`data_json`                         string               comment ' '
,`remark`                            string               comment 'remark '
,`create_time`                       timestamp            comment 'create time '
,`create_by`                         string               comment '   '
,`update_time`                       timestamp            comment 'update time '
,`update_by`                         string               comment ' '
) comment 'Push enterprise information records'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_company_sync partition(data_date='${hiveconf:DATA_DATE}')
select
		`id`                               
		,`supplier_name`                    
		,`country`                          
		,`country_code`                     
		,`object_key`                       
		,`status`                           
		,nvl(from_unixtime(cast(`push_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`push_time`) as push_time
		,nvl(from_unixtime(cast(`process_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`process_time`) as process_time
		,`seq`                              
		,`data_json`                        
		,`remark`                           
		,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
		,`create_by`                        
		,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
		,`update_by`                        
from ods.ods_olea_cust_olea_company_sync;