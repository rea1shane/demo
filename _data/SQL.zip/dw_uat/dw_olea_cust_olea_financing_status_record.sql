--drop table if exists dw_uat.dw_olea_cust_olea_financing_status_record;
create table if not exists dw_uat.dw_olea_cust_olea_financing_status_record
(`id`                                string               comment '主键ID                                              '
,`supplier_id`                       string               comment 'supplier的companyId                                '
,`financing_id`                      string               comment '资产id olea_financing.id                            '
,`status`                            string               comment '状态                                                '
,`create_by`                         string               comment '创建人                                               '
,`create_by_name`                    string               comment '创建人名称                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '修改人                                               '
,`update_by_name`                    string               comment '修改人名称                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
,`type`                              string               comment '状态类型                                              '
) comment '资产状态变更记录'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_financing_status_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`supplier_id`                      
,`financing_id`                     
,`status`                           
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`type`                             

from ods.ods_olea_cust_olea_financing_status_record;