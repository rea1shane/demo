--alter table dw_uat.dw_olea_cust_olea_company_audit  add columns(filling_task_status string comment'外部建档任务启动状态');


--drop table if exists dw_uat.dw_olea_cust_olea_company_audit;
create table if not exists dw_uat.dw_olea_cust_olea_company_audit
(`id`                                string               comment '     '
,`company_id`                        string               comment 'company id '
,`app_no`                            string               comment 'process application NO. '
,`first_commit_flag`                 string               comment 'Is it the first time to establish  doc '
,`dd_state`                          string               comment 'Approval Status     '
,`dd_approved_time`                  timestamp            comment 'dd approved time     '
,`client_state`                      string               comment 'company status       '
,`company_type`                      string               comment 'company type such supplier,buyer,inverstor   '
,`modify_portal`                     string               comment 'Currently modifiable ends, all, suppliers, inner pipe  '
,`investment_type`                   string               comment 'inverstor type                                             '
,`submit_phase`                      string               comment 'supply submitted step     '
,`level_type`                        string               comment 'level type  '
,`group_id`                          string               comment 'The company id of the associated group type '
,`create_type`                       string               comment 'Documentation method: internal/external'
,`olea_id_number`                    string               comment 'olea id number  '
,`olea_id`                           string               comment 'Olea ID                                           '
,`city`                              string               comment 'city                                              '
,`street`                            string               comment 'street                                            '
,`company_name_local`                string               comment 'Country name in local language                                          '
,`company_name`                      string               comment 'company name '
,`country`                           string               comment 'country of registration  '
,`company_registration_document_type` string               comment 'company registration document type '
,`company_unique_code`               string               comment 'registration code '
,`third_party_code`                  string               comment '3rd party encoding, for assets etc. '
,`registration_doc_expiry_date`      date                 comment 'Registration file expiration time  '
,`company_address`                   string               comment 'company address  '
,`legal_person_name`                 string               comment 'legal person name '
,`industry`                          string               comment 'industry                                                '
,`industry_name`                     string               comment 'industry name                                              '
,`mobile_no`                         string               comment 'mobile no                                               '
,`mobile_prefix`                     string               comment 'phone number prefix                                             '
,`operating_country`                 string               comment 'country of operation                                              '
,`operating_city`                    string               comment 'Operating city'                                              
,`operating_street`                  string               comment 'operating street                                              '
,`business_manager`                  string               comment 'business manager id                                            '
,`remark`                            string               comment 'remark                                                '
,`create_by`                         string               comment 'creator id                                             '
,`update_by`                         string               comment 'updator id                                            '
,`create_by_name`                    string               comment 'creator name                                             '
,`update_by_name`                    string               comment 'updator name                                          '
,`ops_id`                            string               comment 'last approve user id                              '
,`file_id`                           string               comment 'attach file id                                              '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
,`tax_identification_num`            string               comment 'tax number                                                '
,`tax_residence_country`             string               comment 'tax country                                              '
,`model_type`                        string               comment 'Company modelType category                       '
,`investor_category`                 string               comment 'Investor category: Escrow investor: escrow investor | Subscriber investor: subscription '
) comment 'Company Records'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_company_audit partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`company_id`                       
,`app_no`                           
,`first_commit_flag`                
,`dd_state`                         
,nvl(from_unixtime(cast(`dd_approved_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`dd_approved_time`) as dd_approved_time
,`client_state`                     
,`company_type`                     
,`modify_portal`                    
,`investment_type`                  
,`submit_phase`                     
,`level_type`                       
,`group_id`                         
,`create_type`                      
,`olea_id_number`                   
,`olea_id`                          
,`city`                             
,`street`                           
,`company_name_local`               
,`company_name`                     
,`country`                          
,`company_registration_document_type`
,`company_unique_code`              
,`third_party_code`                 
,nvl(from_unixtime(cast(`registration_doc_expiry_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`registration_doc_expiry_date`) as registration_doc_expiry_date
,`company_address`                  
,`legal_person_name`                
,`industry`                         
,`industry_name`                    
,`mobile_no`                        
,`mobile_prefix`                    
,`operating_country`                
,`operating_city`                   
,`operating_street`                 
,`business_manager`                 
,`remark`                           
,`create_by`                        
,`update_by`                        
,`create_by_name`                   
,`update_by_name`                   
,`ops_id`                           
,`file_id`                          
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`tax_identification_num`           
,`tax_residence_country`            
,`model_type`                       
,`investor_category`                
,filling_task_status
,email
,dd_type               
,supplier_portal_access
,investor_send_via_sftp
,parent_company_name
,app_type
,from_unixtime(cast(date_of_incorporation/1000 as bigint),'yyyy-MM-dd') as date_of_incorporation
,insurance_country_grade
,back_up_commercial_officer_name
,data_source
,country_of_incorporation
from ods.ods_olea_cust_olea_company_audit;