create table if not exists  dw_uat.dw_olea_cust_olea_buyer_invoice_shipment
 (
	  project_code 	       	 string     comment 'Platform unique code,project code'
   ,buyer_invoice_id       int        comment 'buyer invoice id'
   ,invoice_no 		       	 string     comment 'invoice NO.'
   ,incoterms 		       	 string     comment 'Incoterms'
   ,delivery_mode 	       string     comment ''
   ,shipment_document      string     comment 'shipping order number,/AWB/Receipt No.'
   ,shipment_date 	       date       comment 'shipping date，Shipment/AWB/Receipt date'
   ,country_of_loading     string     comment ''
   ,place_of_loading 	   	 string     comment 'Port/Airport/Place of Loading'
   ,country_of_destination string     comment'' 
   ,place_of_destination   string     comment''
   ,vessel_name 		   	 	 string     comment 'Vessel Name/Flight/Plate No.'
   ,shipping_company 	     string     comment 'Shipping Agent/Carrier Name'
   ,remark 				   		   string     comment 'remark'
   ,create_by 			   	   int        comment 'creator id'
   ,create_by_name 		     string     comment 'creator name'
   ,create_time 		   	   TIMESTAMP  comment 'create time'
   ,update_by 			   	   int    	  comment 'updator id'
   ,update_by_name 		     string     comment 'updator name'
   ,update_time 		   	   TIMESTAMP  comment 'update time'
)partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_buyer_invoice_shipment partition(data_date='${hiveconf:DATA_DATE}')
select 
     	 project_code 	       
        ,buyer_invoice_id       
        ,invoice_no 		        
        ,incoterms 		       
        ,delivery_mode 	       
        ,shipment_document      
        ,from_unixtime(cast(shipment_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as shipment_date 	       
        ,country_of_loading     
        ,place_of_loading 	   
        ,country_of_destination 
        ,place_of_destination   
        ,vessel_name 		   
        ,shipping_company 	   
        ,remark 				   
        ,create_by 			   
        ,create_by_name 		   
        ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 		   
        ,update_by 			   
        ,update_by_name 		   
        ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
   from ods.ods_olea_cust_olea_buyer_invoice_shipment a	
;   