create table if not exists dw_uat.dw_olea_cust_olea_buyer_bank_account_audit 
 (
	 id  							bigint      COMMENT 'primary key',
	 app_no  					string      COMMENT 'process application NO.',
	 bank_account_id  bigint      COMMENT 'The id of the buyer`s account table can be associated with the id in the table olea_supplier_bank_account to query account information',
	 status  					string      COMMENT 'account status',
	 dd_state  				string      COMMENT 'approval status:WAIT_SUBMIT:Pending Submission | IN_PROGRESS:Under Review | APPROVED:Approved | REJECTED:Rejected',
	 company_id  			bigint      COMMENT 'company id',
	 participant_id  	string      COMMENT 'participant id',
	 account_name  		string      COMMENT 'account name',
	 currency  				string      COMMENT 'currency: USD',
	 account_no  			string      COMMENT 'account NO.',
	 bank_swift_code  string      COMMENT 'bank swiftCode',
	 bank_address  		string      COMMENT 'bank address',
	 bank_name  			string      COMMENT 'bank name',
	 bank_branch  		string      COMMENT 'bank branch',
	 intermediary_swift_code 	 string   COMMENT 'middleman swiftcode',
	 enable  				 string      COMMENT 'Is it effective, Y: effective N: not effective',
	 remark  				 string      COMMENT 'remark',
	 create_by  		 bigint      COMMENT 'creator id',
	 create_by_name  string      COMMENT 'creator name',
	 create_time  	 TIMESTAMP   COMMENT 'create time',
	 update_by  		 bigint      COMMENT 'updator id',
	 update_by_name  string      COMMENT 'updator name',
	 update_time  	 TIMESTAMP   COMMENT 'update time'
)
comment 'Buyer bank account table audit record form'
partitioned by(data_date date)  
stored as parquet
;
insert overwrite table dw_uat.dw_olea_cust_olea_buyer_bank_account_audit partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id  							
	 ,app_no  					
	 ,bank_account_id  
	 ,status  					
	 ,dd_state  				
	 ,company_id  			
	 ,participant_id  	
	 ,account_name  		
	 ,currency  				
	 ,account_no  			
	 ,bank_swift_code  
	 ,bank_address  		
	 ,bank_name  			
	 ,bank_branch  		
	 ,intermediary_swift_code
	 ,enable  				 
	 ,remark  				 
	 ,create_by  		 
	 ,create_by_name  
	 ,nvl(from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),create_time) as create_time  	 
	 ,update_by  		 
	 ,update_by_name  
	 ,nvl(from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),update_time) as update_time 
	 ,ffc_account_name
	 ,ffc_account_no
from 	ods.ods_olea_cust_olea_buyer_bank_account_audit 
;