--drop table if exists dw_uat.dw_olea_wkfl_wkfl_app_history;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_app_history
(`id`                                string               comment '                                                  '
,`business_id`                       string               comment '关键业务id (与流程类型相关)                                  '
,`channel`                           string               comment '渠道号 1.PC 2.MOB                                    '
,`app_no`                            string               comment '工作流主键                                             '
,`app_type`                          string               comment '流程类型                                              '
,`proc_def_id`                       string               comment '流程实例定义编号                                          '
,`proc_inst_id`                      string               comment '流程实例号                                             '
,`task_id`                           string               comment '当前任务ID                                            '
,`task_def_key`                      string               comment '当前任务编码                                            '
,`task_def_name`                     string               comment '当前任务名称                                            '
,`task_form_key`                     string               comment '表单url                                             '
,`audit_name`                        string               comment '审核人                                               '
,`audit_user_id`                     string               comment '审核人id                                             '
,`audit_role`                        string               comment '审核人角色                                             '
,`audit_state`                       string               comment '审核状态码                                             '
,`audit_desc`                        string               comment '审批备注                                              '
,`audit_urls`                        string               comment '审批图片路径                                            '
,`audit_time`                        timestamp            comment '审核时间                                              '
,`task_create_time`                  timestamp            comment '任务创建时间                                            '
,`task_claim_time`                   timestamp            comment '任务签收时间                                            '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_user`                       string               comment '创建人名称                                             '
,`create_by`                         string               comment '创建人id                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_user`                       string               comment '修改人名称                                             '
,`update_by`                         string               comment '修改人id                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_app_history partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`business_id`                      
,`channel`                          
,`app_no`                           
,`app_type`                         
,`proc_def_id`                      
,`proc_inst_id`                     
,`task_id`                          
,`task_def_key`                     
,`task_def_name`                    
,`task_form_key`                    
,`audit_name`                       
,`audit_user_id`                    
,`audit_role`                       
,`audit_state`                      
,`audit_desc`                       
,`audit_urls`                       
,nvl(from_unixtime(cast(`audit_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`audit_time`) as audit_time
,nvl(from_unixtime(cast(`task_create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`task_create_time`) as task_create_time
,nvl(from_unixtime(cast(`task_claim_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`task_claim_time`) as task_claim_time
,`enable`                           
,`remark`                           
,`create_user`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_user`                      
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_wkfl_wkfl_app_history;