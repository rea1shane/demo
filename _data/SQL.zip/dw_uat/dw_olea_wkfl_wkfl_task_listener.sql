--drop table if exists dw_uat.dw_olea_wkfl_wkfl_task_listener;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_task_listener
(`id`                                string               comment '                                                  '
,`app_type`                          string               comment '流程类型                                              '
,`name`                              string               comment '任务名称                                              '
,`expression`                        string               comment '任务表达式                                             '
,`type`                              string               comment '任务类型 dubbo,http                                   '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_user`                       string               comment '创建人名称                                             '
,`create_by`                         string               comment '创建人id                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_user`                       string               comment '修改人名称                                             '
,`update_by`                         string               comment '修改人id                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_task_listener partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`app_type`                         
,`name`                             
,`expression`                       
,`type`                             
,`enable`                           
,`remark`                           
,`create_user`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_user`                      
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_wkfl_wkfl_task_listener;