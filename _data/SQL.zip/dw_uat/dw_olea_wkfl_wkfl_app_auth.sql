--drop table if exists dw_uat.dw_olea_wkfl_wkfl_app_auth;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_app_auth
(`id`                                string               comment '                                                  '
,`process_def_key`                   string               comment '流程定义编码                                            '
,`process_def_id`                    string               comment '流程定义id                                            '
,`task_def_key`                      string               comment '任务编码                                              '
,`role_code`                         string               comment '任务编码                                              '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_user`                       string               comment '创建人名称                                             '
,`create_by`                         string               comment '创建人id                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_user`                       string               comment '修改人名称                                             '
,`update_by`                         string               comment '修改人id                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_app_auth partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`process_def_key`                  
,`process_def_id`                   
,`task_def_key`                     
,`role_code`                        
,`enable`                           
,`remark`                           
,`create_user`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_user`                      
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_wkfl_wkfl_app_auth;