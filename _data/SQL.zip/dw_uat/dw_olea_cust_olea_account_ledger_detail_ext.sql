--alter table dw_uat.dw_olea_cust_olea_account_ledger_detail_ext add columns (valid_express  					string  comment'是否有效校验');
--alter table dw_uat.dw_olea_cust_olea_account_ledger_detail_ext add columns (amount_express 					string  comment'金额表达式');
--alter table dw_uat.dw_olea_cust_olea_account_ledger_detail_ext add columns (event 							string  comment'取值字段');
--alter table dw_uat.dw_olea_cust_olea_account_ledger_detail_ext add columns (credit_subject_name  	string  comment'credit对应科目名称');
--alter table dw_uat.dw_olea_cust_olea_account_ledger_detail_ext add columns (debit_subject_name 	string  comment'debit对应科目名称');



--drop table if exists dw_uat.dw_olea_cust_olea_account_ledger_detail_ext;
create table if not exists dw_uat.dw_olea_cust_olea_account_ledger_detail_ext
(`id`                                string               comment 'id                                       '
,`ledger_detail_id`                  string               comment 'Middle-end financial transaction details id          '
,`account_detail_record_id`          string               comment 'Accounting details record id           '
,`group_type`                        string               comment 'group type       '
,`from_bank_account`                 string               comment 'Payer`s bank account '
,`to_bank_account`                   string               comment 'Payee`s bank account number '
,`create_by`                         string               comment 'creator id'
,`create_time`                       timestamp            comment 'create time'
,`update_by`                         string               comment 'update_by'
,`update_time`                       timestamp            comment 'update time '
) comment '会计交易明细拓展表'
partitioned by(data_date string)  
stored as parquet
;




insert overwrite table  dw_uat.dw_olea_cust_olea_account_ledger_detail_ext partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`ledger_detail_id`                 
,`account_detail_record_id`         
,`group_type`                       
,`from_bank_account`                
,`to_bank_account`                  
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,valid_express  
,amount_express 
,event 			
,credit_subject_name
,debit_subject_name 
,subject_no
,direction
from ods.ods_olea_cust_olea_account_ledger_detail_ext
;