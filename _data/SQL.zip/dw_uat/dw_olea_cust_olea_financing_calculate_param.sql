--alter table dw_uat.dw_olea_cust_olea_financing_calculate_param add columns (financing_ratio string comment '融资比率');
--alter table dw_uat.dw_olea_cust_olea_financing_calculate_param add columns (customer_rate   string comment '资产价格');




--drop table if exists dw_uat.dw_olea_cust_olea_financing_calculate_param;
create table if not exists dw_uat.dw_olea_cust_olea_financing_calculate_param
(
		`id`                                 string               comment '                                                  '
		,`financing_id`                      string               comment 'financing id'
		,`financing_program_id`              string               comment 'financing program id'
		,`nominal_rate`                      string               comment 'nominal interest rate(Model 1: Nominal Rate，Model 3:Financing Ratio'
		,`overdue_rate`                      string               comment 'Overdue Rate'
		,`advance_ratio`                     string               comment 'financing rate(Mode 1 :Advance Ratio,Model 3 :Customer Ratio'
		,`grace_period`                      string               comment 'Grace Period'
		,`processing_fee`                    string               comment 'Processing Fee'
		,`remark`                            string               comment 'remark                                                '
		,`create_by`                         string               comment 'creator id'
		,`create_by_name`                    string               comment 'creator name '
		,`create_time`                       timestamp            comment 'create time'
		,`update_by`                         string               comment 'updator id '
		,`update_by_name`                    string               comment 'updator name '
		,`update_time`                       timestamp            comment 'update time '
) comment 'Financing calculation parameter table'
partitioned by(data_date string)  
stored as parquet
;


insert overwrite table  dw_uat.dw_olea_cust_olea_financing_calculate_param partition(data_date='${hiveconf:DATA_DATE}')
select
		`id`                               
		,`financing_id`                     
		,`financing_program_id`             
		,`nominal_rate`                     
		,`overdue_rate`                     
		,`advance_ratio`                    
		,`grace_period`                     
		,`processing_fee`                   
		,`remark`                           
		,`create_by`                        
		,`create_by_name`                   
		,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
		,`update_by`                        
		,`update_by_name`                   
		,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
		,financing_ratio
		,customer_rate  
from ods.ods_olea_cust_olea_financing_calculate_param
;