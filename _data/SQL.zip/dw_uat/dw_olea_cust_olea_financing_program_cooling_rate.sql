CREATE TABLE if not exists dw_uat.dw_olea_cust_olea_financing_program_cooling_rate 
(
   financing_program_id int         COMMENT '融资项目ID'
  ,buyer_entity 		string      COMMENT 'Buyer Entity'
  ,goods_description 	string 		COMMENT 'Goods Description'
  ,from_start_date_type string      COMMENT '统计期限开始日期类型'
  ,to_days 				int 	    COMMENT 'to 日期间隔'
  ,to_cal_type 			string 	COMMENT 'to 日期计算模式（Calendar Days）'
  ,to_direction 		string 	COMMENT 'to 期限计算方向（before/after）'
  ,to_start_date_type   string  COMMENT 'to 起始日期类型'
  ,cooling_rate 		double 	COMMENT '手动输入的cooling Rate'
  ,create_by 			int   	COMMENT '创建人userId'
  ,create_by_name 		string 	COMMENT '创建人'
  ,create_time 			timestamp     COMMENT '创建时间'
  ,update_by 			int   	 	  COMMENT '更新人userId'
  ,update_by_name 		string   	  COMMENT '更新人'
  ,update_time 			timestamp  	  COMMENT '最后更新时间'
) COMMENT '融资项目 Cooling Rate'
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_program_cooling_rate  partition(data_date='${hiveconf:DATA_DATE}')
select  
    financing_program_id
   ,buyer_entity 		
   ,goods_description 	
   ,from_start_date_type
   ,to_days 				
   ,to_cal_type 			
   ,to_direction 		
   ,to_start_date_type  
   ,cooling_rate 		
   ,create_by 			
   ,create_by_name 		
   ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 			
   ,update_by 			
   ,update_by_name 		
   ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
 from ods.ods_olea_cust_olea_financing_program_cooling_rate
 ;
   