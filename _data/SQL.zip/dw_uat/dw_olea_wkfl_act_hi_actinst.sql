--drop table if exists dw_uat.dw_olea_wkfl_act_hi_actinst;
create table if not exists dw_uat.dw_olea_wkfl_act_hi_actinst
(`ID_`                               string               comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`ACT_ID_`                           string               comment '                                                  '
,`TASK_ID_`                          string               comment '                                                  '
,`CALL_PROC_INST_ID_`                string               comment '                                                  '
,`ACT_NAME_`                         string               comment '                                                  '
,`ACT_TYPE_`                         string               comment '                                                  '
,`ASSIGNEE_`                         string               comment '                                                  '
,`START_TIME_`                       timestamp            comment '                                                  '
,`END_TIME_`                         timestamp            comment '                                                  '
,`DURATION_`                         string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_hi_actinst partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`PROC_DEF_ID_`                     
,`PROC_INST_ID_`                    
,`EXECUTION_ID_`                    
,`ACT_ID_`                          
,`TASK_ID_`                         
,`CALL_PROC_INST_ID_`               
,`ACT_NAME_`                        
,`ACT_TYPE_`                        
,`ASSIGNEE_`                        
,nvl(from_unixtime(cast(`START_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`START_TIME_`) as START_TIME_
,nvl(from_unixtime(cast(`END_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`END_TIME_`) as END_TIME_
,`DURATION_`                        
,`TENANT_ID_`                       

from ods.ods_olea_wkfl_act_hi_actinst;