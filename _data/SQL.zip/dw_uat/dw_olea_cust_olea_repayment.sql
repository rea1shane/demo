--alter table dw_uat.dw_olea_cust_olea_repayment     			  add columns (tpp_invoice_fee  			    double  comment'TPP Invoice Fee');
--alter table dw_uat.dw_olea_cust_olea_repayment     			  add columns (tpp_adjustment   			    double  comment'TPP Invoice Fee Adjustment');

--202202新增
--alter table dw_uat.dw_olea_cust_olea_repayment add columns(extension_id string comment'关联的extension id');
--alter table dw_uat.dw_olea_cust_olea_repayment add columns(type 		 string comment'回款类型');


--202201新增
--alter table dw_uat.dw_olea_cust_olea_repayment add columns(expected_excess_amount double comment'expected_excess_amount')
--alter table dw_uat.dw_olea_cust_olea_repayment  change   actual_received_date   actual_received_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_repayment  change   create_time   create_time timstamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_repayment  change   update_time   update_time  timstamp      comment'' ;

create table if not exists dw_uat.dw_olea_cust_olea_repayment
 (
    id                          string comment ''
   ,repayment_id                string comment 'repayment ID'
   ,payment_id                  string comment 'payment ID'
   ,financing_id                string comment 'financing ID'
   ,repayment_package_id        string comment 'repayment package ID'
   ,payment_ref_no              string comment 'payment reference No.'
   ,repayment_status            string comment 'repayment status'
   ,estimated_received_amount   string comment 'estimated received amount'
   ,actual_received_amount      string comment 'actual received amount'
   ,repayment_shortage          string comment 'repayment shortage'
   ,actual_received_date        string comment 'actual received date'
   ,intermediary_bank_fees      string comment 'intermediary bank fees'
 --,document_upload_status      string comment 'document upload status'
   ,remark                      string comment 'remark'
   ,create_by                   string comment 'id of the person who created'
   ,create_by_name              string comment 'name of the person who created'
   ,update_by                   string comment 'id of the person who updated'
   ,update_by_name              string comment 'name of the person who updated'
   ,create_time                 string comment ''
   ,update_time                 string comment ''
)partitioned by (data_date string)
stored as parquet;

insert overwrite table dw_uat.dw_olea_cust_olea_repayment partition(data_date='${hiveconf:DATA_DATE}')
select 
        id                        
       ,repayment_id              
       ,payment_id                
       ,financing_id              
       ,repayment_package_id      
       ,payment_ref_no            
       ,repayment_status          
       ,estimated_received_amount 
       ,actual_received_amount    
       ,repayment_shortage        
       ,from_unixtime(cast(actual_received_date/1000 as bigint),'yyyy-MM-dd')  as actual_received_date      
       ,intermediary_bank_fees     
       ,remark                    
       ,create_by                 
       ,create_by_name            
       ,update_by                 
       ,update_by_name            
       ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time              
       ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time
	   ,expected_excess_amount	   
	   ,extension_id
	   ,`type` 	
       ,tpp_invoice_fee
	   ,tpp_adjustment
       ,outstanding_amount	
       ,days_late	 
	   ,overdue_type	
	   ,partner_fee_payment_type
	   ,overdue_id 
	   ,days_late_imd
from ods.ods_olea_cust_olea_repayment	 
; 
