--drop table if exists dw_uat.dw_olea_cust_olea_autocheck_column_record;
create table if not exists dw_uat.dw_olea_cust_olea_autocheck_column_record
(`id`                                string               comment '                                                  '
,`company_id`                        string               comment 'company id  '
,`field`                             string               comment 'check field  '
,`type`                              string               comment 'check type  '
,`display`                           string               comment 'the content displayed on the page '
,`auto_result`                       string               comment 'auto check result   '
,`manual_result`                     string               comment 'manual check result  '
,`updator`                           string               comment 'updator id '
,`comment`                           string               comment 'check comment '
,`check_date`                        timestamp            comment 'check date '
,`case_system_id`                    string               comment '   '
,`none_of_above`                     string               comment '   '
,`entity_type`                       string               comment '   '
,`ubo_type`                          string               comment '  '
,`ubo_id`                            string               comment '  '
,`order_num`                         string               comment '  '
,`remark`                            string               comment 'remark '
,`create_time`                       timestamp            comment 'create time   '
,`create_by`                         string               comment '   '
,`update_time`                       timestamp            comment 'update time  '
,`update_by`                         string               comment '    '
) comment 'Enterprise Automation Check Field Results'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_autocheck_column_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`company_id`                       
,`field`                            
,`type`                             
,`display`                          
,`auto_result`                      
,`manual_result`                    
,`updator`                          
,`comment`                          
,nvl(from_unixtime(cast(`check_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`check_date`) as check_date
,`case_system_id`                   
,`none_of_above`                    
,`entity_type`                      
,`ubo_type`                         
,`ubo_id`                           
,`order_num`                        
,`remark`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        
from ods.ods_olea_cust_olea_autocheck_column_record;