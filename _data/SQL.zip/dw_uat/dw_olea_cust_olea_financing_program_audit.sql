--alter table dw_uat.dw_olea_cust_olea_financing_program_audit   add columns (nominal_rate_type 	 			string  comment'名义利率类型：Fixed、Floating');
--alter table dw_uat.dw_olea_cust_olea_financing_program_audit   add columns (risk_free_rate_option 			string  comment'最低风险利率选项：TermsSofa');
--alter table dw_uat.dw_olea_cust_olea_financing_program_audit   add columns (overdue_agree_rate 			double  comment'逾期约定利率');
--alter table dw_uat.dw_olea_cust_olea_financing_program_audit   add columns (manual_input_nominal_rate        double  comment'手动输入的名义利率值');



--drop table if exists dw_uat.dw_olea_cust_olea_financing_program_audit;
create table if not exists dw_uat.dw_olea_cust_olea_financing_program_audit
(`id`                                string               comment '                                                  '
,`parent_id`                         string               comment '项目父编号                                             '
,`option_flag`                       string               comment '是否 amend 过                                        '
,`financing_program_id`              string               comment '主表id                                              '
,`program_no`                        string               comment '项目编号(Program Id)                                  '
,`program_no_version`                string               comment '项目编号版本号                                           '
,`app_no`                            string               comment '流程编号                                              '
,`check_status`                      string               comment '审核状态                                              '
,`program_status`                    string               comment '项目状态                                              '
,`supplier_id`                       string               comment '供应商id                                             '
,`supplier_name`                     string               comment '供应商名称 for front Supplier Name                     '
,`buyer_group_id`                    string               comment '买方集团id(buyer group id)                            '
,`buyer_group_name`                  string               comment '买方集团名称 for front Buyer Group Name                 '
,`supplier_third_party_id`           string               comment 'supplier_third_party_id                           '
,`buyer_group_third_party_id`        string               comment 'buyer_group_third_party_id                        '
,`third_party_platform`              string               comment '3方平台(Third party platform)                        '
,`product_type`                      string               comment '产品类型(Product Type)                                '
,`currency`                          string               comment '币种(Currency)                                      '
,`nominal_rate`                      string               comment '名义利率(Nominal Rate)                                '
,`overdue_rate`                      string               comment '逾期利率(Overdue Rate)                                '
,`advance_ratio`                     string               comment '进速比(Advance Ratio)                                '
,`grace_period`                      string               comment '宽限期(Grace Period)                                 '
,`payment_instruction`               string               comment '支付指令(Payment Instruction)                         '
,`processing_fee`                    string               comment '手续费(Processing Fee)                               '
,`remark`                            string               comment 'upload                                            '
,`expiry_date`                       date                 comment '到期日                                               '
,`effective_date`                    date                 comment '生效日期                                              '
,`termination_date`                  date                 comment '终止时间                                              '
,`termination_remarks`               string               comment '项目终止原因                                            '
,`enable`                            string               comment '是否生效                                              '
,`create_by`                         string               comment '创建人userId                                         '
,`create_by_name`                    string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人userId                                         '
,`update_by_name`                    string               comment '更新人                                               '
,`update_time`                       timestamp            comment '最后更新时间                                            '
) comment '资产项目流程审核表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_financing_program_audit partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`parent_id`                        
,`option_flag`                      
,`financing_program_id`             
,`program_no`                       
,`program_no_version`               
,`app_no`                           
,`check_status`                     
,`program_status`                   
,`supplier_id`                      
,`supplier_name`                    
,`buyer_group_id`                   
,`buyer_group_name`                 
,`supplier_third_party_id`          
,`buyer_group_third_party_id`       
,`third_party_platform`             
,`product_type`                     
,`currency`                         
,`nominal_rate`                     
,`overdue_rate`                     
,`advance_ratio`                    
,`grace_period`                     
,`payment_instruction`              
,`processing_fee`                   
,`remark`                           
,nvl(from_unixtime(cast(`expiry_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`expiry_date`) as expiry_date
,nvl(from_unixtime(cast(`effective_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`effective_date`) as effective_date
,nvl(from_unixtime(cast(`termination_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`termination_date`) as termination_date
,`termination_remarks`              
,`enable`                           
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,nominal_rate_type 	 		
,risk_free_rate_option 		
,overdue_agree_rate 		
,manual_input_nominal_rate
,goods_code
,required_documents
,project_code 
,unfunded_invoice
,unfunded_invoice_processing_fee   
,selected_buyergp_id   
,min_payment_terms_days
,max_payment_terms_days
,payment_terms       
,min_advance_ratio
,cost_to_distribution  
,post_trade 
,buyer_program_type
,insurance_applied 
,unfunded_type
,unfunded_required_documents 
from ods.ods_olea_cust_olea_financing_program_audit
;