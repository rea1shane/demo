--drop table if exists dw_uat.dw_olea_wkfl_wkfl_appno_seq;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_appno_seq
(`id`                                string               comment '                                                  '
,`seq`                               string               comment '申请编号序列                                            '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_appno_seq partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`seq`                              

from ods.ods_olea_wkfl_wkfl_appno_seq;