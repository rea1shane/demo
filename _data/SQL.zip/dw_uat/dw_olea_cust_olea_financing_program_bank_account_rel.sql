create table if not exists dw_uat.dw_olea_cust_olea_financing_program_bank_account_rel
( 	
	 id 				 		   string  	  comment '唯一主键，自增雪花id'
    ,app_no 					   string  	  comment '流程编号'
	,financing_program_id   	   string     comment '融资项目ID link to olea_financing_program.id'
	,account_id 				   string  	  comment '账户ID link to olea_bank_account.id'
	,default_account 			   string  	  comment '是否为供应商默认账户'
	,create_by 				   	   string     comment '创建人userid'
	,create_by_name 			   string     comment '创建人'
	,create_time   			   	   timestamp  comment '创建时间'
	,update_by 				   	   string  	  comment '更新人userid'
	,update_by_name    		   	   string     comment '更新人'
	,update_time 			   	   timestamp  comment '更新时间'
)
comment '融资项目与账户关联表'
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_program_bank_account_rel  partition(data_date='${hiveconf:DATA_DATE}')
select 
	  id 				 	
     ,app_no 				
     ,financing_program_id   
     ,account_id 			
     ,default_account 				
     ,create_by                          
     ,create_by_name                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                        
     ,update_by                          
     ,update_by_name                     
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time   
  from ods.ods_olea_cust_olea_financing_program_bank_account_rel
;










