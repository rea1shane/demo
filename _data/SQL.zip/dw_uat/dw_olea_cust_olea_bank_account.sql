--alter table dw_uat.dw_olea_cust_olea_bank_account add columns(participant_id     string comment'参与者Id');
--alter table dw_uat.dw_olea_cust_olea_bank_account add columns(scb_onboard_status string comment'account建档状态:NA、Pending、Completed');


create table if not exists dw_uat.dw_olea_cust_olea_bank_account
(
    id                          bigint            comment ''
   ,program_id                  bigint            comment 'program ID'
   ,dd_state                    string            comment 'duel diligence state'
   ,company_id                  bigint            comment 'company ID'
   ,bank_type                   string            comment 'bank type'
   ,account_name                string            comment 'account name'
   ,account_currency            string            comment 'account currency'
   ,account_no                  string            comment 'account No.'
   ,bank_swift_code             string            comment 'bank swift code'
   ,bank_address                string            comment 'bank address'
   ,bank_name                   string            comment 'bank name'
   ,intermediary_swift_code     string            comment 'intermediary swift code'
   ,transfer_amount             decimal(20,8)     comment 'transfer amount'
   ,withdraw_amount             decimal(20,8)     comment 'withdraw amount'
   ,funded_amount               decimal(20,8)     comment 'funded amount'
   ,total_balance               decimal(20,8)     comment 'total balance'
   ,frozen_amount               decimal(20,8)     comment 'frozen amount'
   ,available_balance           decimal(20,8)     comment 'available balance'
   ,bank_branch                 string            comment 'bank branch'
   ,enable                      string            comment 'enable'
   ,create_by                   bigint            comment 'id of the person who created'
   ,create_by_name              string            comment 'name of the person who created'
   ,create_time                 string            comment 'create time'
   ,update_by                   bigint            comment 'id of the person who updated'
   ,update_by_name              string            comment 'name of the person who updated'
   ,update_time                 string            comment 'update time'
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_cust_olea_bank_account  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_bank_account  change   update_time   update_time  timestamp      comment'' ;


insert overwrite table dw_uat.dw_olea_cust_olea_bank_account partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                      
     ,program_id              
     ,dd_state                
     ,company_id              
     ,bank_type               
     ,account_name            
     ,account_currency        
     ,account_no              
     ,bank_swift_code         
     ,bank_address            
     ,bank_name               
     ,intermediary_swift_code 
     ,transfer_amount         
     ,withdraw_amount         
     ,funded_amount           
     ,total_balance           
     ,frozen_amount           
     ,available_balance       
     ,bank_branch             
     ,enable                  
     ,create_by               
     ,create_by_name          
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time       
     ,update_by               
     ,update_by_name  
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
		 ,participant_id    
		 ,scb_onboard_status
		 ,remark
		 ,utilised_amount
		 ,ffc_account_name
		 ,ffc_account_no
 from ods.ods_olea_cust_olea_bank_account
 ;
