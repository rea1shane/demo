--drop table if exists dw_uat.dw_olea_cust_olea_financing_request_record;
create table if not exists dw_uat.dw_olea_cust_olea_financing_request_record
(`id`                                string               comment '                                                  '
,`file_name`                         string               comment '文件名                                               '
,`file_path`                         string               comment '文件路径                                              '
,`type`                              string               comment '导入类型                                              '
,`total_number`                      string               comment '关联资产笔数                                            '
,`success_number`                    string               comment '导入成功资产笔数                                          '
,`fail_number`                       string               comment '导入成功资产笔数                                          '
,`uploaded_result`                   string               comment '导入结果                                              '
,`fail_reason`                       string               comment '导入结果                                              '
,`remark`                            string               comment '备注                                                '
,`create_by`                         string               comment '创建人                                               '
,`create_by_name`                    string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '修改人                                               '
,`update_by_name`                    string               comment '创建人                                               '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment '融资导入记录表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_financing_request_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`file_name`                        
,`file_path`                        
,`type`                             
,`total_number`                     
,`success_number`                   
,`fail_number`                      
,`uploaded_result`                  
,`fail_reason`                      
,`remark`                           
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,source
from ods.ods_olea_cust_olea_financing_request_record;