--drop table if exists dw_uat.dw_olea_wkfl_act_id_user;
create table if not exists dw_uat.dw_olea_wkfl_act_id_user
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`FIRST_`                            string               comment '                                                  '
,`LAST_`                             string               comment '                                                  '
,`EMAIL_`                            string               comment '                                                  '
,`PWD_`                              string               comment '                                                  '
,`PICTURE_ID_`                       string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_id_user partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`FIRST_`                           
,`LAST_`                            
,`EMAIL_`                           
,`PWD_`                             
,`PICTURE_ID_`                      

from ods.ods_olea_wkfl_act_id_user;