--drop table if exists dw_uat.dw_olea_pub_pub_dynamics_bank_info;
create table if not exists dw_uat.dw_olea_pub_pub_dynamics_bank_info
(`id`                                string               comment '                                                  '
,`bank_account_name`                 string               comment '银行账户名称                                            '
,`bank_account_no`                   string               comment '银行账户号                                             '
,`currency_code`                     string               comment '币种code                                            '
,`bank_account_posting_group_name`   string               comment '投递组名称                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment 'dynamics 银行信息表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_pub_dynamics_bank_info partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`bank_account_name`                
,`bank_account_no`                  
,`currency_code`                    
,`bank_account_posting_group_name`  
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_pub_pub_dynamics_bank_info;