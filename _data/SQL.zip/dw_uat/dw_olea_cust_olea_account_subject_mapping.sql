create table if not exists dw_uat.dw_olea_cust_olea_account_subject_mapping
(
 id      			    string      comment''
 ,subject_name    string      comment'subject name'
 ,subject_no	    string      comment'subject no'
 ,create_by 	    string      comment'creator id'
 ,update_by 	    string      comment'updater id'
 ,create_time     TIMESTAMP   comment'create time'
 ,update_time     TIMESTAMP   comment'update time'
)
COMMENT'转账科目映射表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_account_subject_mapping partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id 						
	,subject_name
	,subject_no	
	,create_by 	
	,update_by 	  			    
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 			    
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 		
	,currency
	,ori_subject_no
	,account_no
	,participant_id
from ods.ods_olea_cust_olea_account_subject_mapping
;