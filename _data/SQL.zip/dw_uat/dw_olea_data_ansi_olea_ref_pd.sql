--alter table dw_uat.dw_olea_data_ansi_olea_ref_pd  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_pd  change   create_time   create_time timestamp      comment'' ;


create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_pd
(
	id				    string  comment ''	
   ,rating_grade	 	string  comment 'rating_grade   '
   ,rank			    string  comment 'rank           '
   ,rating_band		    string  comment 'rating_band    '
   ,pd				 	string  comment 'pd             '
   ,lbound			 	string  comment 'lbound         '
   ,ubound			 	string  comment 'ubound         '
   ,rating_source	 	string  comment 'RatingSource   '
   ,update_date		 	string  comment 'update_date    '
   ,create_by		 	string  comment ''
   ,create_time		    string  comment ''
  )partitioned by (data_date string)
stored as parquet;

 
insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_pd partition(data_date='${hiveconf:DATA_DATE}')
select 	id				
      ,rating_grade	
      ,rank			
      ,rating_band		
      ,pd				
      ,lbound			
      ,ubound			
      ,rating_source	
      ,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date		
      ,create_by		
      ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time		
  from ods.ods_olea_data_ansi_olea_ref_pd
; 
           
                         