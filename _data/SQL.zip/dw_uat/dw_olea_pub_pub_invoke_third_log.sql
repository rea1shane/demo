--drop table if exists dw_uat.dw_olea_pub_pub_invoke_third_log;
create table if not exists dw_uat.dw_olea_pub_pub_invoke_third_log
(`id`                                string               comment '                                                  '
,`url`                               string               comment '请求路径                                              '
,`sys_id`                            string               comment '系统id                                              '
,`type`                              string               comment '请求类别POST,GET,RPC                                  '
,`request`                           string               comment '请求参数                                              '
,`status`                            string               comment '请求状态                                              '
,`response`                          string               comment '返回值                                               '
,`error_msg`                         string               comment '异常信息                                              '
,`cost_time`                         string               comment '耗费时间                                              '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '更新时间                                              '
,`remark`                            string               comment '备注                                                '
) comment '调用其他系统日志'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_pub_invoke_third_log partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`url`                              
,`sys_id`                           
,`type`                             
,`request`                          
,`status`                           
,`response`                         
,`error_msg`                        
,`cost_time`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`remark`                           

from ods.ods_olea_pub_pub_invoke_third_log;