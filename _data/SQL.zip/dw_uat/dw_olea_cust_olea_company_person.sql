
create table if not exists dw_uat.dw_olea_cust_olea_company_person
( 
   id                   string  comment ''
  ,company_id           string  comment ''
  ,company_type         string  comment ''
  ,`type`               string  comment ''
  ,sys_user_id          string  comment ''
  ,email_address        string  comment ''
  ,busi_key             string  comment ''
  ,name                 string  comment ''
  ,first_name           string  comment ''
  ,last_name            string  comment ''
  ,first_name_local     string  comment ''
  ,last_name_local      string  comment ''
  ,nationality          string  comment ''
  ,nationality_name     string  comment ''
  ,residency            string  comment ''
  ,id_type              string  comment ''
  ,id_no                string  comment ''
  ,birth_date           string  comment ''
  ,mobile_prefix        string  comment ''
  ,mobile_number        string  comment ''
  ,equals_legal         string  comment ''
  ,send_email_flag      string  comment ''
  ,sign_flag            string  comment ''
  ,designation          string  comment ''
  ,create_time          string  comment ''
  ,update_time          string  comment ''
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_cust_olea_company_person  add  columns (group_key  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_company_person  add  columns (related_person_id  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_company_person  add  columns (related_person_name  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_company_person  change   birth_date   birth_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_company_person  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_company_person  change   update_time   update_time  timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_cust_olea_company_person  partition(data_date='${hiveconf:DATA_DATE}')
 select 
       id                
      ,company_id        
      ,company_type      
      ,`type`            
      ,sys_user_id       
      ,email_address     
      ,busi_key          
      ,name              
      ,first_name        
      ,last_name         
      ,first_name_local  
      ,last_name_local   
      ,nationality       
      ,nationality_name  
      ,residential_country  as  residency  
      ,id_type           
      ,id_no             
      ,from_unixtime(cast(birth_date/1000 as bigint),'yyyy-MM-dd') as birth_date        
      ,mobile_prefix     
      ,mobile_number     
      ,equals_legal      
      ,send_email_flag   
      ,sign_flag         
      ,designation       
      ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time       
      ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
      ,group_key
      ,related_person_id	
      ,related_person_name
      ,role_option_flag
      ,role_value
	  ,country_of_tax_residence
	  ,residential_city
	  ,residential_address
  from ods.ods_olea_cust_olea_company_person 	 a 
;