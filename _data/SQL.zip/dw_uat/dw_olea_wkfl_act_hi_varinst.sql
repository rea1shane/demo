--drop table if exists dw_uat.dw_olea_wkfl_act_hi_varinst;
create table if not exists dw_uat.dw_olea_wkfl_act_hi_varinst
(`ID_`                               string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`TASK_ID_`                          string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`VAR_TYPE_`                         string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`BYTEARRAY_ID_`                     string               comment '                                                  '
,`DOUBLE_`                           string               comment '                                                  '
,`LONG_`                             string               comment '                                                  '
,`TEXT_`                             string               comment '                                                  '
,`TEXT2_`                            string               comment '                                                  '
,`CREATE_TIME_`                      timestamp            comment '                                                  '
,`LAST_UPDATED_TIME_`                timestamp            comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_hi_varinst partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`PROC_INST_ID_`                    
,`EXECUTION_ID_`                    
,`TASK_ID_`                         
,`NAME_`                            
,`VAR_TYPE_`                        
,`REV_`                             
,`BYTEARRAY_ID_`                    
,`DOUBLE_`                          
,`LONG_`                            
,`TEXT_`                            
,`TEXT2_`                           
,nvl(from_unixtime(cast(`CREATE_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`CREATE_TIME_`) as CREATE_TIME_
,nvl(from_unixtime(cast(`LAST_UPDATED_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`LAST_UPDATED_TIME_`) as LAST_UPDATED_TIME_

from ods.ods_olea_wkfl_act_hi_varinst;