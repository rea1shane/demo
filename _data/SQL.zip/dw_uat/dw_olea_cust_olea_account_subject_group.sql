--alter table dw_uat.dw_olea_cust_olea_account_subject_group add columns(remark  string comment'注释'); 

--drop table if exists dw_uat.dw_olea_cust_olea_account_subject_group;
create table if not exists dw_uat.dw_olea_cust_olea_account_subject_group
(`id`                                string               comment 'primary key id'
,`group_type`                        string               comment 'grouping type'
,`step_id`                           string               comment 'step id'
,`direction`                         string               comment 'Borrowing direction'
,`sort_id`                           string               comment 'sorting id'
,`subject_no`                        string               comment 'subject NO. '
,`subject_name`                      string               comment 'subject name' 
,`create_by`                         string               comment 'creator id   '
,`create_time`                       timestamp            comment 'create time  '
,`update_by`                         string               comment 'updater ID  '
,`update_time`                       timestamp            comment 'update time  '
) comment 'Accounting subject grouping table'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_account_subject_group partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`group_type`                       
,`step_id`                          
,`direction`                        
,`sort_id`                          
,`subject_no`                       
,`subject_name`                     
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,remark
,unique_key
from ods.ods_olea_cust_olea_account_subject_group;