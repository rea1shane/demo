--drop table if exists dw_uat.dw_olea_cust_olea_third_platform_contact;
create table if not exists dw_uat.dw_olea_cust_olea_third_platform_contact
(`id`                                string               comment '                                                  '
,`platform_id`                       string               comment '平台id                                              '
,`first_name`                        string               comment 'first_name                                        '
,`last_name`                         string               comment 'last_name                                         '
,`full_name`                         string               comment '全名                                                '
,`mobile_prefix`                     string               comment '手机号前缀                                             '
,`mobile_number`                     string               comment '手机号                                               '
,`full_mobile_number`                string               comment '手机号（包括前缀）                                         '
,`email`                             string               comment '邮箱地址                                              '
,`department`                        string               comment '部门                                                '
,`title`                             string               comment '职位                                                '
,`create_by`                         string               comment '创建人userId                                         '
,`create_by_name`                    string               comment '创建人                                               '
,`create_time`                       timestamp            comment '                                                  '
,`update_by`                         string               comment '更新人userId                                         '
,`update_by_name`                    string               comment '更新人                                               '
,`update_time`                       timestamp            comment '                                                  '
) comment '第三方平台联系人表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_third_platform_contact partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`platform_id`                      
,`first_name`                       
,`last_name`                        
,`full_name`                        
,`mobile_prefix`                    
,`mobile_number`                    
,`full_mobile_number`               
,`email`                            
,`department`                       
,`title`                            
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_third_platform_contact;