CREATE table if not exists dw_uat.dw_olea_cust_olea_funder_audit
(
    `id`                               int    	comment 'primary key id' 
   ,`company_id`                       int    	comment 'id of the company ' 
   ,`app_no`                           string  	comment 'process NO. get after workflow submit' 
   ,`funder_type`                      string   comment 'Fund Manager/Fund' 
   ,`fund_manager_id`                  int    	comment 'Fund Manager id' 
   ,`parent_entity_name`               string  	comment 'Parent Entity Name' 
   ,`parent_entity_type`               string   comment 'Publicly Listed/Financial Institution/Privately Owned' 
   ,`parent_entity_publicly_listed_on` string   comment 'Parent Entity Publicly Listed On' 
   ,`parent_entity_regulated_market`   string   comment 'Yes/No' 
   ,`parent_country_of_registration`   string  	comment 'The selection range is a list of country names' 
   ,`master_fund_entity_name`          string  	comment 'Required only if Client Setting-Funder Type=Fund' 
   ,`legal_entity_id_number`           string   comment 'Required only if Client Setting-Funder Type=Fund' 
   ,`create_by`                        int    	comment 'creator id' 
   ,`create_by_name`                   string   comment 'creator name' 
   ,`create_time`                      TIMESTAMP    comment 'create time' 
   ,`update_by`                        int   	 	comment 'updator id' 
   ,`update_by_name`                   string   	comment 'updator name' 
   ,`update_time`                      TIMESTAMP    comment 'update time' 
)comment 'Investor extended information review records'
partitioned by (data_date string)                   
stored as parquet
;
insert overwrite table dw_uat.dw_olea_cust_olea_funder_audit partition (data_date='${hiveconf:DATA_DATE}')
  select `id`                               
       ,`company_id`                       
       ,`app_no`                           
       ,`funder_type`                      
       ,`fund_manager_id`                  
       ,`parent_entity_name`               
       ,`parent_entity_type`               
       ,`parent_entity_publicly_listed_on` 
       ,`parent_entity_regulated_market`   
       ,`parent_country_of_registration`   
       ,`master_fund_entity_name`          
       ,`legal_entity_id_number`           
       ,`create_by`                        
       ,`create_by_name`                   
       ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as `create_time`                      
       ,`update_by`                        
       ,`update_by_name`                   
       ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as `update_time`  
       ,parent_country_of_operating                    
    from ods.ods_olea_cust_olea_funder_audit a 
 ;