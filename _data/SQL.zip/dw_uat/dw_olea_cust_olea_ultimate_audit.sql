create table if not exists dw_uat.dw_olea_cust_olea_ultimate_audit
(
  id                        string  comment ''
 ,company_id                string  comment 'relevant company id'
 ,ultimate_id               string  comment 'olea_ultimate id'
 ,audit_id                  string  comment 'id of company audit '
 ,app_no                    string  comment 'application id'
 ,first_name                string  comment 'first name'
 ,last_name                 string  comment 'last name'
 ,gender                    string  comment 'gender'
 ,date_of_birth             string  comment 'date of birth'
 ,nationality               string  comment 'nationality'
 ,country_of_residency      string  comment 'country of residency'
 ,city_of_residency         string  comment 'city of residency'
 ,street_of_residency       string  comment ''
 ,country_of_birth          string  comment 'country of birth'
 ,city_of_birth             string  comment 'city of birth'
 ,tax_idt_number            string  comment 'tax identification number'
 ,country_of_tax            string  comment 'country of tax'
 ,entity_id                 string  comment 'entity_id'
 ,enable                    string  comment ''
 ,create_by                 string  comment 'id of the person who created'
 ,create_time               string  comment 'create time'
 ,update_by                 string  comment 'id of the person who updated'
 ,update_time               string  comment 'update time'
)partitioned by (data_date string)
stored as parquet;

insert overwrite table dw_uat.dw_olea_cust_olea_ultimate_audit partition(data_date='${hiveconf:DATA_DATE}')
	select 
	    id                     
	   ,company_id             
	   ,ultimate_id            
	   ,audit_id               
	   ,app_no                 
	   ,first_name             
	   ,last_name              
       ,gender                 
       ,from_unixtime(cast(date_of_birth/1000 as bigint),'yyyy-MM-dd') as date_of_birth          
       ,nationality            
       ,country_of_residency   
       ,city_of_residency      
       ,street_of_residency    
       ,country_of_birth       
       ,city_of_birth          
       ,tax_idt_number         
       ,country_of_tax         
       ,entity_id              
       ,enable                 
       ,create_by              
       ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time            
       ,update_by              
       ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time   
	   ,related_person_name
	   ,id_type
	   ,id_no
	   ,group_key
	   ,related_person_id
	   ,first_name_local
	   ,last_name_local
	   ,designation
	   ,shareholdings_percentage
	   ,email_address
	   ,mobile_prefix
	   ,mobile_number
   from ods.ods_olea_cust_olea_ultimate_audit
  ;

