--drop table if exists dw_uat.dw_olea_ledger_ledger_subject_map;
create table if not exists dw_uat.dw_olea_ledger_ledger_subject_map
(`id`                                string               comment '物理主键                                              '
,`las_subject_no`                    string               comment '科目号                                               '
,`tree_id`                           string               comment '树排序号                                              '
,`attribute_expression`              string               comment '匹配属性                                              '
,`fin_subject_no`                    string               comment 'fin财务科目                                           '
,`has_sub_node`                      string               comment '是否有子节点,FALSE:没有,TRUE:有                            '
,`enable`                            string               comment '启用/删除状态：0-禁用/删除，1-启用/正常                           '
,`remark`                            string               comment '                                                  '
,`create_by`                         string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人                                               '
,`update_time`                       timestamp            comment '更新时间                                              '
) comment '科目映射配置表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_ledger_ledger_subject_map partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`las_subject_no`                   
,`tree_id`                          
,`attribute_expression`             
,`fin_subject_no`                   
,`has_sub_node`                     
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_ledger_ledger_subject_map;