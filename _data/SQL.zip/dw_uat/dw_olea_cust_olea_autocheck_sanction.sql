create table if not exists dw_uat.dw_olea_cust_olea_autocheck_sanction
(
   id                string  comment ''
  ,record_id         string  comment 'olea_autocheck_column_record.id'
  ,code              string  comment 'sanction code'
  ,description       string  comment 'description'
  ,country           string  comment 'country'
  ,remark            string  comment 'remark'
  ,create_time       string  comment 'create time'
  ,create_by         string  comment ''
  ,update_time       string  comment 'update time'
  ,update_by         string  comment ''
 )partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_cust_olea_autocheck_sanction  add  columns (app_no  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_autocheck_sanction  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_autocheck_sanction  change   update_time   update_time  timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_cust_olea_autocheck_sanction partition(data_date='${hiveconf:DATA_DATE}')
 select 
      id             
     ,record_id      
     ,code           
     ,description    
     ,country        
     ,remark         
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time    
     ,create_by      
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time    
     ,update_by  
	 ,app_no
  from ods.ods_olea_cust_olea_autocheck_sanction 
;