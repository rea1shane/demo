--alter table dw_uat.dw_olea_data_ansi_olea_supplier_disc_mapping  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_supplier_disc_mapping  change   create_time   create_time timestamp      comment'' ;

create table if not exists dw_uat.dw_olea_data_ansi_olea_supplier_disc_mapping
(
    id                            	    string  comment 'id'
   ,buyr_group_id                       string  comment 'BuyrGroupID'
   ,buyr_country_code                   string  comment 'BuyrCountryCode'
   ,supr_country_code                   string  comment 'SuprCountryCode'
   ,supr_buyr_disc_rate                 string  comment 'SuprBuyrDiscRate'
   ,update_date                         string  comment 'update_date'
   ,create_time                         string  comment 'update_by'
   ,create_by                           string  comment  'create_by'
)partitioned by (data_date string)
stored as parquet;



insert overwrite table dw_uat.dw_olea_data_ansi_olea_supplier_disc_mapping partition(data_date='${hiveconf:DATA_DATE}')
 select 
	  id				
	 ,buyr_group_id     	   as  buyr_group_id         
	 ,buyr_country_code        as  buyr_country_code 
	 ,supr_country_code        as  supr_country_code 
	 ,supr_buyr_disc_rate      as  supr_buyr_discrate
	 ,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd')  as update_date  
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time    
	 ,create_by			
 from ods.ods_olea_data_ansi_olea_supplier_disc_mapping
;








