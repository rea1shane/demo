--drop table if exists dw_uat.dw_olea_cust_olea_company_person_audit;
create table if not exists dw_uat.dw_olea_cust_olea_company_person_audit
(`id`                                string               comment '         '
,`company_id`                        string               comment 'company id'
,`source_person_id`                  string               comment 'Master data PesonId'
,`company_type`                      string               comment 'company type'
,`company_app_no`                    string               comment 'Company Workflow ID'
,`type`                              string               comment ' '
,`sys_user_id`                       string               comment 'sys user id '
,`name`                              string               comment 'user name  '
,`first_name`                        string               comment 'first_name  '
,`last_name`                         string               comment 'last_name   '
,`first_name_local`                  string               comment 'first_name_local '
,`last_name_local`                   string               comment 'last_name_local  '
,`nationality`                       string               comment 'nationality code '
,`nationality_name`                  string               comment 'nationality name '
,`residency`                         string               comment 'Country of Residence '
,`designation`                       string               comment 'designation '
,`id_type`                           string               comment 'type of certificate '
,`id_no`                             string               comment 'ID NO. '
,`birth_date`                        date                 comment 'birthday date '
,`mobile_number`                     string               comment 'mobile number  '
,`mobile_prefix`                     string               comment 'prefix mobile_number '
,`email_address`                     string               comment 'email address '
,`equals_legal`                      string               comment 'Whether it is a legal person '
,`sign_flag`                         string               comment 'Authorized signing logo, signed at login '
,`create_time`                       timestamp            comment '   '
,`update_time`                       timestamp            comment '    '
,`group_key`                         string               comment 'personnel group key'
,`related_person_id`                 string               comment 'Affiliate ID'
,`related_person_name`               string               comment 'Name of associated person '
) comment 'Enterprise Personnel Record Form'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_company_person_audit partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`company_id`                       
,`source_person_id`                 
,`company_type`                     
,`company_app_no`                   
,`type`                             
,`sys_user_id`                      
,`name`                             
,`first_name`                       
,`last_name`                        
,`first_name_local`                 
,`last_name_local`                  
,`nationality`                      
,`nationality_name`                 
,residential_country as `residency`                         
,`designation`                      
,`id_type`                          
,`id_no`                            
,nvl(from_unixtime(cast(`birth_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`birth_date`) as birth_date
,`mobile_number`                    
,`mobile_prefix`                    
,`email_address`                    
,`equals_legal`                     
,`sign_flag`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`group_key`                        
,`related_person_id`                
,`related_person_name`              
,role_option_flag
,role_value
,country_of_tax_residence
,residential_city
,residential_address
from ods.ods_olea_cust_olea_company_person_audit;