--drop table if exists dw_uat.dw_olea_cust_olea_financing_request_task;
create table if not exists dw_uat.dw_olea_cust_olea_financing_request_task
(`id`                                string               comment '                                                  '
,`financing_id`                      string               comment '融资ID                                              '
,`financing_ref_no`                  string               comment '融资编号                                              '
,`requested_amount`                  string               comment '申请金额                                              '
,`seller`                            string               comment '卖方                                                '
,`buyer`                             string               comment '买方                                                '
,`currency`                          string               comment '币种                                                '
,`invoice_no`                        string               comment '发票编号                                              '
,`status`                            string               comment '状态                                                '
,`create_time`                       timestamp            comment '创建时间                                              '
,`create_by`                         string               comment '创建人                                               '
,`create_by_name`                    string               comment '创建人                                               '
,`update_by`                         string               comment '修改人                                               '
,`update_by_name`                    string               comment '创建人                                               '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment '融资导入任务表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_financing_request_task partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`financing_id`                     
,`financing_ref_no`                 
,`requested_amount`                 
,`seller`                           
,`buyer`                            
,`currency`                         
,`invoice_no`                       
,`status`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,`create_by_name`                   
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,data_source
,project_code
from ods.ods_olea_cust_olea_financing_request_task;