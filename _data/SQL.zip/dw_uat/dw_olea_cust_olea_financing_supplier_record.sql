create table if not exists dw_uat.dw_olea_cust_olea_financing_supplier_record
( 
   id                              string      comment'发票表主键ID,自增雪花ID'
  ,app_no                          string      comment'流程编号ID'
  ,data_source                     string      comment'数据来源'
  ,name                            string      comment'excel名字'
  ,submission_status               string      comment'供应商端融资状态'
  ,financing_id                    string      comment'融资ID'
  ,supplier_id                     string      comment'供应商ID'
  ,package_id                      string      comment'同时上传或新增资产唯一标识'
  ,request_type                    string      comment'数据来源请求方式（内管新增，供应商上传或新增）'
  ,remark                          string      comment'备注'
  ,create_by                       string      comment'创建人'
  ,create_by_name                  string      comment'创建人名字'
  ,create_time                     timestamp   comment'创建时间'
  ,update_by                       string      comment'更新人'
  ,update_by_name                  string      comment'更新人名字'
  ,update_time                     timestamp   comment'更新时间'
 )
 COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_supplier_record partition(data_date='${hiveconf:DATA_DATE}')
select 
  id                              --发票表主键ID,自增雪花ID
  ,app_no                         --流程编号ID
  ,data_source                    --数据来源
  ,name                           --excel名字
  ,submission_status              --供应商端融资状态
  ,financing_id                   --融资ID
  ,supplier_id                    --供应商ID
  ,package_id
  ,request_type
  ,remark                         --备注
  ,create_by                      --创建人
  ,create_by_name                 --创建人名字
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time                    --创建时间
  ,update_by                      --更新人
  ,update_by_name                 --更新人名字
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time                    --更新时间
  ,project_code
  ,flow_status
  ,company_person_role_option
  ,type
from ods.ods_olea_cust_olea_financing_supplier_record 
;


















