--drop table if exists dw_uat.dw_olea_ledger_ledger_trade_config;
create table if not exists dw_uat.dw_olea_ledger_ledger_trade_config
(`id`                                string               comment '                                                  '
,`trade_code`                        string               comment '交易编码                                              '
,`trade_type`                        string               comment '交易类型                                              '
,`name`                              string               comment '配置名称                                              '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_by`                         string               comment '                                                  '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '                                                  '
,`update_time`                       timestamp            comment '更新时间                                              '
) comment '交易配置表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_ledger_ledger_trade_config partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`trade_code`                       
,`trade_type`                       
,`name`                             
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_ledger_ledger_trade_config;