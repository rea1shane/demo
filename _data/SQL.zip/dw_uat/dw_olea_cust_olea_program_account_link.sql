create table if not exists dw_uat.dw_olea_cust_olea_program_account_link
(
   id                bigint      comment 'primary key id' 
  ,program_id        bigint      comment 'olea_program.id' 
  ,account_id        bigint      comment 'olea_account.id' 
  ,is_default          string      comment 'Is it the default account' 
  ,create_by         bigint      comment 'creator id' 
  ,create_time       TIMESTAMP   comment 'create time' 
  ,update_by         bigint      comment 'updator id' 
  ,update_time       TIMESTAMP   comment 'update time'
)comment 'Investment Project Account Binding Form'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_program_account_link partition (data_date='${hiveconf:DATA_DATE}')
 select id            
       ,program_id    
       ,account_id    
       ,is_default      
       ,create_by     
       ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time   
       ,update_by     
       ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
  from ods.ods_olea_cust_olea_program_account_link	   
 ;