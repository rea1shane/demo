create table if not exists dw_uat.dw_olea_cust_olea_payment_package_records
(`id`                                string               comment '                                                 '
,`source_package_ids`                string               comment '源包id列表                                            '
,`target_package_id`                 string               comment '目标id                                              '
,`create_time`                       timestamp            comment '创建时间                                              '
,`create_by`                         string               comment '创建人                                               '
) comment '放款打包记录'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_payment_package_records partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`source_package_ids`               
,`target_package_id`                
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`         
,`type`               
from ods.ods_olea_cust_olea_payment_package_records;