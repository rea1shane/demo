--drop table if exists dw_uat.dw_olea_cust_olea_supplier_common_account;
create table if not exists dw_uat.dw_olea_cust_olea_supplier_common_account
(`id`                                string               comment '                                                  '
,`supplier_id`                       string               comment '供应商ID                                             '
,`account_name`                      string               comment '银行账户名称                                            '
,`account_no`                        string               comment '银行账号                                              '
,`swift_code`                        string               comment 'swift code                                        '
,`create_by`                         string               comment '创建人                                               '
,`create_by_name`                    string               comment '创建人名称                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '修改人                                               '
,`update_by_name`                    string               comment '修改人名称                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment '供应商常用账户表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_supplier_common_account partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`supplier_id`                      
,`account_name`                     
,`account_no`                       
,`swift_code`                       
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_supplier_common_account;