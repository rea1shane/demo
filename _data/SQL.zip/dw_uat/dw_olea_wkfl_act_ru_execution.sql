--drop table if exists dw_uat.dw_olea_wkfl_act_ru_execution;
create table if not exists dw_uat.dw_olea_wkfl_act_ru_execution
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`BUSINESS_KEY_`                     string               comment '                                                  '
,`PARENT_ID_`                        string               comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`SUPER_EXEC_`                       string               comment '                                                  '
,`ACT_ID_`                           string               comment '                                                  '
,`IS_ACTIVE_`                        string               comment '                                                  '
,`IS_CONCURRENT_`                    string               comment '                                                  '
,`IS_SCOPE_`                         string               comment '                                                  '
,`IS_EVENT_SCOPE_`                   string               comment '                                                  '
,`SUSPENSION_STATE_`                 string               comment '                                                  '
,`CACHED_ENT_STATE_`                 string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`LOCK_TIME_`                        timestamp            comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_ru_execution partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`PROC_INST_ID_`                    
,`BUSINESS_KEY_`                    
,`PARENT_ID_`                       
,`PROC_DEF_ID_`                     
,`SUPER_EXEC_`                      
,`ACT_ID_`                          
,`IS_ACTIVE_`                       
,`IS_CONCURRENT_`                   
,`IS_SCOPE_`                        
,`IS_EVENT_SCOPE_`                  
,`SUSPENSION_STATE_`                
,`CACHED_ENT_STATE_`                
,`TENANT_ID_`                       
,`NAME_`                            
,nvl(from_unixtime(cast(`LOCK_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`LOCK_TIME_`) as LOCK_TIME_

from ods.ods_olea_wkfl_act_ru_execution;