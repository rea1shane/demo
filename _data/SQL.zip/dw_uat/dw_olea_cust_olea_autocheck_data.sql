
create table if not exists dw_uat.dw_olea_cust_olea_autocheck_data
(
    id                  string  comment ''
   ,column_record_id    string  comment 'autocheck_column_record.id'
   ,olea_data           string  comment 'olea data'
   ,interface_data      string  comment 'interface_data'
   ,check_field         string  comment 'check columns field'
   ,result              string  comment 'check result'
   ,remark              string  comment 'remark'
   ,create_time         string  comment 'create time'
   ,create_by           string  comment ''
   ,update_time         string  comment 'update time'
   ,update_by           string  comment ''
)partitioned by(data_date string) 
stored as parquet
;
--alter table dw_uat.dw_olea_cust_olea_autocheck_data  add  columns (app_no  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_autocheck_data  change   create_time   create_time timstamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_autocheck_data  change   update_time   update_time  timstamp      comment'' ;
insert overwrite table dw_uat.dw_olea_cust_olea_autocheck_data partition(data_date='${hiveconf:DATA_DATE}')
select 
       id                
      ,column_record_id  
      ,olea_data         
      ,interface_data    
      ,check_field       
      ,result            
      ,remark            
      ,from_unixtime(cast(a.create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time       
      ,create_by         
      ,from_unixtime(cast(a.update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time       
      ,update_by  
      ,app_no	  
 from ods.ods_olea_cust_olea_autocheck_data a 
 ;
