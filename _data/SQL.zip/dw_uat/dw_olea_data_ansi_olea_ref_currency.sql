create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_currency
(
    id				bigint	   comment ''
   ,currency_code	string	   comment ''
   ,currency_name	string	   comment ''
   ,exchange_rate	string	   comment ''
   ,update_date	    timestamp  comment ''
   ,create_by	    bigint	   comment ''
   ,create_time	    timestamp  comment ''
)partitioned by (data_date string)
stored as parquet;


--alter table dw_uat.dw_olea_data_ansi_olea_ref_currency  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_currency  change   create_time   create_time timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_currency partition(data_date='${hiveconf:DATA_DATE}')
select 
	id					
   ,currency_code		
   ,currency_name		
   ,exchange_rate		
   ,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date    	
   ,create_by	    	
   ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time
   ,d365_sync_status   
 from ods.ods_olea_data_ansi_olea_ref_currency
;