--drop table if exists dw_uat.dw_olea_wkfl_act_ru_task;
create table if not exists dw_uat.dw_olea_wkfl_act_ru_task
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`PARENT_TASK_ID_`                   string               comment '                                                  '
,`DESCRIPTION_`                      string               comment '                                                  '
,`TASK_DEF_KEY_`                     string               comment '                                                  '
,`OWNER_`                            string               comment '                                                  '
,`ASSIGNEE_`                         string               comment '                                                  '
,`DELEGATION_`                       string               comment '                                                  '
,`PRIORITY_`                         string               comment '                                                  '
,`CREATE_TIME_`                      timestamp            comment '                                                  '
,`DUE_DATE_`                         timestamp            comment '                                                  '
,`CATEGORY_`                         string               comment '                                                  '
,`SUSPENSION_STATE_`                 string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  '
,`FORM_KEY_`                         string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_ru_task partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`EXECUTION_ID_`                    
,`PROC_INST_ID_`                    
,`PROC_DEF_ID_`                     
,`NAME_`                            
,`PARENT_TASK_ID_`                  
,`DESCRIPTION_`                     
,`TASK_DEF_KEY_`                    
,`OWNER_`                           
,`ASSIGNEE_`                        
,`DELEGATION_`                      
,`PRIORITY_`                        
,nvl(from_unixtime(cast(`CREATE_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`CREATE_TIME_`) as CREATE_TIME_
,nvl(from_unixtime(cast(`DUE_DATE_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`DUE_DATE_`) as DUE_DATE_
,`CATEGORY_`                        
,`SUSPENSION_STATE_`                
,`TENANT_ID_`                       
,`FORM_KEY_`                        

from ods.ods_olea_wkfl_act_ru_task;