  create table if not exists dw_uat.dw_olea_cust_olea_limit_shared_group_rel
(
     id                    int     comment '唯一主键，自增雪花id'
    ,limit_shared_group_id int     comment '关联olea_limit_shared_group表id,link to olea_limit_shared_group.id'
    ,limit_management_id   int     comment '关联olea_limit_management表id,link to olea_limit_management.id'
    ,company_name          string  comment '公司名称'
    ,olea_id               string  comment 'Olea Id，link to olea_company.olea_id'
    ,create_by             int     comment '创建人'
    ,create_time           timestamp  comment '创建时间'
    ,update_by             int        comment '更新人'
    ,update_time           timestamp  comment '更新时间'
)partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_limit_shared_group_rel partition(data_date='${hiveconf:DATA_DATE}')
select 
       id                   
      ,limit_shared_group_id
      ,limit_management_id  
      ,company_name         
      ,olea_id              
      ,create_by            
      ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time          
      ,update_by            
      ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
   from ods.ods_olea_cust_olea_limit_shared_group_rel 
   ;        