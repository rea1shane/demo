

create table if not exists dw_uat.dw_olea_data_ansi_olea_algo_parameter
(  id                                 string  comment 'id'          
  ,pss_remi_cost_benbank              string  comment 'PSS_Remi_cost_BenBank    '
  ,pss_remi_cost_corresbank           string  comment 'PSS_Remi_cost_CorresBank '
  ,pss_proc_cost                      string  comment 'PSS_Proc_cost            '
  ,inv_persupplier_perday             string  comment 'inv_perSupplier_perDay   '
  ,inv_perbuyer_perday                string  comment 'inv_perBuyer_perDay      '
  ,inv_perday                         string  comment 'inv_perDay               '
  ,olea_mgmtfee_bps                   string  comment 'OLEA_MgmtFee_BPS         '
  ,infonex_platfee_bps                string  comment 'InfoNex_PlatFee_BPS      '
  ,olea_infonex_platfee_bps           string  comment 'OLEA_InfoNex_PlatFee_BPS '
  ,olea_llsi_svcfee_bps               string  comment 'OLEA_LLSI_SvcFee_BPS     '
  ,esco_annfee                        string  comment 'Esco_AnnFee              '
  ,esco_inv_perann                    string  comment 'Esco_inv_perAnn          '
  ,update_date                        string  comment 'update_date              '
  ,create_time                        string  comment ''
  ,create_by                          string  comment ''
  --,olea_processing_cost               string  comment ''
  --,olea_investor_esco_cost            string  comment ''
  --,olea_supplier_disburse_cost        string  comment ''
 )partitioned by (data_date string)
stored as parquet;


--alter table dw_uat.dw_olea_data_ansi_olea_algo_parameter  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_algo_parameter  change   create_time   create_time timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_data_ansi_olea_algo_parameter partition(data_date='${hiveconf:DATA_DATE}')
select 
       id                            
      ,pss_remi_cost_benbank         
      ,pss_remi_cost_corresbank      
      ,pss_proc_cost                 
      ,inv_persupplier_perday        
      ,inv_perbuyer_perday           
      ,inv_perday                    
      ,olea_mgmtfee_bps              
      ,infonex_platfee_bps           
      ,olea_infonex_platfee_bps      
      ,olea_llsi_svcfee_bps          
      ,esco_annfee                   
      ,esco_inv_perann               
      ,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date          
      ,create_time                   
      ,create_by                     
     -- ,olea_processing_cost           
     -- ,olea_investor_esco_cost        
     -- ,olea_supplier_disburse_cost   	
from ods.ods_olea_data_ansi_olea_algo_parameter
;


                                            
                                            