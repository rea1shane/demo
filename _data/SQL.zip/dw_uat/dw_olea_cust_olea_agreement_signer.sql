--drop table if exists dw_uat.dw_olea_cust_olea_agreement_signer;
create table if not exists dw_uat.dw_olea_cust_olea_agreement_signer
(`id`                                string               comment ' '
,`company_id`                        string               comment 'company id  '
,`agreement_id`                      string               comment 'Contract id '
,`signer_type`                       string               comment 'signer type '
,`sign_status`                       string               comment 'sign status '
,`sign_time`                         date                 comment 'sign time '
,`sign_user_id`                      string               comment 'sign user id '
,`create_time`                       timestamp            comment 'create time '
,`create_by`                         string               comment 'creator id '
,`update_time`                       timestamp            comment 'update time '
,`update_by`                         string               comment 'updater id '
) comment 'contract signatory information sheet'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_agreement_signer partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`company_id`                       
,`agreement_id`                     
,`signer_type`                      
,`sign_status`                      
,nvl(from_unixtime(cast(`sign_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`sign_time`) as sign_time
,`sign_user_id`                     
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        

from ods.ods_olea_cust_olea_agreement_signer;