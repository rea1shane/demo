--drop table if exists dw_uat.dw_olea_data_ansi_olea_external_fin_metric;
create table if not exists dw_uat.dw_olea_data_ansi_olea_external_fin_metric
(`id`                                string               comment '                                                  '
,`instrument_id`                     string               comment 'instrument_id                                     '
,`data_source`                       string               comment 'data_source                                       '
,`stat_date`                         string               comment 'stat_date                                         '
,`fin_metric_short`                  string               comment 'fin_metric_short                                  '
,`fin_metric_value`                  string               comment 'fin_metric_value                                  '
,`fin_metric_long`                   string               comment 'fin_metric_long                                   '
,`statement_type`                    string               comment 'statement_type                                    '
,`currency_code`                     string               comment 'currency_code                                     '
,`update_date`                       date                 comment 'update_date                                       '
,`create_by`                         string               comment '                                                  '
,`create_time`                       timestamp            comment '                                                  ') comment 'external_fin_metric'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_data_ansi_olea_external_fin_metric partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`instrument_id`                    
,`data_source`                      
,`stat_date`                        
,`fin_metric_short`                 
,`fin_metric_value`                 
,`fin_metric_long`                  
,`statement_type`                   
,`currency_code`                    
,nvl(from_unixtime(cast(`update_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_date`) as update_date
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time

from ods.ods_olea_data_ansi_olea_external_fin_metric;