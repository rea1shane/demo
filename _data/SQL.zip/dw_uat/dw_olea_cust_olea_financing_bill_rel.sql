create table if not exists dw_uat.dw_olea_cust_olea_financing_bill_rel
 (    id                bigint           comment 'id'
    ,financing_id       bigint           comment 'financing_id'
    ,bill_id            bigint           comment 'bill_id'
    ,supplier_id        bigint           comment 'supplier_id'
    ,buyer_id           bigint           comment 'buyer_id'
    ,bill_type          string           comment 'bill_type'
    ,financing_amount   decimal(20,8)    comment 'financing_amount'
    ,remark             string           comment 'remark'
    ,create_by          bigint           comment 'create_by'
	,create_by_name     string           comment 'create_by_name'
    ,create_time        string           comment 'create_time'
    ,update_by          bigint           comment 'update_by'
	,update_by_name     string           comment 'update_by_name'
    ,update_time        string           comment 'update_time'
)partitioned by (data_date string)
stored as parquet;


-- alter table dw_uat.dw_olea_cust_olea_financing_bill_rel  add  columns (supplier_name   string  comment '' );
-- alter table dw_uat.dw_olea_cust_olea_financing_bill_rel  add  columns (buyer_group_id  string  comment '' );
-- alter table dw_uat.dw_olea_cust_olea_financing_bill_rel  add  columns (buyer_group_name  string  comment '' );
-- alter table dw_uat.dw_olea_cust_olea_financing_bill_rel  add  columns (buyer_name  string  comment '' );
-- alter table dw_uat.dw_olea_cust_olea_financing_bill_rel  change   create_time   create_time timestamp      comment'' ;
-- alter table dw_uat.dw_olea_cust_olea_financing_bill_rel  change   update_time   update_time  timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_bill_rel partition(data_date='${hiveconf:DATA_DATE}')
select 
     id              
    ,financing_id     
    ,bill_id          
    ,supplier_id      
    ,buyer_id         
    ,bill_type        
    ,financing_amount 
    ,remark           
    ,create_by        
    ,create_by_name   
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd')  as create_time      
    ,update_by        
    ,update_by_name   
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd')  as update_time
    ,supplier_name
    ,buyer_group_id	
	,buyer_group_name
	,buyer_name
 from ods.ods_olea_cust_olea_financing_bill_rel
;