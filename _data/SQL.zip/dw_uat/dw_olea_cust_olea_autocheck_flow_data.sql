--drop table if exists dw_uat.dw_olea_cust_olea_autocheck_flow_data;
create table if not exists dw_uat.dw_olea_cust_olea_autocheck_flow_data
(`id`                                string               comment ''
,`app_no`                            string               comment 'process application NO.'
,`type`                              string               comment 'auto check type'
,`ext_key`                           string               comment 'The last joint key when the type can no longer match the unique value'
,`status`                            string               comment 'Is it valid data'
,`value`                             string               comment 'return result data '
,`create_time`                       timestamp            comment 'create time '
,`update_time`                       timestamp            comment 'update time '
,`remark`                            string               comment 'remark'
) comment 'autocheck Data snapshots required in the process'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_autocheck_flow_data partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`app_no`                           
,`type`                             
,`ext_key`                          
,`status`                           
,`value`                            
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`remark`                           
,ext_value
from ods.ods_olea_cust_olea_autocheck_flow_data;