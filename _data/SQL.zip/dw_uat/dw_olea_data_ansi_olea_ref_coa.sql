create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_coa
(
  id                              string comment  'id'               
 ,account                         string comment  'Account'
 ,description                     string comment  'Description'
 ,definition                      string comment  'Definition'
 ,ifrs_pack_sch_description       string comment  'IFRSPackSchDescription'
 ,ifrs_line_item                  string comment  'IFRSLineItem/GeneralRef'
 ,ifrs_pack_acct_node             string comment  'IFRSPackAcctNode'
 ,mr_pack_sch_ref                 string comment  'MRPackSch Ref'
 ,mr_line_item                    string comment  'MRLineItem/GeneralRef'
 ,mr_pack_acct_node               string comment  'MRPackAcctNode'
 ,fcs_activity                    string comment  'FCSActivity'
 ,update_date                     string comment  'update_date'
 ,create_by                       string comment  'update_by'
 ,create_time                     string comment  'create_time'
)partitioned by (data_date string)
stored as parquet;                     

--alter table dw_uat.dw_olea_data_ansi_olea_ref_coa  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_coa  change   create_time   create_time timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_coa partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id					
	,account 					as accountid          
	,description    			as acctdesc           
	,definition     			as acctdefinition     
	,ifrs_pack_sch_description  as ifrs_pack_sch_desc 
	,ifrs_line_item     
	,ifrs_pack_acct_node
	,mr_pack_sch_ref    
	,mr_line_item       
	,mr_pack_acct_node  
	,fcs_activity       
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date      
	,create_by		
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
 from ods.ods_olea_data_ansi_olea_ref_coa
;