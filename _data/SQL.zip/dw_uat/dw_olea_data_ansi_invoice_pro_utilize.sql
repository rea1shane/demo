--alter table dw_uat.dw_olea_data_ansi_invoice_pro_utilize  change   pair_runtime   pair_runtime timestamp      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_invoice_pro_utilize  change   create_time    create_time  timestamp      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_invoice_pro_utilize  change   update_time    update_time  timestamp      comment'' ;


--drop table if exists dw_uat.dw_olea_data_ansi_invoice_pro_utilize;
create table if not exists dw_uat.dw_olea_data_ansi_invoice_pro_utilize
(                                             
   id                                          string  comment ''
  ,invoice_no                                  string  comment 'Invoice no'
  ,investor_id                                 string  comment 'Investor ID'
  ,investor_program_id                         string  comment 'Program ID'
  ,utilisation_rate                            string  comment 'Utilisation rate of program'
  ,current_portfolio_return                    string  comment 'Return rate of program'
  ,utilisation_rate_std                        string  comment 'Standardised utilisation rate of program'
  ,current_portfolio_return_std                string  comment 'Standardised return rate of program'
  ,random_var                                  string  comment 'Random Normal variable'
  ,random_opt                                  string  comment 'Random Sum '
  ,seq_key                                     string  comment 'Sequence of pairing'
  ,pair_runtime                                string  comment 'run time of the pairing'
  ,create_time                                 string  comment ''
  ,update_time                                 string  comment ''
)partitioned by(data_date string) 
stored as parquet
;

insert overwrite table dw_uat.dw_olea_data_ansi_invoice_pro_utilize partition(data_date='${hiveconf:DATA_DATE}')
 select                 
      id                                        
     ,invoice_no                                
     ,investor_id                               
     ,investor_program_id                       
     ,utilisation_rate                          
     ,current_portfolio_return                  
     ,utilisation_rate_std                      
     ,current_portfolio_return_std              
     ,random_var                                
     ,random_opt                                
     ,seq_key                                   
     ,from_unixtime(cast(pair_runtime/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as pair_runtime                              
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                               
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time
 from ods.ods_olea_data_ansi_invoice_pro_utilize
 ;
 
 










