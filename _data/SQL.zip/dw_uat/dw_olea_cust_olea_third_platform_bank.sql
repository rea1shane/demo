--drop table if exists dw_uat.dw_olea_cust_olea_third_platform_bank;
create table if not exists dw_uat.dw_olea_cust_olea_third_platform_bank
(`id`                                string               comment '唯一主键，自增雪花id                                       '
,`platform_id`                       string               comment '平台id（olea_third_platform.id）                      '
,`type`                              string               comment '银行账号类型                                            '
,`payee_type`                        string               comment '付款方式（Payee Type）                                  '
,`payer_type`                        string               comment '还款方式（Payer Type）                                  '
,`account_name`                      string               comment '账户名                                               '
,`account_no`                        string               comment '账户号                                               '
,`account_currency`                  string               comment '账户币种                                              '
,`swift_code`                        string               comment 'Swift code                                        '
,`bank_name`                         string               comment '银行名称                                              '
,`bank_branch`                       string               comment '银行分支行                                             '
,`bank_address`                      string               comment '银行地址                                              '
,`create_by`                         string               comment '创建人userId                                         '
,`create_by_name`                    string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人userId                                         '
,`update_by_name`                    string               comment '更新人                                               '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment '第三方平台银行账号表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_third_platform_bank partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`platform_id`                      
,`type`                             
,`payee_type`                       
,`payer_type`                       
,`account_name`                     
,`account_no`                       
,`account_currency`                 
,`swift_code`                       
,`bank_name`                        
,`bank_branch`                      
,`bank_address`                     
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,related_account_name
from ods.ods_olea_cust_olea_third_platform_bank;