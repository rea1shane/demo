create table if not exists dw_uat.dw_olea_cust_olea_asset_workflow_history
( 

 id								  							string         comment'primary key id'
 ,app_no                          string         comment'application NO.'
 ,business_id                     string         comment'business ID'
 ,to_status                       string         comment'process reverse state'
 ,process_date                    timestamp      comment'process reverse state'
 ,company_id                      string         comment'company ID，oela_company id'
 ,`type`                          string         comment'history type' 
 ,create_by                       string         comment'creator id'
 ,create_by_name                  string         comment'creator name'
 ,create_time                     timestamp      comment'create time'
 ,update_by                       string         comment'updater id'
 ,update_by_name                  string         comment'updater name'
 ,update_time                     timestamp      comment'update time'
 )                                               
 COMMENT 'the process audit node reverses the history table'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_asset_workflow_history partition(data_date='${hiveconf:DATA_DATE}')
select 
     id                         				
    ,app_no      
    ,business_id 
    ,to_status   
    ,from_unixtime(cast(process_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as process_date           
    ,company_id  
    ,`type`  	
    ,create_by                 
    ,create_by_name            
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time               
    ,update_by                 
    ,update_by_name            
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time               
from ods.ods_olea_cust_olea_asset_workflow_history 
;









































