--drop table if exists dw_uat.dw_olea_wkfl_act_hi_procinst;
create table if not exists dw_uat.dw_olea_wkfl_act_hi_procinst
(`ID_`                               string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`BUSINESS_KEY_`                     string               comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`START_TIME_`                       timestamp            comment '                                                  '
,`END_TIME_`                         timestamp            comment '                                                  '
,`DURATION_`                         string               comment '                                                  '
,`START_USER_ID_`                    string               comment '                                                  '
,`START_ACT_ID_`                     string               comment '                                                  '
,`END_ACT_ID_`                       string               comment '                                                  '
,`SUPER_PROCESS_INSTANCE_ID_`        string               comment '                                                  '
,`DELETE_REASON_`                    string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  '
,`NAME_`                             string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_hi_procinst partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`PROC_INST_ID_`                    
,`BUSINESS_KEY_`                    
,`PROC_DEF_ID_`                     
,nvl(from_unixtime(cast(`START_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`START_TIME_`) as START_TIME_
,nvl(from_unixtime(cast(`END_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`END_TIME_`) as END_TIME_
,`DURATION_`                        
,`START_USER_ID_`                   
,`START_ACT_ID_`                    
,`END_ACT_ID_`                      
,`SUPER_PROCESS_INSTANCE_ID_`       
,`DELETE_REASON_`                   
,`TENANT_ID_`                       
,`NAME_`                            

from ods.ods_olea_wkfl_act_hi_procinst;