--drop table if exists dw_uat.dw_olea_data_ansi_olea_external_mrkt_metric;
create table if not exists dw_uat.dw_olea_data_ansi_olea_external_mrkt_metric
(`id`                                string               comment '                                                  '
,`instrument_id`                     string               comment 'instrument_id                                     '
,`data_source`                       string               comment 'data_source                                       '
,`mrkt_metric_value`                 string               comment 'mrkt_metric_value                                 '
,`instrument_isin`                   string               comment 'instrument_isin                                   '
,`prefer_ric`                        string               comment 'prefer_ric                                        '
,`mrkt_info_type`                    string               comment 'mrkt_info_type                                    '
,`mrkt_metric`                       string               comment 'mrkt_metric                                       '
,`mrkt_metric_date`                  date                 comment 'mrkt_metric_date                                  '
,`update_date`                       date                 comment 'update_date                                       '
,`create_by`                         string               comment '                                                  '
,`create_time`                       timestamp            comment '                                                  ') comment 'external_mrkt_metric'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_data_ansi_olea_external_mrkt_metric partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`instrument_id`                    
,`data_source`                      
,`mrkt_metric_value`                
,`instrument_isin`                  
,`prefer_ric`                       
,`mrkt_info_type`                   
,`mrkt_metric`                      
,nvl(from_unixtime(cast(`mrkt_metric_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`mrkt_metric_date`) as mrkt_metric_date
,nvl(from_unixtime(cast(`update_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_date`) as update_date
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time

from ods.ods_olea_data_ansi_olea_external_mrkt_metric;