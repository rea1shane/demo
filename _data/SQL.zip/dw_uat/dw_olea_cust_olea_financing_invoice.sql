--alter table dw_uat.dw_olea_cust_olea_financing_invoice   	  add columns (financed_amount     			    double  comment'融资金额');
--alter table dw_uat.dw_olea_cust_olea_financing_invoice   	  add columns (payment_terms_start_date     	date    comment'付款条件生效日');
--alter table dw_uat.dw_olea_cust_olea_financing_invoice   	  add columns (disbursement_amount     			double  comment'付款金额');

--alter table dw_uat.dw_olea_cust_olea_financing_invoice add columns(invoice_status string comment'invoice_status');
--alter table dw_uat.dw_olea_cust_olea_financing_invoice add columns(due_date       string comment'due_date');

--drop table if exists  dw_uat.dw_olea_cust_olea_financing_invoice;
create table if not exists dw_uat.dw_olea_cust_olea_financing_invoice
( 
    id                     string  comment 'ID'
   ,invoice_id             string  comment 'invoice ID'
   ,invoice_code           string  comment 'invoice code'
   ,invoice_no             string  comment 'invoice No.'
   ,issue_date             string  comment 'issue date'
   ,buyer_id               string  comment 'buyer ID'
   ,buyer                  string  comment 'buyer'
   ,seller_id              string  comment 'seller ID'
   ,seller                 string  comment 'seller'
   ,invoice_amount         string  comment 'invoice amount'
   ,currency               string  comment 'currency'
   ,maturity_date          string  comment 'maturity date'
   ,data_source            string  comment 'data source'
   ,remark                 string  comment 'remark'
   ,create_by              string  comment 'id of the person who created'
   ,create_by_name         string  comment 'name of the person who created'
   ,create_time            string  comment 'create time'
   ,update_by              string  comment 'id of the person who updated'
   ,update_by_name         string  comment 'name of the person who updated'
   ,update_time            string  comment 'update time'
)partitioned by (data_date string)
stored as parquet
;

--alter table dw_uat.dw_olea_cust_olea_financing_invoice  change   issue_date   issue_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_invoice  change   due_date   due_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_invoice  change   maturity_date   maturity_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_invoice  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_invoice  change   update_time   update_time  timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_invoice partition(data_date='${hiveconf:DATA_DATE}')
 select   id                  
         ,invoice_id          
         ,invoice_code        
         ,invoice_no          
         ,from_unixtime(cast(issue_date/1000 as bigint),'yyyy-MM-dd')  as issue_date          
         ,buyer_id            
         ,buyer               
         ,seller_id           
         ,seller              
         ,invoice_amount      
         ,currency            
         ,from_unixtime(cast(maturity_date/1000 as bigint),'yyyy-MM-dd') as maturity_date       
         ,data_source         
         ,remark              
         ,create_by           
         ,create_by_name      
         ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time         
         ,update_by           
         ,update_by_name      
         ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
		 ,invoice_status
		 ,from_unixtime(cast(due_date/1000 as bigint),'yyyy-MM-dd')  as due_date   
         ,financed_amount     		
         ,from_unixtime(cast(payment_terms_start_date/1000 as bigint),'yyyy-MM-dd')  as payment_terms_start_date 
         ,disbursement_amount     	   		 
         ,requested_amount              --申请金额
         ,gtn_seller_fees               --GTN费用
         ,discount_amount               --折扣金额
         ,discount_rate                 --折扣利率
         ,discount_days                 --折扣天数
		 ,busi_key                      --供应商端临时上传文件业务主键
		 ,payment_terms                 --付款期限
		 ,goods_description             --产品描述
		 ,goods_description_category 	--融资项目产品描述	 
		 ,payment_terms_from
		 ,project_code
		 ,from_unixtime(cast(payment_terms_date/1000 as bigint),'yyyy-MM-dd') as payment_terms_date
from ods.ods_olea_cust_olea_financing_invoice 
;