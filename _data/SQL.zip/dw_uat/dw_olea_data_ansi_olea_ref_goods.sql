create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_goods
(
     id                 string  	  comment '唯一主键'
    ,goods_code         string                       
    ,goods_description  string                       
    ,update_date        date          comment 'yyyy-mm-dd'
    ,create_time        timestamp     comment 'system audit'
    ,create_by          string        comment 'system audit'
)
COMMENT'商品类型'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_goods partition(data_date='${hiveconf:DATA_DATE}')
select 
    id               
    ,goods_code       
    ,goods_description
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd')          as update_date       
	,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time      
	,create_by                     
from ods.ods_olea_data_ansi_olea_ref_goods 
;


















