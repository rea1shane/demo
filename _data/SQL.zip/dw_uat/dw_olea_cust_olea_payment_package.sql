--alter table dw_uat.dw_olea_cust_olea_payment_package     add columns(estimated_funding_date timestamp     comment'投资到期日');



--alter table dw_uat.dw_olea_cust_olea_payment_package add columns(extension_suspense_amount string comment'extension总额');


create table if not exists dw_uat.dw_olea_cust_olea_payment_package
(												
   id                                    bigint              comment  ''
  ,olea_id                               string              comment  'Fund/Disbursement Package ID'
  ,type                                  string              comment  'type'
  ,export_status                         string              comment  'Export Status'
  ,package_status                        string              comment  'Package Status'
  ,asset_quantity                        bigint              comment  'asset quantity'
  ,currency                              string              comment  'currency'
  ,fees_type                             string              comment  'Remittance Fee Type'
  ,amount                                decimal(20,8)       comment  'amount'
  ,total_net_financing_amount            decimal(20,8)       comment  'total net financing amount'
  ,total_payment_adjustment_amount       decimal(20,8)       comment  'total payment adjustment amount'
  ,payment_ref_no                        string              comment  'payment reference No.'
  ,trans_date                            string              comment  'transaction date'
  ,fund_date                             string              comment  'fund date'
  ,company_id                            bigint              comment  'company ID'
  ,company_name                          string              comment  'company name'
  ,account_id                            bigint              comment  'account ID'
  ,account_no                            string              comment  'account No.'
  ,payment_user_id                       bigint              comment  'payment user ID'
  ,payment_user_name                     string              comment  'payment user name'
  ,payment_comment                       string              comment  'payment comment'
  ,account_name                          string              comment  'account name'
  ,account_bank                          string              comment  'account bank'
  ,bank_branch                           string              comment  'bank branch'
  ,bank_address                          string              comment  'bank address'
  ,bank_swift_code                       string              comment  'bank swift code'
  ,create_by                             bigint              comment  'id of the person who created'
  ,update_by                             bigint              comment  'id of the person who updated'
  ,create_time                           string              comment  ''
  ,update_time                           string              comment  ''
)partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_cust_olea_payment_package partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                                   
     ,olea_id                              
     ,type                                 
     ,export_status                        
     ,package_status                       
     ,asset_quantity                       
     ,currency                             
     ,fees_type                            
     ,amount                               
     ,total_net_financing_amount           
     ,total_payment_adjustment_amount      
     ,payment_ref_no                       
     ,from_unixtime(cast(trans_date/1000 as bigint),'yyyy-MM-dd') as trans_date                           
     ,fund_date                            
     ,company_id                           
     ,company_name                         
     ,account_id                           
     ,account_no                           
     ,payment_user_id                      
     ,payment_user_name                    
     ,payment_comment                      
     ,account_name                         
     ,account_bank                         
     ,bank_branch                          
     ,bank_address                         
     ,bank_swift_code                      
     ,create_by                            
     ,update_by                            
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time                         
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
     ,package_type
	 ,total_suspense_amount
	 ,model_type  		 	
	 ,credit_available  	
	 ,shortage_excess   	
	 ,total_received_amount
	 ,from_unixtime(cast(complete_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as complete_time 
	 ,extension_suspense_amount	 
	 ,from_unixtime(cast(estimated_funding_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as estimated_funding_date
     ,total_estimated_funding_amount
     ,total_available_float       
     ,data_source
     ,total_estimated_disbursed_amount
     ,total_overdue_interest
	 ,project_code	 
	 ,net_settlement_status    
	 ,net_settlement_package_id
	 ,net_settled_amount       
	 ,estimated_top_up_Required
	 ,actual_top_up_required 
	 ,payment_instruction  --20230215
from ods.ods_olea_cust_olea_payment_package
;
