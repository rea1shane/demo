CREATE table if not exists dw_uat.dw_olea_pub_olea_stock_exchange
(
   `id`                        int       comment 'primary key id' 
  ,`code_of_stock_exchange`    string    comment 'Code of Stock exchange' 
  ,`name_of_stock_exchange`    string    comment 'Name of Stock exchange' 
  ,`country_code`              string    comment 'ISO Country Code' 
  ,`market_cap`                string    comment 'Market Cap' 
  ,`opening_hours`             string    comment 'Opening Hours' 
  ,`create_time`               TIMESTAMP comment 'create time' 
)comment  'stock exchange table'
partitioned by (data_date string)                   
stored as parquet
;


insert overwrite table dw_uat.dw_olea_pub_olea_stock_exchange partition (data_date='${hiveconf:DATA_DATE}')
select  `id`                     
       ,`code_of_stock_exchange` 
       ,`name_of_stock_exchange` 
       ,`country_code`           
       ,`market_cap`             
       ,`opening_hours`          
       ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as `create_time`            
   from ods.ods_olea_pub_olea_stock_exchange
   ;