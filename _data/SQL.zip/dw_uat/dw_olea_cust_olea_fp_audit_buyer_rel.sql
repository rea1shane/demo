--drop table if exists dw_uat.dw_olea_cust_olea_fp_audit_buyer_rel;
create table if not exists dw_uat.dw_olea_cust_olea_fp_audit_buyer_rel
(`id`                                string               comment '                                                  '
,`financing_program_id`              string               comment '融资项目ID link to olea_financing_program.id          '
,`financing_program_audit_id`        string               comment '融资项目审核记录ID link to olea_financing_program_audit.id'
,`buyer_entity_id`                   string               comment '买方子公司ID link to olea_company.id                   '
,`buyer_entity_name`                 string               comment '买方子公司名称 for front Buyer Entity Name               '
,`create_by`                         string               comment '创建人                                               '
,`create_by_name`                    string               comment '创建人名称                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '修改人                                               '
,`update_by_name`                    string               comment '修改人名称                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment '融资项目审核记录与买方子公司关联表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_fp_audit_buyer_rel partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`financing_program_id`             
,`financing_program_audit_id`       
,`buyer_entity_id`                  
,`buyer_entity_name`                
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,buyer_group_id  
,buyer_group_name
from ods.ods_olea_cust_olea_fp_audit_buyer_rel;