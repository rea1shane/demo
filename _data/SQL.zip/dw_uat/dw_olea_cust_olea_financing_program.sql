--alter table dw_uat.dw_olea_cust_olea_financing_program 		add columns (nominal_rate_type	 			string  comment'名义利率类型：Fixed、Floating');
--alter table dw_uat.dw_olea_cust_olea_financing_program 		add columns (risk_free_rate_option 			string  comment'最低风险利率选项：TermsSofa');
--alter table dw_uat.dw_olea_cust_olea_financing_program 		add columns (overdue_agree_rate    			double  comment'逾期约定利率');
--alter table dw_uat.dw_olea_cust_olea_financing_program         add columns (manual_input_nominal_rate        double  comment'手动输入的名义利率值');



create table if not exists dw_uat.dw_olea_cust_olea_financing_program
(
   id                                string  comment ''                     
   ,parent_id                        string  comment ''    
   ,option_flag                      string  comment ''    
   ,program_no                       string  comment ''    
   ,program_no_version               string  comment ''    
   ,app_no                           string  comment ''    
   ,check_status                     string  comment ''    
   ,program_status                   string  comment ''    
   ,supplier_id                      string  comment ''    
   ,buyer_group_id                   string  comment ''    
   ,supplier_third_party_id          string  comment ''    
   ,buyer_group_third_party_id       string  comment ''    
   ,third_party_platform             string  comment ''    
   ,product_type                     string  comment ''    
   ,currency                         string  comment ''    
   ,nominal_rate                     string  comment ''    
   ,overdue_rate                     string  comment ''    
   ,advance_ratio                    string  comment ''    
   ,grace_period                     string  comment ''    
   ,payment_instruction              string  comment ''    
   ,processing_fee                   string  comment ''    
   ,expiry_date                      string  comment ''    
   ,effective_date                   string  comment ''    
   ,termination_date                 string  comment ''    
   ,termination_remarks              string  comment ''    
   ,remark                           string  comment ''
   ,enable                           string  comment ''
   ,create_by                        string  comment ''
   ,create_by_name                   string  comment ''
   ,create_time                      string  comment ''
   ,update_by                        string  comment ''
   ,update_by_name                   string  comment ''
   ,update_time                      string  comment ''
)partitioned by (data_date string)
stored as parquet;


--alter table dw_uat.dw_olea_cust_olea_financing_program  add  columns (supplier_name  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_financing_program  add  columns (buyer_group_name  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_financing_program  change   expiry_date   expiry_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_program  change   effective_date   effective_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_program  change   termination_date   termination_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_program  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_program  change   update_time   update_time  timestamp      comment'' ;

insert overwrite table  dw_uat.dw_olea_cust_olea_financing_program partition(data_date='${hiveconf:DATA_DATE}')
select 
     id                            
    ,parent_id                     
    ,option_flag                   
    ,program_no                    
    ,program_no_version            
    ,app_no                        
    ,check_status                  
    ,program_status                
    ,supplier_id                   
    ,buyer_group_id                
    ,supplier_third_party_id       
    ,buyer_group_third_party_id    
    ,third_party_platform          
    ,product_type                  
    ,currency                      
    ,nominal_rate                  
    ,overdue_rate                  
    ,advance_ratio                 
    ,grace_period                  
    ,payment_instruction           
    ,processing_fee                
    ,from_unixtime(cast(expiry_date/1000 as bigint),'yyyy-MM-dd') as expiry_date                   
    ,from_unixtime(cast(expiry_date/1000 as bigint),'yyyy-MM-dd') as effective_date                
    ,from_unixtime(cast(expiry_date/1000 as bigint),'yyyy-MM-dd') as termination_date              
    ,termination_remarks           
    ,remark
    ,enable
	,create_by
	,create_by_name
	,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 
	,update_by
	,update_by_name
	,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
    ,supplier_name
    ,buyer_group_name	
	,nominal_rate_type	 		
	,risk_free_rate_option 		
	,overdue_agree_rate    		
	,manual_input_nominal_rate
	,goods_code
	,required_documents  
    ,project_code	
	,unfunded_invoice
	,unfunded_invoice_processing_fee
	,selected_buyergp_id   
	,min_payment_terms_days
	,max_payment_terms_days
	,payment_terms 
    ,min_advance_ratio
    ,cost_to_distribution
    ,post_trade	
	,null as exclusion_auto_populate_flag
    ,rpd_date
    ,noa_type
    ,buyer_authorised_signatory_ids
    ,buyer_program_type
    ,insurance_applied
    ,unfunded_type
    ,unfunded_required_documents  
from ods.ods_olea_cust_olea_financing_program
;
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       































     


     