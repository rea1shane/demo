--drop table if exists dw_uat.dw_olea_wkfl_act_ru_job;
create table if not exists dw_uat.dw_olea_wkfl_act_ru_job
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  '
,`LOCK_EXP_TIME_`                    timestamp            comment '                                                  '
,`LOCK_OWNER_`                       string               comment '                                                  '
,`EXCLUSIVE_`                        string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`PROCESS_INSTANCE_ID_`              string               comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`RETRIES_`                          string               comment '                                                  '
,`EXCEPTION_STACK_ID_`               string               comment '                                                  '
,`EXCEPTION_MSG_`                    string               comment '                                                  '
,`DUEDATE_`                          timestamp            comment '                                                  '
,`REPEAT_`                           string               comment '                                                  '
,`HANDLER_TYPE_`                     string               comment '                                                  '
,`HANDLER_CFG_`                      string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_ru_job partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`TYPE_`                            
,nvl(from_unixtime(cast(`LOCK_EXP_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`LOCK_EXP_TIME_`) as LOCK_EXP_TIME_
,`LOCK_OWNER_`                      
,`EXCLUSIVE_`                       
,`EXECUTION_ID_`                    
,`PROCESS_INSTANCE_ID_`             
,`PROC_DEF_ID_`                     
,`RETRIES_`                         
,`EXCEPTION_STACK_ID_`              
,`EXCEPTION_MSG_`                   
,nvl(from_unixtime(cast(`DUEDATE_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`DUEDATE_`) as DUEDATE_
,`REPEAT_`                          
,`HANDLER_TYPE_`                    
,`HANDLER_CFG_`                     
,`TENANT_ID_`                       

from ods.ods_olea_wkfl_act_ru_job;