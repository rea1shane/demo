--drop table if exists dw_uat.dw_olea_cust_olea_check_task;
create table if not exists dw_uat.dw_olea_cust_olea_check_task
(`id`                                string               comment '                                                  '
,`financing_id`                      string               comment 'financing id  '
,`financing_ref_no`                  string               comment 'financing ref no '
,`status`                            string               comment 'status   '
,`create_time`                       timestamp            comment 'create time  '
,`create_by`                         string               comment 'creator id    '
,`create_by_name`                    string               comment 'creator name  '
,`update_by`                         string               comment 'updator id   '
,`update_by_name`                    string               comment 'updator name  '
,`update_time`                       timestamp            comment 'update time   '
) 
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_check_task partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`financing_id`                     
,`financing_ref_no`                 
,`status`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,`create_by_name`                   
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_check_task;