--alter table dw_uat.dw_olea_cust_olea_third_platform  add  columns (payee_type  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_third_platform  add  columns (payer_type  string  comment '' );

--drop table if exists dw_uat.dw_olea_cust_olea_third_platform;
create table if not exists dw_uat.dw_olea_cust_olea_third_platform
(`id`                                string               comment '                                                  '
,`platform_config_id`                string               comment '平台基础配置id                                          '
,`platform_no`                       string               comment '平台唯一编号                                            '
--,`payment_type`                      string               comment '收款方式                                              '
,`status`                            string               comment '状态                                                '
,`account_name`                      string               comment '账户名                                               '
,`account_no`                        string               comment '账户号                                               '
,`account_currency`                  string               comment '账户币种                                              '
,`swift_code`                        string               comment 'Swift code                                        '
,`bank_name`                         string               comment '银行名称                                              '
,`bank_branch`                       string               comment '银行分支行                                             '
,`bank_address`                      string               comment '银行地址                                              '
,`create_by`                         string               comment '创建人userId                                         '
,`create_by_name`                    string               comment '创建人                                               '
,`create_time`                       timestamp            comment '                                                  '
,`update_by`                         string               comment '更新人userId                                         '
,`update_by_name`                    string               comment '更新人                                               '
,`update_time`                       timestamp            comment '                                                  '
) comment '第三方平台信息表'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_third_platform partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
--,`platform_config_id`   
,null as attr1   --  platform_config_id改为备用字段    
,`project_code`                      
,`status`                           
,`account_name`                     
,`account_no`                       
,`account_currency`                 
,`swift_code`                       
,`bank_name`                        
,`bank_branch`                      
,`bank_address`                     
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,payee_type
,payer_type
,project_name  		       
,platform_name 		       
,primary_relationship       
,trade_validation_level     
,trade_validation_outsource 
,fr_template                
,maturity_date              
,financing_start_date       
,tiered_interest_rate       
,onboarding_process         
,sc_portal_access           
,sc_portal_f_r              
,extension_applicability    
,invoice_amount_min         
,fr_amount_min              
,tenor_min                  
,tenor_max              
,fr_asset_validity 
,deal_complexity 
,partner_fee_flag
,platform_config_id 
,partner_fee_payment_type  
,transactional_document_template
from ods.ods_olea_cust_olea_third_platform;