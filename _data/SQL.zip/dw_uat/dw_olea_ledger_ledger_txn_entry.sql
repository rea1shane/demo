--drop table if exists dw_uat.dw_olea_ledger_ledger_txn_entry;
create table if not exists dw_uat.dw_olea_ledger_ledger_txn_entry
(`id`                                string               comment '                                                  '
,`txn_id`                            string               comment '交易id                                              '
,`sort_id`                           string               comment '分录编号                                              '
,`txn_type`                          string               comment '交易类型                                              '
,`direction`                         string               comment '发生方向                                              '
,`borrowing_no`                      string               comment '借贷编号                                              '
,`subject_desc`                      string               comment '科目描述                                              '
,`las_subject_no`                    string               comment 'las科目号                                            '
,`amount_express`                    string               comment '金额表达式                                             '
,`valid_express`                     string               comment '是否有效校验                                            '
,`event`                             string               comment '取值字段                                              '
,`digest`                            string               comment '摘要                                                '
,`status`                            string               comment '状态                                                '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '备注                                                '
,`create_by`                         string               comment '                                                  '
,`create_time`                       timestamp            comment '                                                  '
,`update_by`                         string               comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment '会计分录表'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_ledger_ledger_txn_entry partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`txn_id`                           
,`sort_id`                          
,`txn_type`                         
,`direction`                        
,`borrowing_no`                     
,`subject_desc`                     
,`las_subject_no`                   
,`amount_express`                   
,`valid_express`                    
,`event`                            
,`digest`                           
,`status`                           
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,unique_key
--,event
from ods.ods_olea_ledger_ledger_txn_entry;