--drop table if exists dw_uat.dw_olea_data_ansi_olea_external_credit_rating;
create table if not exists dw_uat.dw_olea_data_ansi_olea_external_credit_rating
(`id`                                string               comment '                                                  '
,`instrument_id`                     string               comment 'instrument_id                                     '
,`pd`                                string               comment 'pd                                                '
,`rating`                            string               comment 'rating                                            '
,`rating_source`                     string               comment 'rating_source                                     '
,`rating_date`                       date                 comment 'rating_date                                       '
,`rating_type`                       string               comment 'rating_type                                       '
,`data_source`                       string               comment 'data_source                                       '
,`update_date`                       date                 comment 'update_date                                       '
,`create_by`                         string               comment '                                                  '
,`create_time`                       timestamp            comment '                                                  ') comment 'external_credit_rating'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_data_ansi_olea_external_credit_rating partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`instrument_id`                    
,`pd`                               
,`rating`                           
,`rating_source`                    
,nvl(from_unixtime(cast(`rating_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`rating_date`) as rating_date
,`rating_type`                      
,`data_source`                      
,nvl(from_unixtime(cast(`update_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_date`) as update_date
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time

from ods.ods_olea_data_ansi_olea_external_credit_rating;