--alter table dw_uat.dw_olea_cust_olea_financing_program_buyer_rel  add  columns (buyer_entity_name  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_financing_program_buyer_rel  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_program_buyer_rel  change   update_time   update_time  timestamp     comment'' ;

create table if not exists dw_uat.dw_olea_cust_olea_financing_program_buyer_rel
(
    id                    string  comment ''
   ,financing_program_id  string  comment ''
   ,buyer_entity_id       string  comment ''
   ,create_by             string  comment ''
   ,create_by_name        string  comment ''
   ,create_time           string  comment ''
   ,update_by             string  comment ''
   ,update_by_name        string  comment ''
   ,update_time           string  comment ''
)partitioned by (data_date string)
stored as parquet;

insert overwrite table  dw_uat.dw_olea_cust_olea_financing_program_buyer_rel partition(data_date='${hiveconf:DATA_DATE}')
select 
     id
    ,financing_program_id
    ,buyer_entity_id
    ,create_by
    ,create_by_name
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time
    ,update_by
    ,update_by_name
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
	,buyer_entity_name	
	,buyer_group_id  
	,buyer_group_name
  from ods.ods_olea_cust_olea_financing_program_buyer_rel
;
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       































     


     