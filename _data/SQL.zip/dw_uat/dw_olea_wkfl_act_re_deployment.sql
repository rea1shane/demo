--drop table if exists dw_uat.dw_olea_wkfl_act_re_deployment;
create table if not exists dw_uat.dw_olea_wkfl_act_re_deployment
(`ID_`                               string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`CATEGORY_`                         string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  '
,`DEPLOY_TIME_`                      timestamp            comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_re_deployment partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`NAME_`                            
,`CATEGORY_`                        
,`TENANT_ID_`                       
,nvl(from_unixtime(cast(`DEPLOY_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`DEPLOY_TIME_`) as DEPLOY_TIME_

from ods.ods_olea_wkfl_act_re_deployment;