--drop table if exists dw_uat.dw_olea_cust_olea_autocheck_retry_audit;
create table if not exists dw_uat.dw_olea_cust_olea_autocheck_retry_audit
(`id`                                string               comment '  '
,`company_audit_id`                  string               comment 'Enterprise audit id'
,`app_no`                            string               comment 'process application NO.'
,`param`                             string               comment 'request param'
,`interface_type`                    string               comment 'interface type'
,`enable`                            string               comment ''
,`remark`                            string               comment 'ramark '
,`retry_times`                       string               comment 'retry times'
,`create_by`                         string               comment '         '
,`update_time`                       timestamp            comment 'update time'
,`update_by`                         string               comment ' '
,`create_time`                       timestamp            comment 'create time'
) comment 'automated Verification Retry Table'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_autocheck_retry_audit partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`company_audit_id`                 
,`app_no`                           
,`param`                            
,`interface_type`                   
,`enable`                           
,`remark`                           
,`retry_times`                      
,`create_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time

from ods.ods_olea_cust_olea_autocheck_retry_audit;