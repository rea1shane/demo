--drop table if exists dw_uat.dw_olea_wkfl_act_ru_variable;
create table if not exists dw_uat.dw_olea_wkfl_act_ru_variable
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`TASK_ID_`                          string               comment '                                                  '
,`BYTEARRAY_ID_`                     string               comment '                                                  '
,`DOUBLE_`                           string               comment '                                                  '
,`LONG_`                             string               comment '                                                  '
,`TEXT_`                             string               comment '                                                  '
,`TEXT2_`                            string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_ru_variable partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`TYPE_`                            
,`NAME_`                            
,`EXECUTION_ID_`                    
,`PROC_INST_ID_`                    
,`TASK_ID_`                         
,`BYTEARRAY_ID_`                    
,`DOUBLE_`                          
,`LONG_`                            
,`TEXT_`                            
,`TEXT2_`                           

from ods.ods_olea_wkfl_act_ru_variable;