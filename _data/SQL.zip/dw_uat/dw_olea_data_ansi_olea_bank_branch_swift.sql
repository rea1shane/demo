create table if not exists dw_uat.dw_olea_data_ansi_olea_bank_branch_swift
(
  id				string   comment 'id'
 ,bank_name			string   comment 'bank_name'
 ,branch_name		string   comment 'branch_name'
 ,swiftcode			string   comment 'swiftcode'
 ,connection		string   comment 'connection'
 ,country			string   comment 'country'
 ,city				string   comment 'city'
 ,address			string   comment 'address'
 ,postcode			string   comment 'postcode'
 ,money_transfer	string   comment 'money_transfer'
 ,receive_money		string   comment 'receive_money'
 ,bank_url			string   comment 'bank_url'
 ,country_code		string   comment 'country_code'
 ,update_date		string   comment 'update_date'
 ,create_by         string   comment 'create by'
 ,create_time       string   comment 'create_time'
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_data_ansi_olea_bank_branch_swift  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_bank_branch_swift  change   create_time   create_time timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_data_ansi_olea_bank_branch_swift partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id			
	,bank_name		
	,branch_name	
	,swiftcode		
	,connection	
	,country		
	,city			
	,address		
	,postcode		
	,money_transfer
	,receive_money	
	,bank_url		
	,country_code			
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_date	
	,create_by
	,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time
from ods.ods_olea_data_ansi_olea_bank_branch_swift
;