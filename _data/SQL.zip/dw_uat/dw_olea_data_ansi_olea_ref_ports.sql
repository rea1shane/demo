create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_ports
(
     id                  string  	  
     ,port_code          string   
     ,delivery_mode      string   
     ,country_code       string
     ,country_name       string
     ,place_name         string
     ,unlocode_port_id   string
     ,source             string
     ,update_date        date          
     ,create_time        timestamp     
     ,create_by          string        
)
COMMENT'商品类型'
partitioned by (data_date string)                   
stored as parquet
;


insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_ports partition(data_date='${hiveconf:DATA_DATE}')
select 
    id                              
	,port_code        
	,delivery_mode    
	,country_code     
	,country_name     
	,place_name       
	,unlocode_port_id 
	,source           
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd')          as update_date       
	,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time      
	,create_by       
    ,sanction	
from ods.ods_olea_data_ansi_olea_ref_ports 
;


















