--drop table if exists dw_uat.dw_olea_cust_olea_model;
create table if not exists dw_uat.dw_olea_cust_olea_model
(`id`                                string               comment '                                                  '
,`model_name`                        string               comment '模型名称，唯一。创建Other类型时候的指定                            '
,`job_id`                            string               comment 'xxl-job任务id                                       '
,`tag`                               string               comment '模型标签 core/other                                   '
,`trigger_type`                      string               comment '触发类型： realTime/every/daily/weekly                 '
,`trigger_frequency`                 string               comment '触发间隔 多选用逗号分隔 SUN,MON,TUE,WED,THU,FRI,SAT          '
,`trigger_rule`                      string               comment '触发规则                                              '
,`trigger_time`                      string               comment '触发时间 hh:mm:dd                                     '
,`model_type`                        string               comment '模型类型：Pricing/PD/Pairing/Other                     '
,`last_valid_time`                   timestamp            comment '上次置有效的时间                                          '
,`create_by`                         string               comment '创建人id                                             '
,`update_by`                         string               comment '更新人id                                             '
,`create_by_name`                    string               comment '创建人名称                                             '
,`update_by_name`                    string               comment '最后更新人名称                                           '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment '模型表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_model partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`model_name`                       
,`job_id`                           
,`tag`                              
,`trigger_type`                     
,`trigger_frequency`                
,`trigger_rule`                     
,`trigger_time`                     
,`model_type`                       
,nvl(from_unixtime(cast(`last_valid_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`last_valid_time`) as last_valid_time
,`create_by`                        
,`update_by`                        
,`create_by_name`                   
,`update_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_model;