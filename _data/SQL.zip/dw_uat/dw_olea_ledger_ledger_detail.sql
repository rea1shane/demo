--drop table if exists dw_uat.dw_olea_ledger_ledger_detail;
create table if not exists dw_uat.dw_olea_ledger_ledger_detail
(`id`                                string               comment '主键id                                              '
,`loan_no`                           string               comment '借据编号                                              '
,`bill_no`                           string               comment '单据号                                               '
,`txn_id`                            string               comment '交易编号                                              '
,`sort_id`                           string               comment '交易序号                                              '
,`occur_time`                        timestamp            comment '发生时间                                              '
,`occur_date`                        date                 comment '发生日期                                              '
,`currency`                          string               comment '币种                                                '
,`subject_name`                      string               comment '科目名称                                              '
,`subject_desc`                      string               comment '科目描述                                              '
,`direction`                         string               comment '借贷方向                                              '
,`subject_no`                        string               comment '科目号                                               '
,`credit_amt`                        string               comment '贷方（付）发生额                                          '
,`debit_amt`                         string               comment '借方（收）发生额                                          '
,`hand_status`                       string               comment '处理状态                                              '
,`org_id`                            string               comment '机构                                                '
,`bank_code_no`                      string               comment '资金方                                               '
,`account_set`                       string               comment '账套                                                '
,`ledger_type`                       string               comment '账务类型账套                                            '
,`digest`                            string               comment '摘要                                                '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '备注                                                '
,`create_by`                         string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人                                               '
,`update_time`                       timestamp            comment '更新时间                                              '
,`contract_no`                       string               comment '                                                  '
,`txn_type`                          string               comment '交易类型                                              '
) comment '账务交易明细'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_ledger_ledger_detail partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`loan_no`                          
,`bill_no`                          
,`txn_id`                           
,`sort_id`                          
,nvl(from_unixtime(cast(`occur_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`occur_time`) as occur_time
,nvl(from_unixtime(cast(`occur_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`occur_date`) as occur_date
,`currency`                         
,`subject_name`                     
,`subject_desc`                     
,`direction`                        
,`subject_no`                       
,`credit_amt`                       
,`debit_amt`                        
,`hand_status`                      
,`org_id`                           
,`bank_code_no`                     
,`account_set`                      
,`ledger_type`                      
,`digest`                           
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`contract_no`                      
,`txn_type`                         
,invoice_no
from ods.ods_olea_ledger_ledger_detail;