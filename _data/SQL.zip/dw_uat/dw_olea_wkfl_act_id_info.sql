--drop table if exists dw_uat.dw_olea_wkfl_act_id_info;
create table if not exists dw_uat.dw_olea_wkfl_act_id_info
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`USER_ID_`                          string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  '
,`KEY_`                              string               comment '                                                  '
,`VALUE_`                            string               comment '                                                  '
,`PASSWORD_`                         string               comment '                                                  '
,`PARENT_ID_`                        string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_id_info partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`USER_ID_`                         
,`TYPE_`                            
,`KEY_`                             
,`VALUE_`                           
,`PASSWORD_`                        
,`PARENT_ID_`                       

from ods.ods_olea_wkfl_act_id_info;