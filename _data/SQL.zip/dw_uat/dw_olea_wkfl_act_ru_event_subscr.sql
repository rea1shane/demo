--drop table if exists dw_uat.dw_olea_wkfl_act_ru_event_subscr;
create table if not exists dw_uat.dw_olea_wkfl_act_ru_event_subscr
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`EVENT_TYPE_`                       string               comment '                                                  '
,`EVENT_NAME_`                       string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`ACTIVITY_ID_`                      string               comment '                                                  '
,`CONFIGURATION_`                    string               comment '                                                  '
,`CREATED_`                          timestamp            comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_ru_event_subscr partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`EVENT_TYPE_`                      
,`EVENT_NAME_`                      
,`EXECUTION_ID_`                    
,`PROC_INST_ID_`                    
,`ACTIVITY_ID_`                     
,`CONFIGURATION_`                   
,nvl(from_unixtime(cast(`CREATED_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`CREATED_`) as CREATED_
,`PROC_DEF_ID_`                     
,`TENANT_ID_`                       

from ods.ods_olea_wkfl_act_ru_event_subscr;