
--2022年1月新增字段
--alter table dw_uat.dw_olea_cust_olea_autocheck_pep add columns(end_date   string  comment'结束时间');
--alter table dw_uat.dw_olea_cust_olea_autocheck_pep add columns(start_date string  comment'开始时间');

create table if not exists dw_uat.dw_olea_cust_olea_autocheck_pep
(
   id                  string comment ''
  ,record_id           string comment 'olea_autocheck_column_record.id'
  ,category            string comment '分类'
  ,sub_category        string comment '子分类'
  ,position            string comment 'position'
  ,remark              string comment '备注'
  ,create_time         string comment '创建时间'
  ,create_by           string comment ''
  ,update_time         string comment '更新时间'
  ,update_by           string comment ''
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_cust_olea_autocheck_pep  add  columns (app_no  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_autocheck_pep  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_autocheck_pep  change   update_time   update_time  timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_cust_olea_autocheck_pep partition(data_date='${hiveconf:DATA_DATE}')
select 
       id            
      ,record_id     
      ,category      
      ,sub_category  
      ,position      
      ,remark        
      ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time   
      ,create_by     
      ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time   
      ,update_by
	  ,end_date
	  ,start_date	
      ,app_no	  
 from ods.ods_olea_cust_olea_autocheck_pep
 ;
