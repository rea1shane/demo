create table if not exists dw_uat.dw_olea_cust_olea_financing_program_limit_audit
( 
   id                                       string	    comment'唯一主键，自增雪花id'
  ,financing_program_id                     string	    comment'融资项目ID'
  ,financing_program_audit_id               string      comment'融资项目审核记录ID link to olea_financing_program_audit.id'
  ,buyer_group_id                           string	    comment'买方集团id(buyer group id) link to olea_company.id'
  ,buyer_entity_id                          string	    comment'买方子公司ID link to olea_company.id'
  ,buyer_entity_name                        string	    comment'买方子公司名称 for front Buyer Entity Name'
  ,funded_limit                             double	    comment'Funded Limit 金额'
  ,unfunded_limit                           double	    comment'Unrunded Limit 金额'
  ,create_by                                string	    comment'创建人userId'
  ,create_by_name                           string	    comment'创建人'
  ,create_time                              timestamp	comment'创建时间'
  ,update_by                                string	    comment'更新人userId'
  ,update_by_name                           string	    comment'更新人'
  ,update_time                              timestamp	comment'最后更新时间'
 )
 COMMENT'融资项目买方限制表'
partitioned by (data_date date)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_program_limit_audit partition(data_date='${hiveconf:DATA_DATE}')
select 
   id                  
  ,financing_program_id
  ,financing_program_audit_id
  ,buyer_group_id      	
  ,buyer_entity_id     
  ,buyer_entity_name   
  ,funded_limit        
  ,unfunded_limit      
  ,create_by 	 			
  ,create_by_name 			
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
  ,update_by 
  ,update_by_name	  
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
  ,processing_fee
from ods.ods_olea_cust_olea_financing_program_limit_audit a 
;








































