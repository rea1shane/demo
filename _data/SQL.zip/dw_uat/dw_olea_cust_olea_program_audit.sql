--alter table dw_uat.dw_olea_cust_olea_program_audit 			  add columns (program_duration                 string  comment'项目期限');
--alter table dw_uat.dw_olea_cust_olea_program_audit 			  add columns (project_type                     string  comment'项目类型');
--alter table dw_uat.dw_olea_cust_olea_program_audit 			  add columns (program_funding_turnaround_time  int     comment'打款期限');
--alter table dw_uat.dw_olea_cust_olea_program_audit 			  add columns (average_tenor                    int     comment'平均期限');
--alter table dw_uat.dw_olea_cust_olea_program_audit 			  add columns (max_tenor_cap                    double  comment'最大期限比');
--alter table dw_uat.dw_olea_cust_olea_program_audit 			  add columns (rating_type                      string  comment'Rating Type');
--alter table dw_uat.dw_olea_cust_olea_program_audit 			  add columns (rating_grade                     string  comment'Rating Grade');


--alter table dw_uat.dw_olea_cust_olea_program_audit 	    add columns(supplier_specific_anchor_names string comment'特别许可的supplier');
--alter table dw_uat.dw_olea_cust_olea_program_audit 	    add columns(submit_time 	 timestamp comment'提交时间');
--alter table dw_uat.dw_olea_cust_olea_program_audit 	    add columns(amend_version 	 string    comment'变更版本号');
--alter table dw_uat.dw_olea_cust_olea_program_audit 	    add columns(parent_id        string    comment'父类id');
--alter table dw_uat.dw_olea_cust_olea_program_audit 	    add columns(change_type      string	   comment'修改类型');
--alter table dw_uat.dw_olea_cust_olea_program_audit  add  columns (advance_ratio  string  comment '' );

--drop table if exists dw_uat.dw_olea_cust_olea_program_audit;
create table if not exists dw_uat.dw_olea_cust_olea_program_audit
(`id`                                string               comment '                                                  '
,`program_no`                        string               comment '项目编号                                              '
,`investor_category`                 string               comment '投资商类别：托管投资商：escrow investor | 订阅者投资商：subscription '
,`company_id`                        string               comment '投资人Companyid                                      '
,`audit_id`                          string               comment 'company_audit表id                                  '
,`app_no`                            string               comment '流程id                                              '
,`account_id`                        string               comment '账户id                                              '
,`name`                              string               comment '项目名称                                              '
,`commitment_start_date`             date                 comment '承诺开始时间                                            '
,`commitment_end_date`               date                 comment '承诺结束时间                                            '
,`investor_commitment_currency`      string               comment '投资承诺币种                                            '
,`investor_commitment_amount`        string               comment '投资承诺金额                                            '
,`program_status`                    string               comment '项目状态                                              '
,`audit_status`                      string               comment '审核状态                                              '
,`agreement_status`                  string               comment '合同状态                                              '
,`skin_flag`                         string               comment '是否出资                                              '
,`olea_skin_rate`                    string               comment '出资比率                                              '
,`olea_skin_type`                    string               comment '出资类型                                              '
,`products`                          string               comment '产品                                                '
,`max_asset_tenor`                   string               comment '最大期限                                              '
,`min_asset_tenor`                   string               comment '最小期限                                              '
,`investment_pricing_benchmark`      string               comment '最小回报率                                             '
,`credit_rating_of_anchors`          string               comment '买方信用评级                                            '
,`program_offer_date`                date                 comment '项目时间                                              '
,`anchor_region`                     string               comment '买方区域                                              '
,`anchor_country`                    string               comment '买方国家                                              '
,`anchor_industry`                   string               comment '买方行业                                              '
,`anchor_industry_other`             string               comment '其他行业                                              '
,`anchor_industry_name`              string               comment '行业名称                                              '
,`specific_anchor_names`             string               comment '所有注册通过的buyer                                      '
,`supplier_region`                   string               comment '供应商所在区域                                           '
,`supplier_country`                  string               comment '供应商所在国家                                           '
,`available_amount`                  string               comment '可用金额                                              '
,`supplier_type`                     string               comment '供应商类型                                             '
,`funded_amount`                     string               comment '交易金额                                              '
,`frozen_amount`                     string               comment '冻结金额                                              '
,`remark`                            string               comment '备注                                                '
,`create_by`                         string               comment '创建人userId                                         '
,`create_by_name`                    string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人userId                                         '
,`update_name`                       string               comment '更新人                                               '
,`update_time`                       timestamp            comment '最后更新时间                                            '
) comment '投资人项目信息备份表'
 partitioned by(data_date string)  
 stored as parquet
 ;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_program_audit partition(data_date='${hiveconf:DATA_DATE}')
select
    `id`                               
    ,`program_no`                       
    ,`investor_category`                
    ,`company_id`                       
    ,`audit_id`                         
    ,`app_no`                           
    ,`account_id`                       
    ,`name`                             
    ,nvl(from_unixtime(cast(`commitment_start_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`commitment_start_date`) as commitment_start_date
    ,nvl(from_unixtime(cast(`commitment_end_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`commitment_end_date`) as commitment_end_date
    ,`investor_commitment_currency`     
    ,`investor_commitment_amount`       
    ,`program_status`                   
    ,`audit_status`                     
    ,`agreement_status`                 
    ,`skin_flag`                        
    ,`olea_skin_rate`                   
    ,`olea_skin_type`                   
    ,`products`                         
    ,`max_asset_tenor`                  
    ,`min_asset_tenor`                  
    ,`investment_pricing_benchmark`     
    ,`credit_rating_of_anchors`         
    ,nvl(from_unixtime(cast(`program_offer_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`program_offer_date`) as program_offer_date
    ,`anchor_region`                    
    ,`anchor_country`                   
    ,`anchor_industry`                  
    ,`anchor_industry_other`            
    ,`anchor_industry_name`             
    ,`selected_buyergp_id`            
    ,`supplier_region`                  
    ,`supplier_country`                 
    ,`available_amount`                 
    ,`supplier_type`                    
    ,`funded_amount`                    
    ,`frozen_amount`                    
    ,`remark`                           
    ,`create_by`                        
    ,`create_by_name`                   
    ,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
    ,`update_by`                        
    ,`update_name`                      
    ,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
    ,advance_ratio
    ,selected_supplier_id
    ,from_unixtime(cast(submit_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as submit_time 	
    ,amend_version 	
    ,parent_id       
    ,change_type     
    ,program_duration                
    ,project_type                    
    ,program_funding_turnaround_time 
    ,average_tenor                   
    ,max_tenor_cap                   
    ,rating_type                     
    ,rating_grade
    ,project_code     
    ,client_extension_type
    ,buffer_period 		    
    ,cost_of_funds
    ,cost_of_type
    ,profit_share  
    ,net_settlement_opt  
    ,payment_instruction  --20230215
	  ,maturity_terminal_date         
from ods.ods_olea_cust_olea_program_audit
;