CREATE TABLE if not exists dw_uat.dw_olea_cust_olea_buyer_invoices_record 
(
	 name 		      string       COMMENT 'record name'
	,invoice_id     int          COMMENT 'finnacing invoice id'
	,buyer_id 	    int  	       COMMENT 'buyer id'
	,package_id     string       COMMENT 'asset package id'
	,draft_flag     string       COMMENT 'is draft or not'
	,remark         string       COMMENT 'remark'
	,create_by 	    int          COMMENT 'creator id'
	,create_by_name string       COMMENT 'creator name'
	,create_time	  timestamp    COMMENT 'create time'
	,update_by 		  int  		     COMMENT 'updator id'
	,update_by_name string       COMMENT 'updator name'
	,update_time 	 timestamp     COMMENT 'update time'
)partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_buyer_invoices_record  partition(data_date='${hiveconf:DATA_DATE}')
select 
    name 		    
   ,invoice_id     
   ,buyer_id 	    
   ,package_id     
   ,draft_flag     
   ,remark         
   ,create_by 	    
   ,create_by_name 
   ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time	
   ,update_by 		
   ,update_by_name 
   ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time
   ,invoice_option_status
   ,submit_time
   ,app_no   
   ,option_type --20230215
   ,company_person_role_option
   ,from_unixtime(cast(financing_request_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as financing_request_time
from ods.ods_olea_cust_olea_buyer_invoices_record
;

