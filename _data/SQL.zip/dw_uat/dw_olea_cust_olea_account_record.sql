--drop table if exists dw_uat.dw_olea_cust_olea_account_record;
create table if not exists dw_uat.dw_olea_cust_olea_account_record
(`id`                                string               comment '                                                  '
,`txn_id`                            string               comment 'Transaction ID                                     '
,`entity_name`                       string               comment 'entity name                                              '
,`currency`                          string               comment 'currency                                                '
,`step_id`                           string               comment 'step id                                              '
,`step_name`                         string               comment 'step name                                              '
,`status`                            string               comment 'status                                                '
,`package_id`                        string               comment 'asset package id                                             '
,`tran_type`                         string               comment 'transaction type                                              '
,`trading_date`                      date                 comment 'trading date                                              '
,`product_no`                        string               comment 'product no                                              '
,`product_name`                      string               comment 'product name                                              '
,`supplier_id`                       string               comment 'supplier id                                             '
,`supplier_name`                     string               comment 'supplier name                                             '
,`buyer_id`                          string               comment 'buyer id                                              '
,`buyer_name`                        string               comment 'buyer name                                              '
,`investor_id`                       string               comment 'investor id                                             '
,`investor_name`                     string               comment 'investor name                                             '
,`from_bank_account`                 string               comment 'Payer`s bank account                                           '
,`to_bank_account`                   string               comment 'Payee`s bank account number                                           '
,`create_by`                         string               comment 'creator id                                             '
,`update_by`                         string               comment 'updater id                                             '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment 'Accounting Push Record Form'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_account_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`txn_id`                           
,`entity_name`                      
,`currency`                         
,`step_id`                          
,`step_name`                        
,`status`                           
,`package_id`                       
,`tran_type`                        
,nvl(from_unixtime(cast(`trading_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`trading_date`) as trading_date
,`product_no`                       
,`product_name`                     
,`supplier_id`                      
,`supplier_name`                    
,`buyer_id`                         
,`buyer_name`                       
,`investor_id`                      
,`investor_name`                    
,`from_bank_account`                
,`to_bank_account`                  
,`create_by`                        
,`update_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_account_record;