--drop table if exists dw_uat.dw_olea_cust_olea_check_item;
create table if not exists dw_uat.dw_olea_cust_olea_check_item
(`id`                                string               comment '  '
,`financing_ref_no`                  string               comment 'financing ref NO. '
,`check_field`                       string               comment 'check field name '
,`check_value`                       string               comment 'check value '
,`file_type`                         string               comment 'file type '
,`ocr_record_id`                     string               comment 'the last ocr record id '
,`check_record_id`                   string               comment 'check record id  '
,`file_no`                           string               comment 'file NO.  '
,`enable`                            string               comment ' '
,`remark`                            string               comment ' '
,`create_by`                         string               comment ' '
,`create_time`                       timestamp            comment ' '
,`update_by`                         string               comment ' '
,`update_time`                       timestamp            comment ' '
) comment 'checklist table'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_check_item partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`financing_ref_no`                 
,`check_field`                      
,`check_value`                      
,`file_type`                        
,`ocr_record_id`                    
,`check_record_id`                  
,`file_no`                          
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
from ods.ods_olea_cust_olea_check_item;