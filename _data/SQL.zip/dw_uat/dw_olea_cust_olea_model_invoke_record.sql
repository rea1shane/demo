--drop table if exists dw_uat.dw_olea_cust_olea_model_invoke_record;
create table if not exists dw_uat.dw_olea_cust_olea_model_invoke_record
(`id`                                string               comment '                                                  '
,`model_id`                          string               comment '模型表id                                             '
,`version_id`                        string               comment '版本表id                                             '
,`version_status`                    string               comment '运行时版本状态 new/valid                                 '
,`invoke_user`                       string               comment '执行发起人                                             '
,`invoke_result`                     string               comment '执行状态 环境安装错误/语法错误/执行中/执行成功/失败                      '
,`invoke_time`                       timestamp            comment '执行时间                                              '
,`outcome`                           string               comment '执行结果路径/唯一键                                        '
,`log`                               string               comment '执行日志                                              '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment 'model执行日志'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_model_invoke_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`model_id`                         
,`version_id`                       
,`version_status`                   
,`invoke_user`                      
,`invoke_result`                    
,nvl(from_unixtime(cast(`invoke_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`invoke_time`) as invoke_time
,`outcome`                          
,`log`                              
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,data_sync_status
,execution_parm  
from ods.ods_olea_cust_olea_model_invoke_record;