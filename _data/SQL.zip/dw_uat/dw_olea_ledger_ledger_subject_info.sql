--drop table if exists dw_uat.dw_olea_ledger_ledger_subject_info;
create table if not exists dw_uat.dw_olea_ledger_ledger_subject_info
(`id`                                string               comment '物理主键                                              '
,`subject_no`                        string               comment '科目号                                               '
,`subject_name`                      string               comment '科目名称                                              '
,`direction`                         string               comment '方向DC                                              '
,`parent_no`                         string               comment '上级科目                                              '
,`subject_level`                     string               comment '科目级别                                              '
,`enable`                            string               comment '启用/删除状态：0-禁用/删除，1-启用/正常                           '
,`remark`                            string               comment '备注                                                '
,`create_by`                         string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人                                               '
,`update_time`                       timestamp            comment '更新时间                                              '
,`ext_data`                          string               comment '扩展字段                                              '
) comment '科目配置表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_ledger_ledger_subject_info partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`subject_no`                       
,`subject_name`                     
,`direction`                        
,`parent_no`                        
,`subject_level`                    
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`ext_data`                         

from ods.ods_olea_ledger_ledger_subject_info;