--drop table if exists dw_uat.dw_olea_wkfl_act_re_procdef;
create table if not exists dw_uat.dw_olea_wkfl_act_re_procdef
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`CATEGORY_`                         string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`KEY_`                              string               comment '                                                  '
,`VERSION_`                          string               comment '                                                  '
,`DEPLOYMENT_ID_`                    string               comment '                                                  '
,`RESOURCE_NAME_`                    string               comment '                                                  '
,`DGRM_RESOURCE_NAME_`               string               comment '                                                  '
,`DESCRIPTION_`                      string               comment '                                                  '
,`HAS_START_FORM_KEY_`               string               comment '                                                  '
,`HAS_GRAPHICAL_NOTATION_`           string               comment '                                                  '
,`SUSPENSION_STATE_`                 string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_re_procdef partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`CATEGORY_`                        
,`NAME_`                            
,`KEY_`                             
,`VERSION_`                         
,`DEPLOYMENT_ID_`                   
,`RESOURCE_NAME_`                   
,`DGRM_RESOURCE_NAME_`              
,`DESCRIPTION_`                     
,`HAS_START_FORM_KEY_`              
,`HAS_GRAPHICAL_NOTATION_`          
,`SUSPENSION_STATE_`                
,`TENANT_ID_`                       

from ods.ods_olea_wkfl_act_re_procdef;