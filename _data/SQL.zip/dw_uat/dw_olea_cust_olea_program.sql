--alter table dw_uat.dw_olea_cust_olea_program       			   add columns (program_duration                 string  comment'项目期限');
--alter table dw_uat.dw_olea_cust_olea_program       			   add columns (project_type                     string  comment'项目类型');
--alter table dw_uat.dw_olea_cust_olea_program       			   add columns (program_funding_turnaround_time  int     comment'打款期限');
--alter table dw_uat.dw_olea_cust_olea_program       			   add columns (average_tenor                    int     comment'平均期限');
--alter table dw_uat.dw_olea_cust_olea_program       			   add columns (max_tenor_cap                    double  comment'最大期限比');
--alter table dw_uat.dw_olea_cust_olea_program       			   add columns (rating_type                      string  comment'Rating Type');
--alter table dw_uat.dw_olea_cust_olea_program       			   add columns (rating_grade                     string  comment'Rating Grade');


--alter table dw_uat.dw_olea_cust_olea_program 		    add columns(supplier_specific_anchor_names string comment'特别许可的supplier');
--alter table dw_uat.dw_olea_cust_olea_program 		    add columns(submit_time 	  timestamp comment'提交时间');
--alter table dw_uat.dw_olea_cust_olea_program 		    add columns(amend_version 	  string    comment'变更版本号');
--alter table dw_uat.dw_olea_cust_olea_program 		    add columns(parent_id   	  string 	comment'父类id');
--alter table dw_uat.dw_olea_cust_olea_program 		    add columns(change_type 	  string	comment'修改类型');
--alter table dw_uat.dw_olea_cust_olea_program 		    add columns(button_flag 	  string	comment'按钮标识');
--alter table dw_uat.dw_olea_cust_olea_program 	        add columns(`enable` 			  string	comment'是否已生效');

--202101新增字段advance_ratio
--alter table dw_uat.dw_olea_cust_olea_program add columns(advance_ratio double comment'advance_ratio');
--alter table dw_uat.dw_olea_cust_olea_program add columns(process_type  string comment'process_type');
--alter table dw_uat.dw_olea_cust_olea_program  change   commitment_start_date commitment_start_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_program  change   commitment_end_date   commitment_end_date    date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_program  change   program_offer_date    program_offer_date     date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_program  change   create_time   		create_time            timestamp comment'' ;
--alter table dw_uat.dw_olea_cust_olea_program  change   update_time   		update_time            timestamp comment'' ;
--alter table dw_uat.dw_olea_cust_olea_program  add  columns (app_no  		  string  		  comment '' );
--alter table dw_uat.dw_olea_cust_olea_program  add  columns (supplier_type  string  comment '' );

--drop table if exists dw_uat.dw_olea_cust_olea_program;
create table if not exists dw_uat.dw_olea_cust_olea_program
(
     id                                      string  comment ''
    ,program_no                              string  comment 'program No.'
	,investor_category                       string  comment ''
    ,company_id                              string  comment 'company ID'
    ,account_id                              string  comment 'account ID'
    ,name                                    string  comment 'name'
    ,commitment_start_date                   string  comment 'commitment start date'
    ,commitment_end_date                     string  comment 'commitment end date'
    ,investor_commitment_currency            string  comment 'investor commitment currency'
    ,investor_commitment_amount              string  comment 'investor commitment amount'
    ,program_status                          string  comment 'program status'
    ,audit_status                            string  comment 'audit status'
    ,agreement_status                        string  comment 'agreement status'
    ,skin_flag                               string  comment 'skin flag'
    ,olea_skin_rate                          string  comment 'olea skin rate'
    ,olea_skin_type                          string  comment 'olea skin type'
    ,products                                string  comment 'products'
    ,max_asset_tenor                         string  comment 'max asset tenor'
    ,min_asset_tenor                         string  comment 'min asset tenor'
    ,investment_pricing_benchmark            string  comment 'investment pricing benchmark'
    ,credit_rating_of_anchors                string  comment 'credit rating of anchors'
    ,program_offer_date                      string  comment 'program offer date'
    ,anchor_region                           string  comment 'anchor region'
    ,anchor_country                          string  comment 'anchor country'
    ,anchor_industry                         string  comment 'anchor industry'
    ,anchor_industry_other                   string  comment 'other anchor industry'
    ,anchor_industry_name                    string  comment 'anchor industry name'
    ,specific_anchor_names                   string  comment 'registered and approved anchor names '
    ,supplier_region                         string  comment 'supplier region'
    ,supplier_country                        string  comment 'supplier country'
    ,frozen_amount                           string  comment 'frozen amount'
    ,funded_amount                           string  comment 'funded amount'
    ,available_amount                        string  comment 'available amount'
    ,supplier_id                             string  comment 'supplier ID'
    ,remark                                  string  comment 'remark'
    ,create_by                               string  comment 'id of the person who created'
    ,create_by_name                          string  comment 'name of the person who created'
    ,create_time                             string  comment 'create time'
    ,update_by                               string  comment 'id of the person who updated'
    ,update_name                             string  comment 'name of the person who updated'
    ,update_time                             string  comment 'update time'
)partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_cust_olea_program partition(data_date='${hiveconf:DATA_DATE}')
select  
        id                                 
	   ,program_no 
	   ,investor_category	   
	   ,company_id                         
	   ,account_id                         
	   ,name                               
       ,from_unixtime(cast(commitment_start_date/1000 as bigint),'yyyy-MM-dd') as commitment_start_date              
       ,from_unixtime(cast(commitment_end_date/1000 as bigint),'yyyy-MM-dd')   as commitment_end_date                
       ,investor_commitment_currency       
       ,investor_commitment_amount         
       ,program_status                     
       ,audit_status                       
       ,agreement_status                   
       ,skin_flag                          
       ,olea_skin_rate                     
       ,olea_skin_type                     
       ,products                           
       ,max_asset_tenor                    
       ,min_asset_tenor                    
       ,investment_pricing_benchmark       
       ,credit_rating_of_anchors           
       ,from_unixtime(cast(program_offer_date/1000 as bigint),'yyyy-MM-dd')  as program_offer_date                 
       ,anchor_region                      
       ,anchor_country                     
       ,anchor_industry                    
       ,anchor_industry_other              
       ,anchor_industry_name               
       ,selected_buyergp_id              
       ,supplier_region                    
       ,supplier_country                   
       ,frozen_amount                      
       ,funded_amount                      
       ,available_amount                   
       ,supplier_type                        
       ,remark                             
       ,create_by                          
       ,create_by_name                     
       ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd') as create_time                        
       ,update_by                          
       ,update_name                        
       ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd') as update_time
	   ,advance_ratio
	   ,process_type
	   ,app_no  		
	   ,supplier_type	   
	   ,selected_supplier_id
	   ,from_unixtime(cast(submit_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as submit_time 	
	   ,amend_version 	
	   ,parent_id   	
	   ,change_type 	
	   ,button_flag 
	   ,`enable`	   
	   ,program_duration               
	   ,project_type                   
	   ,program_funding_turnaround_time
	   ,average_tenor                  
	   ,max_tenor_cap                  
	   ,rating_type                    
	   ,rating_grade
       ,project_code	  
       ,client_extension_type
	   ,buffer_period 		 
	   ,utilised_amount
	   ,cost_of_funds
	   ,cost_of_type
	   ,profit_share 
	   ,net_settlement_opt
	   ,payment_instruction  --20230215
	   ,maturity_terminal_date
from ods.ods_olea_cust_olea_program
;	   


