--alter table dw_uat.dw_olea_cust_olea_company  add columns(filling_task_status string comment'外部建档任务启动状态');

create table if not exists dw_uat.dw_olea_cust_olea_company
( 
    id                                 string  comment ''               
   ,app_no                             string  comment ''
   ,first_commit_flag                  string  comment ''
   ,authorization_sign_flag            string  comment ''
   ,dd_state                           string  comment ''
   ,dd_approved_time                   string  comment ''
   ,client_state                       string  comment ''
   ,pre_client_state                   string  comment ''
   ,company_type                       string  comment ''
   ,modify_portal                      string  comment ''
   ,investment_type                    string  comment ''
   ,submit_phase                       string  comment ''
   ,level_type                         string  comment ''
   ,group_id                           string  comment ''
   ,create_type                        string  comment ''
   ,olea_id                            string  comment ''
   ,city                               string  comment ''
   ,street                             string  comment ''
   ,tax_identification_num             string  comment ''
   ,tax_residence_country              string  comment ''
   ,company_name_local                 string  comment ''
   ,company_name                       string  comment ''
   ,country                            string  comment ''
   ,company_registration_document_type string  comment ''
   ,company_unique_code                string  comment ''
   ,third_party_code                   string  comment ''
   ,registration_doc_expiry_date       string  comment ''
   ,company_address                    string  comment ''
   ,legal_person_name                  string  comment ''
   ,industry                           string  comment ''
   ,industry_name                      string  comment ''
   ,mobile_no                          string  comment ''
   ,mobile_prefix                      string  comment ''
   ,operating_country                  string  comment ''
   ,operating_city                     string  comment ''
   ,operating_street                   string  comment ''
   ,business_manager                   string  comment ''
   ,ops_id                             string  comment ''
   ,`file_id`                          string  comment ''
   ,model_type                         string  comment ''
   ,investor_category                  string  comment ''
   ,remark                             string  comment ''
   ,create_by                          string  comment ''
   ,create_by_name                     string  comment ''
   ,create_time                        string  comment ''
   ,update_by                          string  comment ''
   ,update_by_name                     string  comment ''
   ,update_time                        string  comment ''
)partitioned by (data_date string)
stored as parquet;
--alter table dw_uat.dw_olea_cust_olea_company  change   dd_approved_time   dd_approved_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_company  change   registration_doc_expiry_date   registration_doc_expiry_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_company  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_company  change   update_time   update_time  timestamp      comment'' ;


insert overwrite table dw_uat.dw_olea_cust_olea_company  partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                                 
     ,app_no                             
     ,first_commit_flag                  
     ,authorization_sign_flag            
     ,dd_state                           
     ,from_unixtime(cast(dd_approved_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as dd_approved_time                   
     ,client_state                       
     ,pre_client_state                   
	 ,company_type                       
	 ,modify_portal                       
	 ,investment_type                     
	 ,submit_phase                        
	 ,level_type                          
	 ,group_id                            
	 ,create_type                         
	 ,olea_id                             
	 ,city                                
	 ,street                              
	 ,tax_identification_num              
	 ,tax_residence_country               
     ,company_name_local                 
     ,company_name                       
     ,country                            
     ,company_registration_document_type 
     ,company_unique_code                
     ,third_party_code                   
     ,from_unixtime(cast(registration_doc_expiry_date/1000 as bigint),'yyyy-MM-dd') as registration_doc_expiry_date       
     ,company_address                    
     ,legal_person_name                  
     ,industry                           
     ,industry_name                      
     ,mobile_no                          
     ,mobile_prefix                      
     ,operating_country                  
     ,operating_city                     
     ,operating_street                   
     ,business_manager                   
     ,ops_id                             
     ,`file_id`                          
     ,model_type                         
     ,investor_category                  
     ,remark                             
     ,create_by                          
     ,create_by_name                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time                        
     ,update_by                          
     ,update_by_name                     
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time   
     ,filling_task_status	
	 ,email	 
	 ,investor_send_via_sftp
	 ,dd_type               
	 ,supplier_portal_access
	 ,parent_company_name
	 ,from_unixtime(cast(date_of_incorporation/1000 as bigint),'yyyy-MM-dd') as date_of_incorporation
	 ,insurance_country_grade
	 ,back_up_commercial_officer_name
	 ,terms_conditions_sign_status
	 ,data_source
	 ,country_of_incorporation
  from ods.ods_olea_cust_olea_company
;