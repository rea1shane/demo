create table if not exists dw_uat.dw_olea_cust_olea_account_participant
( 
   id               string      comment 'id'
  ,`type`           string      comment 'olea account type'
  ,currency         string      comment 'currency'
  ,participant_id   string      comment 'participant id'
  ,subject_no       string      comment 'subject no'
  ,create_time      timestamp   comment 'create time'
  ,update_time      timestamp   comment 'update time'
 )
 COMMENT''
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_account_participant partition(data_date='${hiveconf:DATA_DATE}')
select 
   id            
  ,`type`          
  ,currency      
  ,participant_id
  ,subject_no    
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 		  
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
from ods.ods_olea_cust_olea_account_participant a 
;




































