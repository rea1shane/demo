--drop table if exists dw_uat.dw_olea_wkfl_act_ge_bytearray;
create table if not exists dw_uat.dw_olea_wkfl_act_ge_bytearray
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`DEPLOYMENT_ID_`                    string               comment '                                                  '
,`BYTES_`                            string               comment '                                                  '
,`GENERATED_`                        string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_ge_bytearray partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`NAME_`                            
,`DEPLOYMENT_ID_`                   
,`BYTES_`                           
,`GENERATED_`                       

from ods.ods_olea_wkfl_act_ge_bytearray;