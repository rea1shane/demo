create table if not exists dw_uat.dw_olea_cust_olea_company_client_due_diligence_audit
 (
	id 			 int	 comment 'primary key'
   ,company_id   int     comment 'company id'
   ,app_no       	  string  comment 'Filled after submit,process NO.'
   ,initial_dd_rating string  comment 'Simplified/Standard/Enhanced'
   ,final_dd_rating   string  comment 'Simplified/Standard/Enhanced'
   ,parent_shareholdings_percentage int     comment 'Integer between 1-100'
   ,public_listed 			string  comment 'Yes/No'
   ,publicly_listed_on		string  comment 'Publicly Listed On'
   ,regulated_market 		string  comment 'Yes/No'
   ,financial_institution 	string  comment 'Yes/No'
   ,financial_action_task_force 	  string  comment 'Yes/No'
   ,equivalent_low_risk_jurisdictions string  comment 'Yes/No'
   ,remark 							  string  comment 'Required when Initial DD Rating and Final DD Rating are inconsistent. Maximum 500 characters.'
   ,create_by 						  int     comment 'creator id'
   ,create_by_name					  string  comment 'creator name'
   ,create_time TIMESTAMP 	  comment 'create time'
   ,update_by 	int           comment 'updator id'
   ,update_by_name string     comment 'updator name'
   ,update_time   TIMESTAMP   comment 'update time'
)comment 'company Client Due Diligence Audit'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_company_client_due_diligence_audit partition (data_date='${hiveconf:DATA_DATE}')
select 
    id 			 
   ,company_id   
   ,app_no       	  
   ,initial_dd_rating 
   ,final_dd_rating   
   ,parent_shareholdings_percentage 
   ,public_listed 			
   ,publicly_listed_on		
   ,regulated_market 		
   ,financial_institution 	
   ,financial_action_task_force 	  
   ,equivalent_low_risk_jurisdictions 
   ,remark 							  
   ,create_by 						 
   ,create_by_name					  
   ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time  	  
   ,update_by 	
   ,update_by_name 
   ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time   
from ods.ods_olea_cust_olea_company_client_due_diligence_audit
;