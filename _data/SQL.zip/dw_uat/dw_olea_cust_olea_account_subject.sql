--drop table if exists dw_uat.dw_olea_cust_olea_account_subject;
create table if not exists dw_uat.dw_olea_cust_olea_account_subject
(`id`                                string               comment '                                                  '
,`step_id`                           string               comment 'step ID                                           '
,`subject_no`                        string               comment 'subject No.                                       '
,`subject_name`                      string               comment 'subject name                                      '
,`direction`                         string               comment 'direction                                         '
,`event`                             string               comment 'event                                             '
,`create_by`                         string               comment 'id of the person who created                      '
,`update_by`                         string               comment 'id of the person who updated                      '
,`create_time`                       timestamp            comment 'create time                                       '
,`update_time`                       timestamp            comment 'update time                                       ') comment '会计科目表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_account_subject partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`step_id`                          
,`subject_no`                       
,`subject_name`                     
,`direction`                        
,`event`                            
,`create_by`                        
,`update_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_account_subject;