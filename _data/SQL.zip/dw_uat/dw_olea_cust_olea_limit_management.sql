create table if not exists dw_uat.dw_olea_cust_olea_limit_management
( 
   id                  string       comment'唯一主键'
  ,olea_id             string       comment'Olea Id，link to olea_company.olea_id'
  ,program_no          string       comment'投资项目编号,link to olea_program.program_no'
  ,currency            string       comment'币种 for currency'
  ,limit_amount        double       comment'限制金额,limit amount'
  ,utilised_amount     double       comment'已使用金额 ，utilised amount'
  ,internal_comments   string       comment'限额调整意见 for internal comments'
  ,documents_key       string       comment'限额调整意见附件文件key,对应model_file表中的group_key, documents busi key'
  ,limit_type          string       comment'限制类型：BuyerGroup、BuyerGroup_Supplier、InvestorProgram、InvestorProgram_BuyerGroup、InvestorProgram_BuyerGroup_Supplier'
  ,parent_id           string       comment'类型为supplier时存在,关联其附属的buyer_group记录id,link olea_limit_management.id'
  ,is_enable           string       comment'是否启用 启用YES 弃用NO 目前只有InvestorProgram_BuyerGroup、InvestorProgram_BuyerGroup_Supplier 两种类型会出现启用 在amend之后'
  ,create_by           string       comment'创建人id, create id'
  ,create_by_name      string       comment'创建人名称, create name'
  ,create_time         timestamp    comment'创建时间 , create time'
  ,update_by           string       comment'更新人id, update id'
  ,update_by_name      string       comment'最后更新人名称, update name'
  ,update_time         timestamp    comment'更新时间, update time'
 )
 COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_limit_management partition(data_date='${hiveconf:DATA_DATE}')
select 
   id               
  ,olea_id          
  ,program_no       
  ,currency         
  ,limit_amount     
  ,utilised_amount  
  ,internal_comments
  ,documents_key    
  ,limit_type       
  ,parent_id        
  ,is_enable        
  ,create_by 	 			
  ,create_by_name 			
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
  ,update_by 
  ,update_by_name	  
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
  ,buyer_entity_utilised_amount
  ,new_update_time
  ,new_update_by_name
from ods.ods_olea_cust_olea_limit_management a 
;


































































