--drop table if exists dw_uat.dw_olea_data_ansi_olea_upload_record;
create table if not exists dw_uat.dw_olea_data_ansi_olea_upload_record
(`id`                                string               comment '                                                  '
,`table_name`                        string               comment 'Schema.Table                                      '
,`uploaded_by`                       string               comment 'Uploaded By                                       '
,`upload_result`                     string               comment 'Upload Result                                     '
,`upload_time`                       timestamp            comment 'Upload Time                                       '
,`log`                               string               comment 'Log                                               '
,`create_by`                         string               comment '创建人id                                             '
,`update_by`                         string               comment '更新人id                                             '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment 'Upload Record'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_data_ansi_olea_upload_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`table_name`                       
,`uploaded_by`                      
,`upload_result`                    
,nvl(from_unixtime(cast(`upload_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`upload_time`) as upload_time
,`log`                              
,`create_by`                        
,`update_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_data_ansi_olea_upload_record;