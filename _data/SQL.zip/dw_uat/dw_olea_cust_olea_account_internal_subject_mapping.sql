create table if not exists dw_uat.dw_olea_cust_olea_account_internal_subject_mapping
( 
   id                  string      comment'id'
  ,transfer_type       string      comment'transfer type'
  ,currency            string      comment'currency'
  ,from_subject_no     string      comment'from subject no'
  ,from_subject_name   string      comment'from subject name'
  ,to_subject_no       string      comment'to subject no'
  ,to_subject_name     string      comment'to subject name'
  ,create_by           string      comment'creator id'
  ,update_by           string      comment'modifier id'
  ,create_time         timestamp   comment'create time'
  ,update_time         timestamp   comment'update time'
 )
 COMMENT''
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_account_internal_subject_mapping partition(data_date='${hiveconf:DATA_DATE}')
select 
   id                 
  ,transfer_type      
  ,currency           
  ,from_subject_no    
  ,from_subject_name  
  ,to_subject_no      
  ,to_subject_name    	
  ,create_by         
  ,update_by         
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time        
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
from ods.ods_olea_cust_olea_account_internal_subject_mapping 
;
















































