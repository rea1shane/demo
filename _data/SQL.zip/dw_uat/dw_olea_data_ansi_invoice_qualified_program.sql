create table if not exists dw_uat.dw_olea_data_ansi_invoice_qualified_program
( 
    id                              string
   ,execution_id                    string
   ,invoice_no                      string
   ,investor_program_id             string
   ,pair_runtime                    timestamp
   ,investor_return_rate            double
   ,investor_yield                  double
   ,advanced_ratio                  double
   ,net_financing_amount_investor   double
   ,tenor                           int
   ,estimated_funding_date          date
   ,create_time                     timestamp
   ,update_date                     date
   ,update_time                     timestamp
 )
 COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_data_ansi_invoice_qualified_program partition(data_date='${hiveconf:DATA_DATE}')
select 
     id
    ,execution_id
    ,invoice_no
    ,investor_program_id
    ,from_unixtime(cast(pair_runtime/1000 as bigint),'yyyy-MM-dd HH:mm:ss')   as pair_runtime
    ,investor_return_rate
    ,investor_yield
    ,advanced_ratio
    ,net_financing_amount_investor
    ,tenor
    ,from_unixtime(cast(estimated_funding_date/1000 as bigint),'yyyy-MM-dd')  as estimated_funding_date
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')    as create_time
    ,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd')             as update_date
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')    as update_time 
from ods.ods_olea_data_ansi_invoice_qualified_program a 
;































