create table if not exists dw_uat.dw_olea_cust_olea_autocheck_record_audit
(  id                    string  comment ''
   ,company_id           string  comment ''
   ,app_no               string  comment ''
   ,check_channel        string  comment ''
   ,`type`               string  comment ''
   ,`result`             string  comment ''
   ,check_date           string  comment ''
   ,ongoing_data_active  string  comment ''
   ,remark               string  comment ''
   ,create_by            string  comment ''
   ,create_time          string  comment ''
   ,update_by            string  comment ''
   ,update_time          string  comment ''
 )comment ''
 partitioned by (data_date string )
 stored as parquet
;
--alter table dw_uat.dw_olea_cust_olea_autocheck_record_audit  change   update_time   update_time  timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_autocheck_record_audit  change   check_date   check_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_autocheck_record_audit  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_autocheck_record_audit  change   update_time   update_time  timestamp      comment'' ;


insert overwrite table dw_uat.dw_olea_cust_olea_autocheck_record_audit partition(data_date='${hiveconf:DATA_DATE}')
select 
     id                   
     ,company_id          
     ,app_no              
     ,check_channel       
     ,`type`              
     ,`result`            
     ,from_unixtime(cast(a.check_date/1000 as bigint),'yyyy-MM-dd') as check_date          
     ,ongoing_data_active 
     ,remark              
     ,create_by           
     ,from_unixtime(cast(a.create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time         
     ,update_by           
     ,from_unixtime(cast(a.update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time         
  from ods.ods_olea_cust_olea_autocheck_record_audit a
  ;
  