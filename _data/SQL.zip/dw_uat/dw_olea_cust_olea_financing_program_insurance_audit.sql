create external table if not exists dw_uat.dw_olea_cust_olea_financing_program_insurance_audit 
 (
	id int                      COMMENT '唯一主键，自增雪花id'
	,financing_program_id int   COMMENT '融资项目ID'
	,financing_program_audit_id int      COMMENT '融资项目审核记录ID link to olea_financing_program_audit.id'
	,buyer_group_id  int                 COMMENT '买方集团id(buyer group id) link to olea_company.id'
	,buyer_entity_id int                 COMMENT '买方子公司ID link to olea_company.id'
	,buyer_entity_name       string      COMMENT '买方子公司名称 for front Buyer Entity Name'
	,max_invoicing_period 	 int         COMMENT 'Max Invoicing Period'
	,max_payment_terms 		 int         COMMENT 'Max Payment Terms'
	,loss_payee 		     string      COMMENT 'Loss Payee(Yes/No)'
	,loss_payee_investor_id  int         COMMENT 'Loss Payee Yes 对象Id'
	,loss_payee_investor     string      COMMENT 'Loss Payee Yes 对象'
	,create_by 				 int         COMMENT '创建人userId'
	,create_by_name          string      COMMENT '创建人'
	,create_time 		     timestamp   COMMENT '创建时间'
	,update_by 				 int         COMMENT '更新人userId'
	,update_by_name 		 string      COMMENT '更新人'
	,update_time 		 	 timestamp   COMMENT '最后更新时间'
)comment '融资项目买方保险额度记录表'
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_program_insurance_audit partition(data_date='${hiveconf:DATA_DATE}')
	select 
	     id 						-- '唯一主键，自增雪花id'
		,financing_program_id 		-- '融资项目ID'
		,financing_program_audit_id -- '融资项目审核记录ID link to olea_financing_program_audit.id'
		,buyer_group_id  			-- '买方集团id(buyer group id) link to olea_company.id'
		,buyer_entity_id 			-- '买方子公司ID link to olea_company.id'
		,buyer_entity_name string   -- '买方子公司名称 for front Buyer Entity Name'
		,max_invoicing_period 		-- 'Max Invoicing Period'
		,max_payment_terms 			-- 'Max Payment Terms'
		,loss_payee 				-- 'Loss Payee(Yes/No)'
		,loss_payee_investor_id  	-- 'Loss Payee Yes 对象Id'
		,loss_payee_investor     	-- 'Loss Payee Yes 对象'
		,create_by 					-- '创建人userId'
		,create_by_name          	-- '创建人'
		,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 		    	-- '创建时间'
		,update_by 					-- '更新人userId'
		,update_by_name 			-- '更新人'
		,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 		 		-- '最后更新时间'
	from ods.ods_olea_cust_olea_financing_program_insurance_audit
	;
