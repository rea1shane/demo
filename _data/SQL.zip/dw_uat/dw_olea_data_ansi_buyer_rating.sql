create table if not exists dw_uat.dw_olea_data_ansi_buyer_rating
(
 id						string comment ''
,parent_id          	string comment ''
,parent_name        	string comment ''
,snp_pd             	string comment ''
,snp_rating         	string comment ''
,moody_pd           	string comment ''
,moody_rating       	string comment ''
,refi_pd            	string comment ''
,refi_rating        	string comment ''
,nus_pd             	string comment ''
,nus_rating         	string comment ''
,olea_pd            	string comment ''
,olea_rating        	string comment ''
,scb_pd             	string comment ''
,scb_rating         	string comment ''
)partitioned by(data_date string) 
stored as parquet
;


insert overwrite table dw_uat.dw_olea_data_ansi_buyer_rating partition(data_date='${hiveconf:DATA_DATE}')
select 
	    id				
       ,parent_id      
       ,parent_name    
       ,snp_pd         
       ,snp_rating     
       ,moody_pd       
       ,moody_rating   
       ,refi_pd        
       ,refi_rating    
       ,nus_pd         
       ,nus_rating     
       ,olea_pd        
       ,olea_rating    
       ,scb_pd         
       ,scb_rating     
	   ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') AS update_time
	   ,fitch_pd  	  
	   ,fitch_rating   
	   ,fin_pd  	  	  
	   ,olea_gran_grade
       ,from_unixtime(cast(data_date/1000 as bigint),'yyyy-MM-dd') as model_date	  
	   ,computed_olea_gran_grade
       ,days_past_due           
	   ,days_to_recovery        
  from ods.ods_olea_data_ansi_buyer_rating
;