--drop table if exists dw_uat.dw_olea_cust_olea_status_transfer_record;
create table if not exists dw_uat.dw_olea_cust_olea_status_transfer_record
(`id`                                string               comment '                                                  '
,`business_id`                       string               comment '业务id（olea_company表ID）                             '
,`app_no`                            string               comment '流程编号（olea_wkfl.wkfl_app_main表ID）                  '
,`busi_key`                          string               comment '随机生成业务流水（用户生成影像上传临时业务编号）                          '
,`business_type`                     string               comment '业务类型                                              '
,`status_type`                       string               comment '状态类型                                              '
,`operation_status`                  string               comment '状态                                                '
,`comment`                           string               comment '备注                                                '
,`enable`                            string               comment '是否为生效记录                                           '
,`create_by`                         string               comment '创建人id                                             '
,`create_by_name`                    string               comment '创建人名称                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人id                                             '
,`update_time`                       timestamp            comment '更新时间                                              '
) comment '状态流转记录表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_status_transfer_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`business_id`                      
,`app_no`                           
,`busi_key`                         
,`business_type`                    
,`status_type`                      
,`operation_status`                 
,`comment`                          
,`enable`                           
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_status_transfer_record;