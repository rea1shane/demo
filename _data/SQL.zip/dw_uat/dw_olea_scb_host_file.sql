--drop table if exists dw_uat.dw_olea_scb_host_file;
create table if not exists dw_uat.dw_olea_scb_host_file
(`id`                                string               comment '                                                  '
,`file_name`                         string               comment '文件名称                                              '
,`type`                              string               comment '文件类型                                              '
,`file_path`                         string               comment '文件在sftp的路径                                        '
,`file_key`                          string               comment '文件标识                                              '
,`report_id`                         string               comment '文件解析的report_id                                    '
,`status`                            string               comment '文件状态                                              '
,`download_user`                     string               comment '下载文件人名称                                           '
,`download_user_id`                  string               comment '下载文件人用户id                                         '
,`remark`                            string               comment '备注                                                '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_scb_host_file partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`file_name`                        
,`type`                             
,`file_path`                        
,`file_key`                         
,`report_id`                        
,`status`                           
,`download_user`                    
,`download_user_id`                 
,`remark`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,dir_path
from ods.ods_olea_scb_host_file;