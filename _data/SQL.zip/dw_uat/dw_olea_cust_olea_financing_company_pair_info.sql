create table if not exists  dw_uat.dw_olea_cust_olea_financing_company_pair_info 
(
  id 						   		         int 			     COMMENT	 '唯一主键，自增雪花id',
  buyer_olea_id       		     string  		   COMMENT	 '公司buyer oleaId，对应company表中的olea_id字段',
  supplier_olea_id   		       string        COMMENT 	'公司supplier oleaId，对应company表中的olea_id字段',
  early_alert_monitoring_flag  string        COMMENT 'EAM资产（t+6）标记：YES/NO',
  overdue_financing_id 				 string        COMMENT '逾期资产(即,t+6资产)的ID,多个用逗号分割',
  pair_status 								 string 			 COMMENT 'buyer supplier limit block status: BLOCKED/UNBLOCKED',
  remark 											 string        COMMENT '备注',
  create_by 								   int           COMMENT '创建人userId',
  create_by_name 					     string        COMMENT '创建人',
  create_time 				 				 timestamp     COMMENT '创建时间',
  update_by 									 int           COMMENT '更新人userId',
  update_by_name 						   string        COMMENT '更新人',
  update_time         			   timestamp     COMMENT '最后更新时间'
) 
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_company_pair_info  partition(data_date='${hiveconf:DATA_DATE}')
select 
        id 						   		            
       ,buyer_olea_id       		            
       ,supplier_olea_id   		            
       ,early_alert_monitoring_flag 	
       ,overdue_financing_id 			
       ,pair_status 							
       ,remark 									
       ,create_by 								
       ,create_by_name 					
       ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd')  as create_time  			
       ,update_by 								
       ,update_by_name 					
       ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd')  as update_time  
 from  ods.ods_olea_cust_olea_financing_company_pair_info 
 ;         