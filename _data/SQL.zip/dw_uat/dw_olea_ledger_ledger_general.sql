--drop table if exists dw_uat.dw_olea_ledger_ledger_general;
create table if not exists dw_uat.dw_olea_ledger_ledger_general
(`id`                                string               comment '主键id                                              '
,`subject_no`                        string               comment '账户所属科目号                                           '
,`org_id`                            string               comment '入账机构                                              '
,`currency`                          string               comment '币种                                                '
,`credit_balance`                    string               comment '贷方余额                                              '
,`debit_balance`                     string               comment '借方余额                                              '
,`direction`                         string               comment '科目方向                                              '
,`subject_name`                      string               comment '科目名称                                              '
,`bank_code_no`                      string               comment '资金方                                               '
,`occur_date`                        date                 comment '总账日期                                              '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_by`                         string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人                                               '
,`update_time`                       timestamp            comment '更新时间                                              '
) comment '账务总账'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_ledger_ledger_general partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`subject_no`                       
,`org_id`                           
,`currency`                         
,`credit_balance`                   
,`debit_balance`                    
,`direction`                        
,`subject_name`                     
,`bank_code_no`                     
,nvl(from_unixtime(cast(`occur_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`occur_date`) as occur_date
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_ledger_ledger_general;