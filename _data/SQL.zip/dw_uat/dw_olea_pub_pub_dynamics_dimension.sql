--drop table if exists dw_uat.dw_olea_pub_pub_dynamics_dimension;
create table if not exists dw_uat.dw_olea_pub_pub_dynamics_dimension
(`id`                                string               comment '                                                  '
,`dimension_code`                    string               comment '对应dynamic dimension code 唯一                       '
,`code`                              string               comment '业务自己的code                                         '
,`name`                              string               comment '名称                                                '
,`status`                            string               comment '状态                                                '
,`error_msg`                         string               comment '同步到dynamics的错误信息                                  '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment 'dynamics 365同步状况'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_pub_dynamics_dimension partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`dimension_code`                   
,`code`                             
,`name`                             
,`status`                           
,`error_msg`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_pub_pub_dynamics_dimension;