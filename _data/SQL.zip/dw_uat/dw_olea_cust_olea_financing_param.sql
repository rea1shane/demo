--alter table dw_uat.dw_olea_cust_olea_financing_param  change financing_ratio   advance_ratio  	date comment'展期完成后的融资到期日';
--alter table dw_uat.dw_olea_cust_olea_financing_param  change customer_rate  	nominal_rate  	date comment'展期完成后的融资到期日';


create table if not exists dw_uat.dw_olea_cust_olea_financing_param
(
  id                 string  comment 'primary key id'
 ,supplier           string  comment 'Supplier Name (LLSI)'
 ,buyer              string  comment 'Buyer Name (LLSI)'
 ,currency           string  comment 'Currency'
 ,product_type       string  comment 'Product Type'
 ,financing_ratio    string  comment 'Financing Ratio (%)'
 ,customer_rate      string  comment 'Customer Rate (%)'
 ,status             string  comment 'whether in effect'
 ,enable             string  comment 'in effect flag'
 ,create_by          string  comment 'creator id'
 ,create_by_name     string  comment 'creator name'
 ,create_time        string  comment 'create time'
 ,update_by          string  comment 'updator id'
 ,update_by_name     string  comment 'updator name'
 ,update_time        string  comment 'update time'
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_cust_olea_financing_param  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing_param  change   update_time   update_time  timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_param partition(data_date='${hiveconf:DATA_DATE}')
select 
      id             
     ,supplier       
     ,buyer          
     ,currency       
     ,product_type   
     ,advance_ratio
     ,nominal_rate  
     ,status         
     ,enable         
     ,create_by      
     ,create_by_name 
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 
     ,update_by      
     ,update_by_name 
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 	   
 from ods.ods_olea_cust_olea_financing_param
 ;
