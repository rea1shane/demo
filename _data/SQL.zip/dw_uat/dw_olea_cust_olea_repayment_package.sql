--alter table dw_uat.dw_olea_cust_olea_repayment_package         add columns (total_actual_tpp_invoice_fee     double  comment'Total Actual TPP Invoice Fee');
--alter table dw_uat.dw_olea_cust_olea_repayment_package         add columns (total_tpp_invoice_fee_adjustment double  comment'Total TPP Invoice Fee Adjustment');

--alter table dw_uat.dw_olea_cust_olea_repayment_package  add  columns (model_type  			  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_repayment_package  add  columns (`type`      			  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_repayment_package  add  columns (total_repurchased_price  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_repayment_package  add  columns (repayment_time  		  timestamp  comment '' );
--alter table dw_uat.dw_olea_cust_olea_repayment_package  change   actual_received_date   actual_received_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_repayment_package  change   create_time   create_time  timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_repayment_package  change   update_time   update_time  timestamp      comment'' ;


create table if not exists dw_uat.dw_olea_cust_olea_repayment_package
 (
  id                                       bigint                   comment ''
 ,olea_id                                  string                   comment 'olea ID'
 ,asset_quantity                           bigint                   comment 'asset quantity'
 ,currency                                 string                   comment 'currency'
 ,payment_ref_no                           string                   comment 'payment reference No.'
 ,total_principal_amount                   decimal(20,8)            comment 'total principal amount'
 ,total_actual_received_amount             decimal(20,8)            comment 'total actual received amount'
 ,actual_received_date                     string           	    comment 'actual received date'
 ,total_intermediary_bank_fees             decimal(20,8)            comment 'total intermediary bank fees'
 ,total_repayment_shortage                 decimal(20,8)            comment 'total repayment shortage'
 ,supplier                                 string            		comment 'supplier'
 ,buyer                                    string            		comment 'buyer'
 ,total_financing_amount                   decimal(20,8)            comment 'total financing amount'
 ,repayment_operator_id                    bigint                   comment 'repayment operator ID'
 ,repayment_operator_name                  string                   comment 'repayment operator name'
 ,repayment_status                         string                   comment 'repayment status'
 ,modify_flag                              string                   comment 'modify flag'
 ,comments                                 string                   comment 'comments'
 ,remark                                   string                   comment 'remark'
 ,create_by                                bigint                   comment 'id of the person who created'
 ,create_by_name                           string                   comment 'name of the person who created'
 ,update_by                                bigint                   comment 'id of the person who updated'
 ,update_by_name                           string                   comment 'name of the person who updated'
 ,create_time                              string                   comment ''
 ,update_time                              string                   comment '' 
)partitioned by (data_date string)
stored as parquet;
 
insert overwrite table dw_uat.dw_olea_cust_olea_repayment_package partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                                 
     ,olea_id	 
	 ,asset_quantity 
     ,currency                        
     ,payment_ref_no                  
     ,total_principal_amount          
     ,total_actual_received_amount    
     ,from_unixtime(cast(actual_received_date/1000 as bigint),'yyyy-MM-dd') as actual_received_date            
     ,total_intermediary_bank_fees    
     ,total_repayment_shortage        
     ,supplier                        
     ,buyer                           
     ,total_financing_amount          
     ,repayment_operator_id           
     ,repayment_operator_name         
     ,repayment_status                
     ,modify_flag                     
     ,comments                        
     ,remark                          
     ,create_by  
     ,create_by_name	 
     ,update_by  
	 ,update_by_name	 
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time                         
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time    
	 ,model_type  			
	 ,`type`      			
	 ,total_repurchased_price
	 ,from_unixtime(cast(repayment_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as repayment_time  
     ,total_actual_tpp_invoice_fee    
	 ,total_tpp_invoice_fee_adjustment
	 ,data_source
	 ,project_code
	 ,total_outstanding_amount
	 ,payer
	 ,total_interest_adjustment
	 ,tpp_available_flag
  from ods.ods_olea_cust_olea_repayment_package
  ;
  