--alter table dw_uat.dw_olea_pub_pub_holiday   add columns (currency_code     string  comment'币种');

--drop table if exists dw_uat.dw_olea_pub_pub_holiday;
create table if not exists dw_uat.dw_olea_pub_pub_holiday
(`id`                                string               comment '节假日编号                                             '
,`date`                              date                 comment '日期                                                '
,`holiday`                           string               comment '是否节假日：枚举类型                                        '
,`area_code`                         string               comment '地区名称：枚举类型                                         '
,`year`                              string               comment '年份                                                '
,`day_of_week`                       string               comment '星期几                                               '
,`enable`                            string               comment '启用/删除状态：0-禁用/删除，1-启用/正常                           '
,`remark`                            string               comment '备注                                                '
,`create_time`                       timestamp            comment '创建时间                                              '
,`create_by`                         string               comment '创建人userId                                         '
,`update_time`                       timestamp            comment '最后更新时间                                            '
,`update_by`                         string               comment '更新人userId                                         '
) 
comment '系统节假日表'
partitioned by(data_date string)  stored as parquet
;
 
insert overwrite table  dw_uat.dw_olea_pub_pub_holiday partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,nvl(from_unixtime(cast(`date`/1000 as bigint),'yyyy-MM-dd'),`date`) as `date`
,`holiday`                          
,`area_code`                        
,`year`                             
,`day_of_week`                      
,`enable`                           
,`remark`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`     
,currency_code                   
from ods.ods_olea_pub_pub_holiday
;