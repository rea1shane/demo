


--alter table dw_uat.dw_olea_cust_olea_redemption_package  change   actual_redemption_date  actual_redemption_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_redemption_package  change   investor_funding_date   investor_funding_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_redemption_package  change   complete_time   		 complete_time	timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_redemption_package  change   create_time     		 create_time 	timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_redemption_package  change   update_time     		 update_time  	timestamp      comment'' ;

--drop table if exists dw_uat.dw_olea_cust_olea_redemption_package;
create table if not exists dw_uat.dw_olea_cust_olea_redemption_package
(
    id                                 string         comment ''
   ,`type`                             string         comment ''
   ,olea_id                            string         comment 'Refund Package ID'
   ,fund_package_id                    string         comment ''
   ,export_status                      string         comment 'Export Status'
   ,package_status                     string         comment 'Package Status'
   ,asset_quantity                     string         comment 'asset quantity'
   ,currency                           string         comment 'currency'
   ,actual_redemption_date             string         comment 'actual redemption date'
   ,investor_funding_date              string         comment ''
   ,complete_time                      string         comment ''
   ,payment_ref_no                     string         comment 'payment reference No.'
   ,investor_id                        string         comment 'investor ID'
   ,investor                           string         comment 'investor'
   ,investor_account_id                string         comment 'investor account ID'
   ,investor_account_name              string         comment 'investor account name'
   ,investor_account_no                string         comment 'investor account No.'
   ,olea_account_name                  string         comment 'olea account name'
   ,olea_account_no                    string         comment 'olea account No.'
   ,return_amount                      string         comment ''
   ,total_funding_amount               string         comment 'total funding amount'
   ,total_overdue_interest             string         comment ''
   ,investor_interest_amount           string         comment 'investor interest amount'
   ,redemption_adjustment_amount       string         comment 'redemption adjustment amount'
   ,estimated_redemption_amount        string         comment 'estimated redemption amount'
   ,actual_redemption_amount           string         comment 'actual redemption amount'
   ,redemption_operator_id             string         comment 'redemption operator ID'
   ,comments                           string         comment 'comments'
   ,remark                             string         comment 'remark'
   ,create_by                          string         comment 'id of the person who created'
   ,update_by                          string         comment 'id of the person who updated'
   ,create_time                        string         comment ''
   ,update_time                        string         comment ''
)partitioned by (data_date string)
stored as parquet;

insert overwrite table dw_uat.dw_olea_cust_olea_redemption_package partition(data_date='${hiveconf:DATA_DATE}')
	 select 
		    id    
            ,`type`			
            ,olea_id 
			,fund_package_id 
            ,export_status                   
            ,package_status                  
            ,asset_quantity                  
            ,currency                        
            ,from_unixtime(cast(actual_redemption_date/1000 as bigint),'yyyy-MM-dd') as actual_redemption_date   
		    ,from_unixtime(cast(investor_funding_date/1000 as bigint),'yyyy-MM-dd')  as investor_funding_date
            ,from_unixtime(cast(complete_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as complete_time 			
            ,payment_ref_no                  
            ,investor_id                     
            ,investor                        
            ,investor_account_id             
            ,investor_account_name           
            ,investor_account_no             
            ,olea_account_name               
            ,olea_account_no 
            ,return_amount			
            ,total_funding_amount    
            ,total_overdue_interest			
            ,investor_interest_amount        
            ,redemption_adjustment_amount    
            ,estimated_redemption_amount     
            ,actual_redemption_amount        
            ,redemption_operator_id          
            ,comments                        
            ,remark                          
            ,create_by                       
            ,update_by                       
            ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time                     
            ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
            ,data_source			
			,total_outstanding_amount
			,total_received_amount 
			,excess_funding_amount 
			,from_unixtime(cast(estimated_funding_date/1000 as bigint),'yyyy-MM-dd') as estimated_funding_date
	        ,total_actual_interest_adjustment
			,net_settle_fund_package_id
			,net_settlement_status     
			,total_net_settled_amount 
		    ,net_settlement_available_amount
		    ,total_origin_net_settled_amount
		    ,payment_instruction  --20230215			
	 from ods.ods_olea_cust_olea_redemption_package
 ;