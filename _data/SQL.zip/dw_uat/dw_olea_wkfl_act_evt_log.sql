--drop table if exists dw_uat.dw_olea_wkfl_act_evt_log;
create table if not exists dw_uat.dw_olea_wkfl_act_evt_log
(`LOG_NR_`                           string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`TASK_ID_`                          string               comment '                                                  '
,`TIME_STAMP_`                       timestamp            comment '                                                  '
,`USER_ID_`                          string               comment '                                                  '
,`DATA_`                             string               comment '                                                  '
,`LOCK_OWNER_`                       string               comment '                                                  '
,`LOCK_TIME_`                        timestamp            comment '                                                  '
,`IS_PROCESSED_`                     string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_evt_log partition(data_date='${hiveconf:DATA_DATE}')
select
`LOG_NR_`                          
,`TYPE_`                            
,`PROC_DEF_ID_`                     
,`PROC_INST_ID_`                    
,`EXECUTION_ID_`                    
,`TASK_ID_`                         
,nvl(from_unixtime(cast(`TIME_STAMP_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`TIME_STAMP_`) as TIME_STAMP_
,`USER_ID_`                         
,`DATA_`                            
,`LOCK_OWNER_`                      
,nvl(from_unixtime(cast(`LOCK_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`LOCK_TIME_`) as LOCK_TIME_
,`IS_PROCESSED_`                    

from ods.ods_olea_wkfl_act_evt_log;