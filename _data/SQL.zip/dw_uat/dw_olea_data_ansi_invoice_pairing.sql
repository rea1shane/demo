--alter table dw_uat.dw_olea_data_ansi_invoice_pairing    add columns(estimated_funding_date timestamp   comment'投资到期日');


--alter table dw_uat.dw_olea_data_ansi_invoice_pairing  add  columns (advanced_ratio  string  comment '' );

--drop table if exists dw_uat.dw_olea_data_ansi_invoice_pairing;
create table if not exists dw_uat.dw_olea_data_ansi_invoice_pairing
(`id`                                string               comment '                                                  '
,`invoice_no`                        string               comment '                                                  '
,`pricing_execution_id`              string               comment '                                                  '
,`paired`                            string               comment '                                                  '
,`prgms_selected`                    string               comment '                                                  '
,`no_of_qual_prgms`                  string               comment '                                                  '
,`pair_runtime`                      timestamp            comment '                                                  '
,`failure_reason`                    string               comment '                                                  '
,`investor_final_invoice_return`     string               comment '                                                  '
,`investor_return_rate`              string               comment '                                                  '
,`investor_yield`                    string               comment '                                                  '
,`freezed_amt`                       string               comment '                                                  '
,`net_financing_amount_supplier`     string               comment '                                                  '
,`estimate_tenor`                    string               comment '                                                  '
,`execution_id`                      string               comment '                                                  '
,`update_date`                       date                 comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
,`create_time`                       timestamp            comment '                                                  '
) comment ''
 partitioned by(data_date string)  
 stored as parquet
 ;
 
insert overwrite table  dw_uat.dw_olea_data_ansi_invoice_pairing partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`invoice_no`                       
,`pricing_execution_id`             
,`paired`                           
,`prgms_selected`                   
,`no_of_qual_prgms`                 
,nvl(from_unixtime(cast(`pair_runtime`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`pair_runtime`) as pair_runtime
,`failure_reason`                   
,`investor_final_invoice_return`    
,`investor_return_rate`             
,`investor_yield`                   
,`freezed_amt`                      
,`net_financing_amount_supplier`    
,`estimate_tenor`                   
,`execution_id`                     
,nvl(from_unixtime(cast(`update_date`/1000 as bigint),'yyyy-MM-dd'),`update_date`) as update_date
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,advanced_ratio
,from_unixtime(cast(estimated_funding_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as estimated_funding_date
,unfunded
,principal_amt    
,adv_ratio_changed
from ods.ods_olea_data_ansi_invoice_pairing;