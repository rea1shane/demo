--alter table dw_uat.dw_olea_data_ansi_invoice_pricing 		   add columns (inter_buyer_bank_fee 			 double  comment'inter_buyer_bank_fee');
--alter table dw_uat.dw_olea_data_ansi_invoice_pricing 		   add columns (final_nominal_rate 				 double  comment'final_nominal_rate');
--alter table dw_uat.dw_olea_data_ansi_invoice_pricing 		   add columns (processing_days    				 double  comment'processing_days');


--alter table dw_uat.dw_olea_data_ansi_invoice_pricing     add columns(estimated_funding_date timestamp   comment'投资到期日');


--drop table if exists dw_uat.dw_olea_data_ansi_invoice_pricing;
create table if not exists dw_uat.dw_olea_data_ansi_invoice_pricing
(`id`                                string               comment '                                                  '
,`invoice_no`                        string               comment '                                                  '
,`invoice_amount`                    string               comment '                                                  '
,`principal_amt`                     string               comment '                                                  '
,`model_type`                        string               comment '                                                  '
,`maturity_date`                     date                 comment '                                                  '
,`customer_rate`                     string               comment '                                                  '
,`financing_program_id`              string               comment '                                                  '
,`financing_program_type`            string               comment '                                                  '
,`bill_id`                           string               comment '                                                  '
,`buyer_id`                          string               comment '                                                  '
,`supplier_id`                       string               comment '                                                  '
,`system_time`                       timestamp            comment '                                                  '
,`supplier_discamt`                  string               comment '                                                  '
,`supplier_procfee`                  string               comment '                                                  '
,`net_financing_amount_supplier`     string               comment '                                                  '
,`thirdparty_procfee`                string               comment '                                                  '
,`olea_platfee`                      string               comment '                                                  '
,`olea_investor_charge`              string               comment '                                                  '
,`investor_final_invoice_return`     string               comment '                                                  '
,`investor_ann_final`                string               comment '                                                  '
,`investor_ann_final_yield`          string               comment '                                                  '
,`net_financing_amount_investor`     string               comment '                                                  '
,`olea_infonex_platfee`              string               comment '                                                  '
,`olea_llsi_svcfee`                  string               comment '                                                  '
,`olea_supplier_disbursefee`         string               comment '                                                  '
,`esco_annfee_per_inv`               string               comment '                                                  '
,`rpa_fee`                           string               comment '                                                  '
,`estimated_tenor`                   string               comment '                                                  '
,`tag`                               string               comment '                                                  '
,`execution_id`                      string               comment '                                                  '
,`update_date`                       date                 comment '                                                  '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
,`advanced_ratio`                    double               comment''
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_data_ansi_invoice_pricing partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`invoice_no`                       
,`invoice_amount`                   
,`principal_amt`                    
,`model_type`                       
,nvl(from_unixtime(cast(`maturity_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`maturity_date`) as maturity_date
,`customer_rate`                    
,`financing_program_id`             
,`financing_program_type`           
,`bill_id`                          
,`buyer_id`                         
,`supplier_id`                      
,nvl(from_unixtime(cast(`system_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`system_time`) as system_time
,`supplier_discamt`                 
,`supplier_procfee`                 
,`net_financing_amount_supplier`    
,`thirdparty_procfee`               
,`olea_platfee`                     
,`olea_investor_charge`             
,`investor_final_invoice_return`    
,`investor_ann_final`               
,`investor_ann_final_yield`         
,`net_financing_amount_investor`    
,`olea_infonex_platfee`             
,`olea_llsi_svcfee`                 
,`olea_supplier_disbursefee`        
,`esco_annfee_per_inv`              
,`rpa_fee`                          
,`estimated_tenor`                  
,`tag`                              
,`execution_id`                     
,nvl(from_unixtime(cast(`update_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_date`) as update_date
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`advanced_ratio`
,from_unixtime(cast(estimated_funding_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as estimated_funding_date
,inter_buyer_bank_fee 
,final_nominal_rate 	
,processing_days    	
,interpolated_rate
,margin           
,olea_margin      
,curve            
,currency_code    
,adv_ratio_changed
,fund_cost_rate
,top_up_amount              
,rate_type                  
from ods.ods_olea_data_ansi_invoice_pricing;