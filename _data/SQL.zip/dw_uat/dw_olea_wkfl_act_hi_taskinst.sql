--drop table if exists dw_uat.dw_olea_wkfl_act_hi_taskinst;
create table if not exists dw_uat.dw_olea_wkfl_act_hi_taskinst
(`ID_`                               string               comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`TASK_DEF_KEY_`                     string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`PARENT_TASK_ID_`                   string               comment '                                                  '
,`DESCRIPTION_`                      string               comment '                                                  '
,`OWNER_`                            string               comment '                                                  '
,`ASSIGNEE_`                         string               comment '                                                  '
,`START_TIME_`                       timestamp            comment '                                                  '
,`CLAIM_TIME_`                       timestamp            comment '                                                  '
,`END_TIME_`                         timestamp            comment '                                                  '
,`DURATION_`                         string               comment '                                                  '
,`DELETE_REASON_`                    string               comment '                                                  '
,`PRIORITY_`                         string               comment '                                                  '
,`DUE_DATE_`                         timestamp            comment '                                                  '
,`FORM_KEY_`                         string               comment '                                                  '
,`CATEGORY_`                         string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_hi_taskinst partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`PROC_DEF_ID_`                     
,`TASK_DEF_KEY_`                    
,`PROC_INST_ID_`                    
,`EXECUTION_ID_`                    
,`NAME_`                            
,`PARENT_TASK_ID_`                  
,`DESCRIPTION_`                     
,`OWNER_`                           
,`ASSIGNEE_`                        
,nvl(from_unixtime(cast(`START_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`START_TIME_`) as START_TIME_
,nvl(from_unixtime(cast(`CLAIM_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`CLAIM_TIME_`) as CLAIM_TIME_
,nvl(from_unixtime(cast(`END_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`END_TIME_`) as END_TIME_
,`DURATION_`                        
,`DELETE_REASON_`                   
,`PRIORITY_`                        
,nvl(from_unixtime(cast(`DUE_DATE_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`DUE_DATE_`) as DUE_DATE_
,`FORM_KEY_`                        
,`CATEGORY_`                        
,`TENANT_ID_`                       

from ods.ods_olea_wkfl_act_hi_taskinst;