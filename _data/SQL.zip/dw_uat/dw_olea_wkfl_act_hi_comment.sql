--drop table if exists dw_uat.dw_olea_wkfl_act_hi_comment;
create table if not exists dw_uat.dw_olea_wkfl_act_hi_comment
(`ID_`                               string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  '
,`TIME_`                             timestamp            comment '                                                  '
,`USER_ID_`                          string               comment '                                                  '
,`TASK_ID_`                          string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`ACTION_`                           string               comment '                                                  '
,`MESSAGE_`                          string               comment '                                                  '
,`FULL_MSG_`                         string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_hi_comment partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`TYPE_`                            
,nvl(from_unixtime(cast(`TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`TIME_`) as TIME_
,`USER_ID_`                         
,`TASK_ID_`                         
,`PROC_INST_ID_`                    
,`ACTION_`                          
,`MESSAGE_`                         
,`FULL_MSG_`                        

from ods.ods_olea_wkfl_act_hi_comment;