--drop table if exists dw_uat.dw_olea_cust_olea_account_operation_record;
create table if not exists dw_uat.dw_olea_cust_olea_account_operation_record
(`id`                                string               comment '         '
,`bank_account_id`                   string               comment 'bank account id'
,`app_no`                            string               comment 'Application process number'
,`amount`                            string               comment 'Operating amount'
,`currency`                          string               comment 'currency'
,`type`                              string               comment 'operation type '
,`description`                       string               comment 'description'
,`create_by`                         string               comment 'creator id'
,`create_time`                       timestamp            comment ''
,`update_by`                         string               comment 'updater id'
,`update_time`                       timestamp            comment ''
) comment 'Amount Operation Record Form'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_account_operation_record partition(data_date='${hiveconf:DATA_DATE}')
select
		`id`                               
		,`bank_account_id`                  
		,`app_no`                           
		,`amount`                           
		,`currency`                         
		,`type`                             
		,`description`                      
		,`create_by`                        
		,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
		,`update_by`                        
		,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
from ods.ods_olea_cust_olea_account_operation_record;