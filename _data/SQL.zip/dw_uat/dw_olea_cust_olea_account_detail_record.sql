--alter table dw_uat.dw_olea_cust_olea_account_detail_record change  internal_transfer_status  attr1 string comment '';

--alter table dw_uat.dw_olea_cust_olea_account_detail_record add columns (internal_transfer_status  string comment '内部转账状态字段');
--alter table dw_uat.dw_olea_cust_olea_account_detail_record add columns (disbursement_combine_type string comment'disbursement阶段资产的打包类型');
--alter table dw_uat.dw_olea_cust_olea_account_detail_record add columns (busi_key string comment'会计推送的标识');


--drop table if exists dw_uat.dw_olea_cust_olea_account_detail_record;
create table if not exists dw_uat.dw_olea_cust_olea_account_detail_record
(`id`                                string               comment '  '
,`account_id`                        string               comment 'Accounting push record id '
,`seq_no`                            string               comment 'push sequence number'                                              
,`invoice_id`                        string               comment 'invoice id'
,`invoice_no`                        string               comment 'invoice no'
,`tran_id`                           string               comment 'Corresponding transaction id'                                         
,`tran_type`                         string               comment 'Transaction Type  '
,`trading_date`                      date                 comment 'Transaction date  '
,`status`                            string               comment 'status '
,`field_json`                        string               comment 'Final push field json                                        '
,`error_msg`                         string               comment 'error message                                              '
,`supplier_id`                       string               comment 'supplier id                                             '
,`supplier_name`                     string               comment 'supplier name                                             '
,`buyer_id`                          string               comment 'buyer id                                              '
,`buyer_name`                        string               comment 'buyer name                                              '
,`investor_id`                       string               comment 'investor id                                             '
,`investor_name`                     string               comment 'investor name                                             '
,`create_by`                         string               comment 'creator id                                             '
,`update_by`                         string               comment 'modifier id                                             '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment 'Accounting Push Detailed Record Form'
partitioned by(data_date string)  
stored as parquet
;


insert overwrite table  dw_uat.dw_olea_cust_olea_account_detail_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`account_id`                       
,`seq_no`                           
,`invoice_id`                       
,`invoice_no`                       
,`tran_id`                          
,`tran_type`                        
,nvl(from_unixtime(cast(`trading_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`trading_date`) as trading_date
,`status`                           
,`field_json`                       
,`error_msg`                        
,`supplier_id`                      
,`supplier_name`                    
,`buyer_id`                         
,`buyer_name`                       
,`investor_id`                      
,`investor_name`                    
,`create_by`                        
,`update_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,null as attr1 --业务库废弃该字段（202204）
,disbursement_combine_type
,busi_key
,account_product_name
,account_product_id
,step_name	
,step_id	
from ods.ods_olea_cust_olea_account_detail_record;