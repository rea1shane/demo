create table if not exists dw_uat.dw_olea_cust_olea_rating_config
( 
  id			   string     comment'主键ID'
  ,parent_id	   string     comment'父类ID'
  ,code			   string     comment'编码'
  ,name 		   string     comment'显示名称'
  ,create_by 	   string     comment'创建人'
  ,create_time 	   timestamp  comment'创建时间'
  ,update_by 	   string     comment'修改人'
  ,update_time 	   timestamp  comment'修改时间'
 )
 COMMENT'信用评级配置表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_rating_config partition(data_date='${hiveconf:DATA_DATE}')
select 
  id			
  ,parent_id	
  ,code			
  ,name 		
  ,create_by 	
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
  ,update_by 	
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 	
from ods.ods_olea_cust_olea_rating_config a 
;
