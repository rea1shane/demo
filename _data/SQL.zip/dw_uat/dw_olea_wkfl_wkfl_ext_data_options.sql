--drop table if exists dw_uat.dw_olea_wkfl_wkfl_ext_data_options;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_ext_data_options
(`id`                                string               comment '                                                  '
,`app_type`                          string               comment '流程类型                                              '
,`options1`                          string               comment '                                                  '
,`options2`                          string               comment '                                                  '
,`options3`                          string               comment '                                                  '
,`options4`                          string               comment '                                                  '
,`options5`                          string               comment '                                                  '
,`options6`                          string               comment '                                                  '
,`options7`                          string               comment '                                                  '
,`options8`                          string               comment '                                                  '
,`options9`                          string               comment '                                                  '
,`options10`                         string               comment '                                                  '
,`options11`                         string               comment '                                                  '
,`options12`                         string               comment '                                                  '
,`options13`                         string               comment '                                                  '
,`options14`                         string               comment '                                                  '
,`options15`                         string               comment '                                                  '
,`options16`                         string               comment '                                                  '
,`options17`                         string               comment '                                                  '
,`options18`                         string               comment '                                                  '
,`options19`                         string               comment '                                                  '
,`options20`                         string               comment '                                                  '
,`options21`                         string               comment '                                                  '
,`options22`                         string               comment '                                                  '
,`options23`                         string               comment '                                                  '
,`options24`                         string               comment '                                                  '
,`options25`                         string               comment '                                                  '
,`options26`                         string               comment '                                                  '
,`options27`                         string               comment '                                                  '
,`options28`                         string               comment '                                                  '
,`options29`                         string               comment '                                                  '
,`options30`                         string               comment '                                                  '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_user`                       string               comment '创建人名称                                             '
,`create_by`                         string               comment '创建人id                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_user`                       string               comment '修改人名称                                             '
,`update_by`                         string               comment '修改人id                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_ext_data_options partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`app_type`                         
,`options1`                         
,`options2`                         
,`options3`                         
,`options4`                         
,`options5`                         
,`options6`                         
,`options7`                         
,`options8`                         
,`options9`                         
,`options10`                        
,`options11`                        
,`options12`                        
,`options13`                        
,`options14`                        
,`options15`                        
,`options16`                        
,`options17`                        
,`options18`                        
,`options19`                        
,`options20`                        
,`options21`                        
,`options22`                        
,`options23`                        
,`options24`                        
,`options25`                        
,`options26`                        
,`options27`                        
,`options28`                        
,`options29`                        
,`options30`                        
,`enable`                           
,`remark`                           
,`create_user`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_user`                      
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_wkfl_wkfl_ext_data_options;