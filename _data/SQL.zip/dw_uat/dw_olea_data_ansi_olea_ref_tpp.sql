--alter table dw_uat.dw_olea_data_ansi_olea_ref_tpp  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_tpp  change   create_time   create_time timestamp      comment'' ;

create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_tpp
(
 id				 string  comment'id'
,tpp_code        string  comment'TPPCode'
,tpp_name        string  comment'TPPName'
,update_date     string  comment'update_date'
,create_time     string  comment'create_time'
,create_by       string  comment'create_by'
)partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_tpp partition(data_date='${hiveconf:DATA_DATE}')
select 
	id				
	,tpp_code    	 as  tpp_code    
	,tpp_name        as  tpp_name    
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date  
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time    
	,create_by			
 from ods.ods_olea_data_ansi_olea_ref_tpp
;