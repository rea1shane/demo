--drop table if exists dw_uat.dw_olea_cust_olea_company_record;
create table if not exists dw_uat.dw_olea_cust_olea_company_record
(`id`                                string               comment ' '
,`company_id`                        string               comment 'company id '
,`first_commit_flag`                 string               comment 'whether to file '
,`authorization_sign_flag`           string               comment 'authorization_sign_flag'
,`dd_state`                          string               comment 'Approval Status'
,`client_state`                      string               comment 'company status'
,`company_type`                      string               comment 'company type such as supplier buyer'
,`modify_portal`                     string               comment 'Currently modifiable ends, all, suppliers, inner pipe'
,`mail_sent_flag`                    string               comment 'wether the invitation code been sent '
,`submit_phase`                      string               comment 'supply submitted step '
,`create_by_name`                    string               comment 'creator name  '
,`update_by_name`                    string               comment 'updator name  '
,`sys_id`                            string               comment 'system user id '
,`create_type`                       string               comment 'Documentation method: internal/external'
,`app_no`                            string               comment 'process app Number '
,`company_name`                      string               comment 'company name'
,`country`                           string               comment 'country'
,`company_registration_document_type` string              comment 'company registration document type'
,`company_unique_code`               string               comment 'registration code'
,`third_party_code`                  string               comment '3rd party encoding, for assets etc.'
,`registration_doc_expiry_date`      date                 comment 'registration document expiry_date'
,`company_address`                   string               comment 'company address'
,`legal_person_name`                 string               comment 'legal person name'
,`industry`                          string               comment 'industry '
,`mobile_no`                         string               comment 'mobile NO.'
,`authorizer_name`                   string               comment 'Authorized person`s name '
,`authorizer_id_type`                string               comment 'Authorized person`s certificate type'
,`authorizer_id_no`                  string               comment 'ID number of authorized person'
,`authorizer_mobile_number`          string               comment 'Authorized person`s mobile phone number'
,`authorizer_email_address`          string               comment 'Authorizer`s email address '
,`authorizer_equals_legal`           string               comment 'Whether the authorized person is a legal person'
,`legal_representative_name`         string               comment 'Legal representative name '
,`legal_representative_id_type`      string               comment 'Type of legal representative certificate'
,`legal_representative_id_no`        string               comment 'Legal representative ID number'
,`legal_representative_mobile_number` string              comment 'Legal representative mobile phone number '
,`legal_representative_email_address` string              comment 'Legal representative email address'
,`create_time`                       timestamp            comment ' '
,`update_time`                       timestamp            comment ' '
) comment ''
 partitioned by(data_date string)  stored as parquet;
 
 
insert overwrite table  dw_uat.dw_olea_cust_olea_company_record partition(data_date='${hiveconf:DATA_DATE}')
select
		`id`                               
		,`company_id`                       
		,`first_commit_flag`                
		,`authorization_sign_flag`          
		,`dd_state`                         
		,`client_state`                     
		,`company_type`                     
		,`modify_portal`                    
		,`mail_sent_flag`                   
		,`submit_phase`                     
		,`create_by_name`                   
		,`update_by_name`                   
		,`sys_id`                           
		,`create_type`                      
		,`app_no`                           
		,`company_name`                     
		,`country`                          
		,`company_registration_document_type`
		,`company_unique_code`              
		,`third_party_code`                 
		,nvl(from_unixtime(cast(`registration_doc_expiry_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`registration_doc_expiry_date`) as registration_doc_expiry_date
		,`company_address`                  
		,`legal_person_name`                
		,`industry`                         
		,`mobile_no`                        
		,`authorizer_name`                  
		,`authorizer_id_type`               
		,`authorizer_id_no`                 
		,`authorizer_mobile_number`         
		,`authorizer_email_address`         
		,`authorizer_equals_legal`          
		,`legal_representative_name`        
		,`legal_representative_id_type`     
		,`legal_representative_id_no`       
		,`legal_representative_mobile_number`
		,`legal_representative_email_address`
		,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
		,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
 from ods.ods_olea_cust_olea_company_record;