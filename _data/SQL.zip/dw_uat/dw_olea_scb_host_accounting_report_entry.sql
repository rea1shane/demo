--drop table if exists dw_uat.dw_olea_scb_host_accounting_report_entry;
create table if not exists dw_uat.dw_olea_scb_host_accounting_report_entry
(`id`                                string               comment '                                                  '
,`file_id`                           string               comment 'host_file主键id                                     '
,`report_id`                         string               comment '取值：Rpt-Id 关联olea_host_report.report_id            '
,`entry_ref`                         string               comment '取值：Ntry-NtryRef                                   '
,`txdtls_tx_id`                      string               comment '取值：Ntry-NtryDtls-TxDtls-Refs-TxId                 '
,`cdt_dbt_ind`                       string               comment '取值：Ntry-CdtDbtInd                                 '
,`amt`                               string               comment '取值：Ntry-Amt                                       '
,`ccy`                               string               comment '取值：Ntry-Amt.Ccy                                   '
,`dt_time`                           timestamp            comment '取值：Ntry-BookgDt-DtTm                              '
,`src_ccy`                           string               comment '取值：Ntry-NtryDtls-TxDtls-AmtDtls-InstdAmt-CcyXchg-S'
,`trgt_ccy`                          string               comment '取值：Ntry-NtryDtls-TxDtls-AmtDtls-InstdAmt-CcyXchg-T'
,`xchg_rate`                         string               comment '取值：Ntry-NtryDtls-TxDtls-AmtDtls-InstdAmt-CcyXchg-X'
,`dbtr_name`                         string               comment '取值：Ntry-NtryDtls-TxDtls-RltdPties-Dbtr-Nm         '
,`dbtr_id`                           string               comment '取值：Ntry-NtryDtls-TxDtls-RltdPties-DbtrAcct-Id-Othr'
,`cdtr_name`                         string               comment '取值：Ntry-NtryDtls-TxDtls-RltdPties-Cdtr-Nm         '
,`cdtr_id`                           string               comment '取值：Ntry-NtryDtls-TxDtls-RltdPties-CdtrAcct-Id-Othr'
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_scb_host_accounting_report_entry partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`file_id`                          
,`report_id`                        
,`entry_ref`                        
,`txdtls_tx_id`                     
,`cdt_dbt_ind`                      
,`amt`                              
,`ccy`                              
,nvl(from_unixtime(cast(`dt_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`dt_time`) as dt_time
,`src_ccy`                          
,`trgt_ccy`                         
,`xchg_rate`                        
,`dbtr_name`                        
,`dbtr_id`                          
,`cdtr_name`                        
,`cdtr_id`                          
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_scb_host_accounting_report_entry;