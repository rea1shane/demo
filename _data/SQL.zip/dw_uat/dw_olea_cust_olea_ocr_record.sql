--drop table if exists dw_uat.dw_olea_cust_olea_ocr_record;
create table if not exists dw_uat.dw_olea_cust_olea_ocr_record
(`id`                                string               comment '                                                  '
,`seq_no`                            string               comment '流水号                                               '
,`financing_ref_no`                  string               comment '融资编号                                              '
,`file_type`                         string               comment '文件类型                                              '
,`file_no`                           string               comment '文件编号                                              '
,`file_path`                         string               comment '文件路径                                              '
,`file_external_key`                 string               comment '文件唯一标识                                            '
,`status`                            string               comment '状态                                                '
,`ocr_time`                          timestamp            comment 'ocr识别响应时间                                         '
,`result_json`                       string               comment 'ocr返回报文                                           '
,`field_json`                        string               comment 'ocr返回识别字段json                                     '
,`error_msg`                         string               comment '报错信息                                              '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_by`                         string               comment '                                                  '
,`create_time`                       timestamp            comment '                                                  '
,`update_by`                         string               comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment 'ocr识别记录表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_ocr_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`seq_no`                           
,`financing_ref_no`                 
,`file_type`                        
,`file_no`                          
,`file_path`                        
,`file_external_key`                
,`status`                           
,nvl(from_unixtime(cast(`ocr_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`ocr_time`) as ocr_time
,`result_json`                      
,`field_json`                       
,`error_msg`                        
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_ocr_record;