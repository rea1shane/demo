CREATE TABLE if not exists dw_uat.dw_olea_cust_olea_financing_program_nominal_rate 
(
   financing_program_id  int        COMMENT '融资项目ID'
  ,buyer_entity 		 string 	COMMENT 'Buyer Entity'
  ,goods_description 	 string 	COMMENT 'Goods Description'
  ,cost_to_distribution  int    	COMMENT 'Cost to Distribution'
  ,nominal_rate 		 double     COMMENT '手动输入的名义利率值'
  ,nominal_rate_type 	 string     COMMENT '名义利率类型：Fixed、Floating'
  ,risk_free_rate_option string     COMMENT '最低风险利率选项：TermsSofa'
  ,create_by 			 int  	    COMMENT '创建人userId'
  ,create_by_name 		 string     COMMENT '创建人'
  ,create_time 			 timestamp  COMMENT '创建时间'
  ,update_by 			 int  		COMMENT '更新人userId'
  ,update_by_name 		 string  	COMMENT '更新人'
  ,update_time 			 timestamp  COMMENT '最后更新时间'
)COMMENT '融资项目 Nominal Rate'
partitioned by (data_date date)
stored as parquet
;
insert overwrite table dw_uat.dw_olea_cust_olea_financing_program_nominal_rate partition(data_date='${hiveconf:DATA_DATE}')
select 
      financing_program_id  
     ,buyer_entity 		 
     ,goods_description 	 
     ,cost_to_distribution  
     ,nominal_rate 		 
     ,nominal_rate_type 	 
     ,risk_free_rate_option 
     ,create_by 			 
     ,create_by_name 		 
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 			 
     ,update_by 			 
     ,update_by_name 		 
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time
 from ods.ods_olea_cust_olea_financing_program_nominal_rate 
; 