create external table if not exists dw_uat.dw_olea_cust_olea_financing_supplier_upload_record
 (
	`id` 				             bigint  COMMENT 'primary key'
	,`package_id`            string  COMMENT ''
	,`project_code`          string  COMMENT ''
	,`olea_id` 			         string  COMMENT 'oleaId'
	,`invoice_no` 		       string  COMMENT ''
	,`currency` 			       string  COMMENT ''
	,`financing_program_id` bigint  COMMENT ''
	,`supplier_id` 				  bigint   COMMENT ''
	,`buyer_id` 					  bigint   COMMENT ''
	,`file_name` 				   string   COMMENT ''
	,`file_path` 					 string   COMMENT 'aws file path'
	,`type` 							 string   COMMENT 'Funded/Unfunded'
	,`content`						string 		COMMENT ''
	,`remark` 						string  COMMENT ''
	,`create_by` 					bigint  COMMENT ''
	,`create_by_name` 		string  COMMENT ''
	,`create_time` 				timestamp  COMMENT ''
	,`update_by` 					bigint     COMMENT ''
	,`update_by_name` 		string     COMMENT ''
	,`update_time` 				timestamp  COMMENT ''
)
partitioned by (data_date string)
stored as parquet
;
insert overwrite table dw_uat.dw_olea_cust_olea_financing_supplier_upload_record  partition(data_date='${hiveconf:DATA_DATE}')
select 
	`id` 				           
	,`package_id`          
	,`project_code`        
	,`olea_id` 			       
	,`invoice_no` 		     
	,`currency` 			     
	,`financing_program_id`
	,`supplier_id` 				 
	,`buyer_id` 					 
	,`file_name` 				   
	,`file_path` 					 
	,`type` 							 
	,`content`						 
	,`remark` 						 
	,`create_by` 					 
	,`create_by_name` 		 
	,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as `create_time` 				 
	,`update_by` 					 
	,`update_by_name` 		 
	,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as `update_time` 				 
from ods.ods_olea_cust_olea_financing_supplier_upload_record
;