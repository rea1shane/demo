create table if not exists dw_uat.dw_olea_cust_olea_financing_program_adjusted_rate
( 	
     id					   		    string         comment '唯一主键，自增雪花id'   
	,financing_program_id 			string	       comment '融资项目ID'
	,nominal_rate 					double   	   comment '名义利率 for front Nominal Rate'
	,manual_input_adjusted_rate 	double   	   comment '手动输入的名义利率值'
	,nominal_rate_type				string   	   comment '名义利率类型：Fixed、Floating'
	,risk_free_rate_option 			string   	   comment '最低风险利率选项：TermsSofa'
	,period_days 					string   	   comment '期限'
	,period_type 					string   	   comment '期限类型'
	,period_direction 				string   	   comment '期限生效类型'
	,date_to_count_period_from 	    string   	   comment '统计期限开始日期'
	,create_by                      string         comment '创建人id'
    ,create_by_name                 string         comment '创建人名称'
    ,create_time                    timestamp 	   comment '创建时间'
    ,update_by                      string         comment '修改人id'
    ,update_by_name                 string         comment '修改人名称'
    ,update_time                    timestamp 	   comment '修改时间'

)
comment '融资项目调整利率'
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_program_adjusted_rate  partition(data_date='${hiveconf:DATA_DATE}')
select 
	  id					 
	 ,financing_program_id 		
	 ,nominal_rate 					 
	 ,manual_input_adjusted_rate 	 
	 ,nominal_rate_type				 
	 ,risk_free_rate_option 			 
	 ,period_days 					 
	 ,period_type 					 
	 ,period_direction 				 
	 ,date_to_count_period_from 		 
	 ,create_by                          
     ,create_by_name                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                        
     ,update_by                          
     ,update_by_name                     
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time
     ,goods_description
     ,olea_share 
     ,investor_share 
  from ods.ods_olea_cust_olea_financing_program_adjusted_rate
;


