--alter table dw_uat.dw_olea_cust_olea_financing   add columns (floating_overdue_rate    double  comment'浮动逾期利率');

--alter table dw_uat.dw_olea_cust_olea_financing change estimated_maturity_date_lasted extended_maturity_date date comment '最新的融资到期日（原始记录）/上一次展期完成后的发票到期日（展期纪录）';
--alter table dw_uat.dw_olea_cust_olea_financing 		    add columns(nominal_rate      double comment'名义利率');
--alter table dw_uat.dw_olea_cust_olea_financing 		    add columns(advance_ratio     double comment'融资比例');
--alter table dw_uat.dw_olea_cust_olea_financing 		    add columns(extension_interest  double comment'展期利息');
--alter table dw_uat.dw_olea_cust_olea_financing add columns(extension_id  					string comment'融资冗余最新展期记录ID'); 
--alter table dw_uat.dw_olea_cust_olea_financing add columns(estimated_maturity_date_lasted  date comment'融资冗余最新展期到期日');
--alter table dw_uat.dw_olea_cust_olea_financing add columns(status_update_time  string comment'status_update_time')

create table if not exists dw_uat.dw_olea_cust_olea_financing
( 
       id                              string comment ''
      ,app_no                          string comment ''
      ,olea_id                         string comment ''
      ,data_source                     string comment ''
	  ,model_type                      string comment ''
      ,data_type                       string comment ''
      ,financing_ref_no                string comment ''
      ,financing_type                  string comment ''
      ,currency                        string comment ''
      ,requested_amount                string comment ''
      ,financed_amount                 string comment ''
      ,financing_amount                string comment ''
	  ,principal_amount                string comment ''
      ,discount_amount                 string comment ''
	  ,invoice_amount                  string comment ''
      ,discount_rate                   string comment ''
      ,disbursement_amount             string comment ''
      ,gtn_seller_fees                 string comment ''
      ,financing_date                  string comment ''
      ,check_by                        string comment ''
      ,funding_date                    string comment ''
      ,discount_days                   string comment ''
      ,maturity_date                   string comment ''
      ,exfactory_date                  string comment ''
      ,request_status                  string comment ''
      ,payment_terms                   string comment ''
      ,payment_terms_start_date        string comment ''
      ,payment_term_days               string comment ''
	  ,repayment_status                string comment ''
      ,request_date                    string comment ''
      ,estimated_financing_date        string comment ''
      ,estimated_interest              string comment ''
      ,investor_program_id             string comment ''
      ,financing_program_id            string comment ''
      ,distribution_id                 string comment ''
      ,asset_default_status            string comment ''
      ,repurchase_price                string comment ''
      ,tpp_status                      string comment ''
      ,`comment`                       string comment ''
      ,financing_pair_status           string comment ''
      ,attachment_upload_status        string comment ''
      ,asset_status                    string comment ''
      ,holiday_days                    string comment ''
      ,remark                          string comment ''
      ,create_by                       string comment ''
      ,create_by_name                  string comment ''
      ,create_time                     string comment ''
      ,update_by                       string comment ''
      ,update_by_name                  string comment ''
      ,update_time                     string comment ''
 )partitioned by (data_date string)                   
stored as parquet;


--alter table dw_uat.dw_olea_cust_olea_financing  change   financing_date   financing_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   funding_date   funding_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   maturity_date   maturity_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   exfactory_date   exfactory_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   payment_terms_start_date   payment_terms_start_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   request_date   request_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   estimated_financing_date   estimated_financing_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   status_update_time   status_update_time  timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_financing  change   update_time   update_time  timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_cust_olea_financing partition(data_date='${hiveconf:DATA_DATE}')
select 
       id                           
      ,app_no                       
      ,olea_id                      
      ,data_source  
      ,model_type	  
      ,null as attr1                    
      ,financing_ref_no             
      ,financing_type               
      ,currency                     
      ,requested_amount             
      ,financed_amount              
      ,financing_amount  
      ,principal_amount	  
      ,discount_amount 
      ,invoice_amount	  
      ,discount_rate                
      ,disbursement_amount          
      ,gtn_seller_fees              
      ,from_unixtime(cast(financing_date/1000 as bigint),'yyyy-MM-dd')  as financing_date               
      ,check_by                     
      ,from_unixtime(cast(funding_date/1000 as bigint),'yyyy-MM-dd')    as funding_date                 
      ,discount_days                
      ,from_unixtime(cast(maturity_date/1000 as bigint),'yyyy-MM-dd')   as maturity_date                
      ,from_unixtime(cast(exfactory_date/1000 as bigint),'yyyy-MM-dd')  as exfactory_date               
      ,request_status               
      ,payment_terms                
      ,from_unixtime(cast(payment_terms_start_date/1000 as bigint),'yyyy-MM-dd')   as payment_terms_start_date
      ,payment_term_days 
      ,repayment_status	  	  
      ,from_unixtime(cast(request_date/1000 as bigint),'yyyy-MM-dd') as request_date                 
      ,from_unixtime(cast(estimated_financing_date/1000 as bigint),'yyyy-MM-dd')   as estimated_financing_date     
      ,estimated_interest           
      ,investor_program_id          
      ,financing_program_id         
      ,distribution_id  
	  ,asset_default_status   
	  ,repurchase_price       
	  ,tpp_status             
	  ,`comment`              
      ,financing_pair_status        
      ,attachment_upload_status
      ,asset_status		  
	  ,holiday_days    	  
      ,remark                       
      ,create_by                    
      ,create_by_name               
      ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                  
      ,update_by                    
      ,update_by_name               
      ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time  
	  ,from_unixtime(cast(status_update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as status_update_time
	  ,extension_id  					
	  ,from_unixtime(cast(extended_maturity_date/1000 as bigint),'yyyy-MM-dd') as extended_maturity_date	
      ,nominal_rate     
      ,advance_ratio    
      ,extension_interest
	  ,floating_overdue_rate	
      ,grace_period      
	  ,from_unixtime(cast(invoice_issue_date/1000 as bigint),'yyyy-MM-dd') as invoice_issue_date
	  ,funding_amount
	  ,project_code
	  ,source 		
	  ,from_unixtime(cast(receive_date/1000 as bigint),'yyyy-MM-dd') as receive_date
	  ,qp_nos			
	  ,qp_count			
	  ,qp_status		
	  ,from_unixtime(cast(qp_expire_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as qp_expire_time	
	  ,outstanding_amount
	  ,unfunded_flag
	  ,unfunded_show_flag
	  ,cooling_period_rate
from ods.ods_olea_cust_olea_financing a 
;
