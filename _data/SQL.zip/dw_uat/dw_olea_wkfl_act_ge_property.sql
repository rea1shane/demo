--drop table if exists dw_uat.dw_olea_wkfl_act_ge_property;
create table if not exists dw_uat.dw_olea_wkfl_act_ge_property
(`NAME_`                             string               comment '                                                  '
,`VALUE_`                            string               comment '                                                  '
,`REV_`                              string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_ge_property partition(data_date='${hiveconf:DATA_DATE}')
select
`NAME_`                            
,`VALUE_`                           
,`REV_`                             

from ods.ods_olea_wkfl_act_ge_property;