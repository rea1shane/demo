create table if not exists dw_uat.dw_olea_cust_olea_autocheck_trade_validation
( 
   id				  				string	   comment 'primary key id'
  ,financing_ref_no   string	   comment 'financing asset NO.'
  ,app_no			  			string	   comment 'process application number'
  ,field			 				string	   comment 'check columns such as `port_of_loading_for_sea、carrier_name_for_land` and as so on'
  ,check_value		  	string	   comment 'check value'
  ,auto_result		  	string	   comment 'auto check result'
  ,auto_check_date    timestamp	 comment 'auto check date'
  ,case_system_id	  	string	 	 comment 'When the type belongs to screening, the verification uses the refinitiv interface, which is charged by caseId, so it is stored to prevent repeated charges'
  ,create_by		  		string	 	 comment 'creator id'
  ,create_time   	 	  timestamp	 comment 'create time'
  ,update_by		  		string	   comment 'updator id'
  ,update_time        timestamp  comment 'update time'
 )
 COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_autocheck_trade_validation partition(data_date='${hiveconf:DATA_DATE}')
select 
   id				
  ,financing_ref_no 
  ,app_no			
  ,field			 
  ,check_value			
  ,auto_result			
  ,from_unixtime(cast(auto_check_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as auto_check_date  	
  ,case_system_id		
  ,create_by			
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time   		
  ,update_by			
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time      	
from ods.ods_olea_cust_olea_autocheck_trade_validation a 
;
















































































