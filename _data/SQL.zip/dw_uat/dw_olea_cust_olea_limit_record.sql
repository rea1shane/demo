create table if not exists dw_uat.dw_olea_cust_olea_limit_record
(  
   id                     string	   comment'唯一主键'
  ,limit_management_id    string	   comment'关联olea_limit_management表id,link to olea_limit_management.id'
  ,currency               string	   comment'币种 for currency'
  ,amount                 double	   comment'金额 amount'
  ,record_type            string	   comment'记录类型 fund refund record type'
  ,financing_id           string	   comment'资产id link to olea_financing.id'
  ,investor_program_no    string	   comment'投资项目编号(系统自动生成)'
  ,financing_program_id   string	   comment'融资项目id link to olea_financing_program.id'
  ,investor_olea_id       string	   comment'investor id'
  ,supplier_olea_id       string	   comment'supplier id'
  ,buyer_olea_id          string	   comment'buyer id'
  ,create_by              string       comment'创建人id, create id'
  ,create_by_name         string       comment'创建人名称, create name'
  ,create_time            timestamp    comment'创建时间 , create time'
  ,update_by              string       comment'更新人id, update id'
  ,update_by_name         string       comment'最后更新人名称, update name'
  ,update_time            timestamp    comment'更新时间, update time'
 )
 COMMENT'风险管理修改历史记录表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_limit_record partition(data_date='${hiveconf:DATA_DATE}')
select 
   id
  ,limit_management_id
  ,currency
  ,amount
  ,record_type
  ,financing_id
  ,program_no
  ,financing_program_id
  ,investor_olea_id
  ,supplier_olea_id
  ,buyer_olea_id
  ,create_by 	 			
  ,create_by_name 			
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
  ,update_by 
  ,update_by_name	  
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
from ods.ods_olea_cust_olea_limit_record a 
;




























































































