create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_anchor_industry
(
 id						  string  comment  'id'
,anchor_industry_id       string  comment  'AnchorIndustryID'
,anchor_industry_desc     string  comment  'AnchorIndustryDesc'
,update_date              string  comment  'update_date'
,create_time              string  comment  'create_time'
,create_by                string  comment  'create_by'
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_data_ansi_olea_ref_anchor_industry  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_anchor_industry  change   create_time   create_time timestamp      comment'' ;

insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_anchor_industry partition(data_date='${hiveconf:DATA_DATE}')
select 
	id						
	,anchor_industry_id      	  as  anchorindustryid      
	,anchor_industry_desc         as  anchorindustrydesc    
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date 
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time	
	,create_by			
 from ods.ods_olea_data_ansi_olea_ref_anchor_industry
;