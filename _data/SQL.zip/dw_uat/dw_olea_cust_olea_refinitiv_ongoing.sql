create table if not exists dw_uat.dw_olea_cust_olea_refinitiv_ongoing
( 
   id                 string
  ,respond    		  string
  ,result             string
  ,create_date        date
 )
 COMMENT'autocheck 每天refinitiv响应的ongoing变化数据'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_refinitiv_ongoing partition(data_date='${hiveconf:DATA_DATE}')
select 
     id
    ,respond 
    ,result  
    ,from_unixtime(cast(create_date/1000 as bigint),'yyyy-MM-dd')    as create_date
from ods.ods_olea_cust_olea_refinitiv_ongoing a 
;































