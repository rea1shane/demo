create table if not exists dw_uat.dw_olea_sso_center_sso_user_authenticator
( 
  id                string        comment'id'
  ,sso_user_id      string        comment'用户id:sso_user.sso_id'
  ,secret           string        comment'身份认证器密码'
  ,enable           string        comment'是否启用'
  ,create_time      timestamp     comment'创建时间'
  ,update_time      timestamp     comment'修改时间'
 )
 COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_sso_center_sso_user_authenticator partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id           
	 ,sso_user_id 
	 ,secret      
	 ,enable      
	 ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 	
from ods.ods_olea_sso_center_sso_user_authenticator a 
;