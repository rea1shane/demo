create table if not exists dw_uat.dw_olea_cust_olea_ultimate
( 
	 id                          string  comment ''
	,company_id                  string  comment 'company id'
	,entity_id                   string  comment 'autocheck_entity.id'
	,app_no                      string  comment 'application No.'
	,first_name                  string  comment 'first name'
	,last_name                   string  comment 'last name'
	,gender                      string  comment 'gender'
	,date_of_birth               string  comment 'date of birth'
	,nationality                 string  comment 'nationality'
	,country_of_residency        string  comment 'country of residency'
	,city_of_residency           string  comment 'city of residency'
	,street_of_residency         string  comment '居住地街道'
	,country_of_birth            string  comment 'country of birth'
	,city_of_birth               string  comment 'city of birth'
	,tax_idt_number              string  comment 'tax_identification_number'
	,country_of_tax              string  comment 'country_of_tax'
	,create_by                   string  comment 'id of the person who created'
	,create_time                 string  comment ''
	,update_by                   string  comment 'id of the person who updated'
	,update_time                 string  comment ''
)partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_cust_olea_ultimate partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                      
     ,company_id              
     ,entity_id               
     ,app_no                  
     ,first_name              
     ,last_name               
     ,gender                  
     ,from_unixtime(cast(date_of_birth/1000 as bigint),'yyyy-MM-dd') as date_of_birth           
     ,nationality             
     ,country_of_residency    
     ,city_of_residency       
     ,street_of_residency     
     ,country_of_birth        
     ,city_of_birth           
     ,tax_idt_number          
     ,country_of_tax          
     ,create_by               
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time             
     ,update_by               
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time   
	   ,related_person_name
	   ,id_type
	   ,id_no
	   ,group_key
	   ,related_person_id
	   ,first_name_local
	   ,last_name_local
	   ,designation
	   ,shareholdings_percentage
	   ,email_address
	   ,mobile_prefix
	   ,mobile_number
  from ods.ods_olea_cust_olea_ultimate	 
  ;