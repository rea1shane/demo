create table if not exists dw_uat.dw_olea_cust_olea_program_limit
( 
  id					string      comment'唯一主键'
  ,app_no               string      comment'流程id'
  ,program_id           string      comment'ProgramId，关联投资人项目id'
  ,program_no	        string      comment'Program ID 投资项目编号'
  ,investor_id          string      comment'Investor Id，投资人id(关联olea_company表id)'
  ,parent_id            string      comment'Parent Id，父类Id' 
  ,`type`               string      comment'TYPE，BUYER/SUPPLIER，类型:买方偏好/供应商偏好'
  ,buyer_group          string      comment'Buyer Group，对应olea_company表BUYER的olea_id'
  ,supplier             string      comment'Supplier，对应olea_company表SUPPLIER的olea_id'
  ,create_by            string      comment'创建人userId'
  ,create_by_name       string      comment'创建人名称'
  ,create_time          timestamp   comment'创建时间'
  ,update_by            string      comment'更新人userId'
  ,update_by_name       string      comment'更新人名称'
  ,update_time          timestamp   comment'最后更新时间'
 )
 COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;


insert overwrite table dw_uat.dw_olea_cust_olea_program_limit partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id	
	 ,app_no
	 ,program_id     
	 ,program_no	  
	 ,investor_id    
	 ,parent_id      
	 ,`type`         
	 ,buyer_group    
	 ,supplier        
     ,create_by 	 			
     ,create_by_name 			
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
     ,update_by 
     ,update_by_name	  
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 	
from ods.ods_olea_cust_olea_program_limit a 
;