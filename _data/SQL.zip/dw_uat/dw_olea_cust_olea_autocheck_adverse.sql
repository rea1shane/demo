create table if not exists dw_uat.dw_olea_cust_olea_autocheck_adverse
(
   id                     string       comment 'olea_autocheck_column_record.id'
  ,record_id              string       comment ''
  ,report                 string       comment 'report content'
  ,type                   string       comment 'check type'
  ,remark                 string       comment 'remark connent'
  ,create_time            string       comment 'create time'
  ,create_by              string       comment 'creator id'
  ,update_time            string       comment ''
  ,update_by              string       comment 'updater id'
 )partitioned by (data_date string)
stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_autocheck_adverse partition(data_date='${hiveconf:DATA_DATE}')
  select 
         id              
        ,record_id       
        ,report          
        ,type            
        ,remark          
        ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time           
        ,create_by       
        ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time           
        ,update_by   
		    ,app_no
   from ods.ods_olea_cust_olea_autocheck_adverse	
   -- where update_time is not null
 ;
--alter table dw_uat.dw_olea_cust_olea_autocheck_adverse add columns (app_no string comment 'app no');
--alter table dw_uat.dw_olea_cust_olea_autocheck_adverse change  create_time create_time timestamp comment 'create time';
--alter table dw_uat.dw_olea_cust_olea_autocheck_adverse change  update_time update_time timestamp comment 'update  time';