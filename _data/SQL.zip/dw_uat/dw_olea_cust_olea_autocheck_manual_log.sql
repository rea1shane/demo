create table if not exists dw_uat.dw_olea_cust_olea_autocheck_manual_log
( 
   id       			      string		comment 'primary key id'
  ,check_record_id      string		comment 'check record id'
  ,log_type             string		comment 'log type'
  ,before_info          string		comment 'Data json format before update'
  ,after_info       	  string		comment 'Data json format after update'
  ,create_by       		  string		comment 'creator id'
  ,create_by_name       string		comment 'creator name'
  ,create_time       	  timestamp	comment 'create time'
  ,update_by       	 	  string		comment 'updator id'
  ,update_by_name       string		comment	'updator name'
  ,update_time			    timestamp comment 'update time'
 )
 COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_autocheck_manual_log partition(data_date='${hiveconf:DATA_DATE}')
select 
     id
    ,check_record_id
    ,log_type
    ,before_info
    ,after_info
    ,create_by
    ,create_by_name  
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time  
    ,update_by  
    ,update_by_name  
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
from ods.ods_olea_cust_olea_autocheck_manual_log a 
;
















































