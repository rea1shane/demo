--drop table dw_uat.dw_olea_cust_olea_h2h_file;
CREATE TABLE if not exists dw_uat.dw_olea_cust_olea_h2h_file
(
  id 						string 			
 ,package_id 				string 	   COMMENT 'refund、disbursement、funding 包id'
 ,origin_file_name 			string     COMMENT '原始文件名称'
 ,participant_id			string     comment '收款方'
 ,busi_key 					string     COMMENT '影像件 业务主键'
 ,ack1 						string     COMMENT '默认N,当接收到对应文件改为Y'
 ,ack2 						string     COMMENT '默认N,当接收到对应文件改为Y'
 ,ack3 						string     COMMENT '默认N,当接收到对应文件改为Y'
 ,rej1 						string     COMMENT '默认N,当接收到对应文件改为Y'
 ,rej2 						string     COMMENT '默认N,当接收到对应文件改为Y'
 ,rej3 						string     COMMENT '默认N,当接收到对应文件改为Y' 
 ,`enable` 					string     COMMENT '默认N,当接收到对应文件改为Y'
 ,remark    				string 	   COMMENT '备注'
 ,create_by 				string 	   COMMENT '创建人id'
 ,update_by 				string 	   COMMENT '更新人id'
 ,create_by_name 			string 	   COMMENT '创建人名称'
 ,update_by_name 			string 	   COMMENT '最后更新人名称'
 ,create_time 				timestamp 		
 ,update_time 				timestamp 		
) COMMENT 'h2h文件状态表'
partitioned by (data_date string)
stored as parquet;
;

insert overwrite table dw_uat.dw_olea_cust_olea_h2h_file partition(data_date='${hiveconf:DATA_DATE}')
select      
      id 					
     ,package_id 			
     ,origin_file_name
	 ,participant_id	 
     ,busi_key 				
     ,ack1 					
     ,ack2 					           
     ,ack3 					
     ,rej1 					
     ,rej2 					
     ,rej3 					
     ,`enable` 				
     ,remark    			
     ,create_by 			
     ,update_by 			
     ,create_by_name 		
     ,update_by_name 					
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time                         
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
     ,transmit_status
	 ,file_status    
  from ods.ods_olea_cust_olea_h2h_file
  ;