--drop table if exists dw_uat.dw_olea_wkfl_act_id_group;
create table if not exists dw_uat.dw_olea_wkfl_act_id_group
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_id_group partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`NAME_`                            
,`TYPE_`                            

from ods.ods_olea_wkfl_act_id_group;