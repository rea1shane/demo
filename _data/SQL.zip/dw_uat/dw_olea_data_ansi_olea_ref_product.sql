--alter table dw_uat.dw_olea_data_ansi_olea_ref_product  add  columns (product_code  	  string  comment '' );
--alter table dw_uat.dw_olea_data_ansi_olea_ref_product  add  columns (product_name  	  string  comment '' );
--alter table dw_uat.dw_olea_data_ansi_olea_ref_product  add  columns (product_grouping  string  comment '' );
--alter table dw_uat.dw_olea_data_ansi_olea_ref_product  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_product  change   create_time   create_time  timestamp comment'' ;


--drop table if exists dw_uat.dw_olea_data_ansi_olea_ref_product;
create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_product
(
id					 string 	comment 'id'
,productcode         string 	comment 'productcode'
,productname         string 	comment 'productname'
,productgrouping     string 	comment 'productgrouping'
,update_date         string 	comment 'update_date'
,create_by           string 	comment 'create_by'
,create_time         string     comment 'create_time'
)partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_product partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id				
	,product_code    	 as  productcode    
	,product_name        as  productname    
	,product_grouping    as  productgrouping
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date     
	,create_by		
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time
	,product_code  	
	,product_name  	
	,product_grouping	
 from ods.ods_olea_data_ansi_olea_ref_product
;