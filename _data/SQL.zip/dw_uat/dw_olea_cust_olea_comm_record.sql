--drop table if exists dw_uat.dw_olea_cust_olea_comm_record;
create table if not exists dw_uat.dw_olea_cust_olea_comm_record
(`id`                                string               comment '                                                  '
,`comm_valid`                        string               comment 'valid / invalid                                   '
,`company_id`                        string               comment 'supplierId / investorId link to olea_company.id   '
,`reference_no`                      string               comment 'Reference No.                                     '
,`date_and_Time`                     timestamp            comment 'Date and Time                                     '
,`initiator`                         string               comment 'Initiator                                         '
,`comm_method`                       string               comment 'Communication Method                              '
,`subject`                           string               comment 'Subject                                           '
,`further_action_completion`         string               comment 'Further Action Completion                         '
,`client_participant`                string               comment 'Client Participant                                '
,`keynote`                           string               comment 'Keynote                                           '
,`further_actions`                   string               comment 'Further Actions                                   '
,`create_by`                         string               comment '创建人id                                             '
,`update_by`                         string               comment '更新人id                                             '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment 'Communication Record'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_comm_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`comm_valid`                       
,`company_id`                       
,`reference_no`                     
,nvl(from_unixtime(cast(`date_and_Time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`date_and_Time`) as date_and_Time
,`initiator`                        
,`comm_method`                      
,`subject`                          
,`further_action_completion`        
,`client_participant`               
,`keynote`                          
,`further_actions`                  
,`create_by`                        
,`update_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_comm_record;