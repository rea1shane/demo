-- auto-generated definition
create table if not exists dw_uat.dw_olea_cust_olea_limit_shared_group
(
    id                   int        comment 'id',
    limit_management_id  bigint     comment '关联olea_limit_management表id,link to olea_limit_management.id',
    currency            string      comment '币种 for currency, 与关联的limit_management的currency一致',
    group_name          string      comment '群组名称',
    create_olea_id      string      comment '创建者oleaId, group的第一创建公司(哪个公司发起的群组)',
    group_type          string      comment '群组类型,预留字段',
    group_status        string      comment '群组状态',
    remark              string      comment '备注,预留字段',
    create_by           string      comment '创建人',
    create_time         timestamp   comment '创建时间',
    update_by           bigint      comment '更新人',
    update_time         timestamp   comment '更新时间'
)
partitioned by (data_date string)                   
stored as parquet
;
insert overwrite table dw_uat.dw_olea_cust_olea_limit_shared_group partition(data_date='${hiveconf:DATA_DATE}')
select 
     id                
    ,limit_management_id 
    ,currency            
    ,group_name          
    ,create_olea_id      
    ,group_type          
    ,group_status        
    ,remark              
    ,create_by           
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time         
    ,update_by           
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time         
 from ods.ods_olea_cust_olea_limit_shared_group
 ;
   