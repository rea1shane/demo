create table if not exists dw_uat.dw_olea_cust_olea_third_platform_partner
( 	
     id					   string           comment '唯一主键，自增雪花id'   
    ,platform_id           string           comment '平台id（olea_third_platform.id）'
	,partner_name          string           comment '配对数值（一般为公司名）'
	,fee_type              string           comment '费用类型ByBps Percentage Share'
	,fee_selection_value   string           comment '费用选项值Invoice Amount、Principal Amount'
	,fee_input_value       int              comment '费用输入数值'
	,create_by             string           comment '创建人id'
    ,create_by_name        string           comment '创建人名称'
    ,create_time           timestamp 		comment '创建时间'
    ,update_by             string           comment '修改人id'
    ,update_by_name        string           comment '修改人名称'
    ,update_time           timestamp 		comment '修改时间'

)
comment '第三方平台配对信息表'
partitioned by (data_date string)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_third_platform_partner  partition(data_date='${hiveconf:DATA_DATE}')
select 
	  id					 
     ,platform_id         
	 ,partner_name        
	 ,fee_type            
	 ,fee_selection_value 
	 ,fee_input_value     
     ,create_by                          
     ,create_by_name                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                        
     ,update_by                          
     ,update_by_name                     
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time   
  from ods.ods_olea_cust_olea_third_platform_partner
;










