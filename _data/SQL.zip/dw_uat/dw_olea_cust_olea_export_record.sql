create table if not exists dw_uat.dw_olea_cust_olea_export_record
(id                                string               comment 'primary key id'
,`type`                            string               comment 'export type : fund/paid/refund'
,package_id                        string               comment 'The exported transaction asset package id'
,`file_name`                       string               comment 'export file name'
,create_by                         string               comment 'creator id '
,create_time                       timestamp            comment 'create time '
,update_by                         string               comment 'updator id'
,update_time                       timestamp            comment 'update time'
) comment 'host to host export record table'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_export_record partition(data_date='${hiveconf:DATA_DATE}')
select
id                          
,`type`                        
,package_id                
,'' as file_no
,create_by                    
,nvl(from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),create_time) as create_time
,update_by            
,nvl(from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),update_time) as update_time
,`file_name`
from ods.ods_olea_cust_olea_export_record
;
