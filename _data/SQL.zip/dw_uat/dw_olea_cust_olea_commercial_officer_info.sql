-- company中co用户信息数据表                                                                                           
CREATE table if not exists  dw_uat.dw_olea_cust_olea_commercial_officer_info
 (                                                                  
  id			           bigint      COMMENT 'primary key id',                                               
  olea_id            string      COMMENT 'olea Id',                                      
  user_name          string      COMMENT 'user name',                                                         
  phone	             string      COMMENT 'phone number',                                                         
  email		           string      COMMENT 'email address',                                                            
  country_code			 string      COMMENT 'country code',                                                         
  remark						 string      COMMENT 'remark',                                                                   
  enable						 string      COMMENT 'yes or no',                                            
  create_by				   bigint 	   COMMENT 'creator id',                                                     
  create_by_name		 string 		 COMMENT 'creator name',                                                          
  create_time			   timestamp 	 COMMENT 'create time',                                             
  update_by				   bigint			 COMMENT 'updator id',                                                     
  update_by_name	   string			 COMMENT 'updator name',                                                          
  update_time				 timestamp   COMMENT 'update time'                                                    
) COMMENT 'commercial officer user information form' 
 partitioned by(data_date string)  stored as parquet;    
 
 
 
 insert overwrite table  dw_uat.dw_olea_cust_olea_commercial_officer_info partition(data_date='${hiveconf:DATA_DATE}')
 
 select 
       id			          
       ,olea_id          
       ,user_name        
       ,phone	          
       ,email		        
       ,country_code		  
       ,remark					  
       ,enable					  
       ,create_by				
       ,create_by_name	  
       ,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time			
       ,update_by				
       ,update_by_name	  
       ,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
    from ods.ods_olea_cust_olea_commercial_officer_info a 
    ;