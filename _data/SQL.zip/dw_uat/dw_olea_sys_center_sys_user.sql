create table if not exists dw_uat.dw_olea_sys_center_sys_user
(
  id	        string   comment 'id'
 ,org_id        string   comment '机构id'
 ,org_code      string   comment '机构编码'
 ,user_name 	string   comment '用户名'
 ,name 			string   comment '姓名'
 ,password 		string   comment '密码'
 ,old_password  string   comment '旧系统密码'
 ,mobile 		string   comment '手机号'
 ,phone 		string   comment '手机号,同微信'
 ,email 		string   comment '邮箱'
 ,department    string   comment '部门'
 ,remark 		string   comment '备注'
 ,user_status 	string   comment '用户状态'
 ,create_by 	string   comment '创建人id'
 ,create_time 	string   comment '创建时间'
 ,update_by 	string   comment '更新人id'
 ,update_time 	string   comment '更新时间'
 ,cas_version 	string   comment '版本号'
)partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_sys_center_sys_user partition(data_date='${hiveconf:DATA_DATE}')
select 
      id	      
	 ,org_id      
	 ,org_code    
     ,user_name 	
     ,name 			
     ,password 		
     ,old_password
     ,mobile 		
     ,phone 		
     ,email 		
     ,department  
     ,remark 		
     ,user_status 
     ,create_by 	
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time      
     ,update_by 	
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
     ,cas_version  
 from ods.ods_olea_sys_center_sys_user
 ;
