create table if not exists dw_uat.dw_olea_cust_olea_autocheck_column_record_audit
(
 id                         string comment 'primary key'   
,company_id                 string comment 'company id'
,app_no                     string comment 'process application id'
,field                      string comment 'check columns such as company_name,company_address company_id'
,`type`                     string comment 'check type eg `docment,inentity,screening`'
,display                    string comment 'the content displayed on the page'
,auto_result                string comment 'auto check result'
,manual_result              string comment 'manual check result'
,updator                    string comment 'updator id'
,`comment`                  string comment 'check comment'
,check_date                 string comment 'check date'
,case_system_id             string comment 'When the type belongs to screening, the verification uses the refinitiv interface, deduction, which is charged by caseId, so it is stored to prevent repeated charges'
,reference_id               string comment 'After the refinitiv screeningRequest interface selects the desired object, it records its referenceId. According to the interface description, this id is a required field of refinitiv'
,none_of_above              string comment 'When the type is screening, in the original logic, when refinitiv does not select the desired object, it will click noneOfBelow. This field is used for this, but it should be replaced by referenceId now'
,entity_type                string comment 'Enumeration value ORGANISATION, INDIVIDUAL. Refenitiv interface requests need to differentiate this. So this field only appears when the type is screening.'
,ubo_type                   string comment 'When the field type belongs to ubo data, this field is used to distinguish whether it is input or supplemented by the post-process FRONT (from the front-end input) CHEKK (from the chekk interface)'
,ubo_id                     string comment 'ubo_id'
,order_num                  string comment ''
,ongoing_data_active        string comment 'Failure type Currently ongoing and audit are two workflows. When ongoing is initiated, the data needs to be copied to the new process, so the original process data must be invalidated. This field is only used for ongoing'
,remark                     string comment 'remark'
,create_by                  string comment 'creator id'
,create_time                string comment 'create time'
,update_by                  string comment 'updator id'
,update_time                string comment 'update time'
)partitioned by (data_date string)
stored as parquet; 
                                          
                                           
                                       
insert overwrite table dw_uat.dw_olea_cust_olea_autocheck_column_record_audit partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                        
     ,company_id                
     ,app_no                    
     ,field                     
     ,`type`                    
     ,display                   
     ,auto_result               
     ,manual_result             
     ,updator                   
     ,`comment`                 
     ,from_unixtime(cast(check_date/1000 as bigint),'yyyy-MM-dd')  as check_date                
     ,case_system_id            
     ,reference_id              
     ,none_of_above             
     ,entity_type               
     ,ubo_type                  
     ,ubo_id                    
     ,order_num                 
     ,ongoing_data_active       
     ,remark                    
     ,create_by                 
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time               
     ,update_by                 
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time  
     ,person_audit_id	 
  from ods.ods_olea_cust_olea_autocheck_column_record_audit
  ;
