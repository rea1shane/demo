--alter table dw_uat.dw_olea_pub_pub_dynamics_receipt	  		  add columns (account_trad_type 				string  comment'账户交易类型');


--drop table if exists dw_uat.dw_olea_pub_pub_dynamics_receipt;
create table if not exists dw_uat.dw_olea_pub_pub_dynamics_receipt
(`id`                                string               comment '                                                  '
,`journal_id`                        string               comment '文件ID                                              '
,`process_steps_id`                  string               comment '流程步骤Id                                            '
,`currency_code`                     string               comment '币种code                                            '
,`event`                             string               comment '描述                                                '
,`amount`                            string               comment '金额                                                '
,`posting_date`                      date                 comment '投寄日期                                              '
,`invoice_no`                        string               comment '发票号                                               '
,`debit_account`                     string               comment '借记卡账户名                                            '
,`credit_account`                    string               comment '信用卡账户名                                            '
,`account_no`                        string               comment '账户卡号                                              '
,`cost_centre`                       string               comment '成本中心                                              '
,`third_party_provider`              string               comment '第三方提供商                                            '
,`product`                           string               comment '账户卡号                                              '
,`investor`                          string               comment '投资人名称                                             '
,`buyer`                             string               comment '买方名称                                              '
,`supplier`                          string               comment '供应商名称                                             '
,`investment_id`                     string               comment '投资ID                                              '
,`project_id`                        string               comment '项目ID                                              '
,`sychronized_status`                string               comment '同步状态:success,failure                              '
,`sychronized_type`                  string               comment '同步类型：PaymentReceipt、CashReceipt                   '
,`error_msg`                         string               comment '同步到dynamics错误信息                                   '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
,`send_email_flag`                   string               comment 'dynamic365邮件发送状态，SENT/UNSENT                      '
,`push_type`                         string               comment 'dynamic365推送方式：AUTOMATIC/MANUAL                   '
) comment 'dynamics 收据信息同步表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_pub_dynamics_receipt partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`journal_id`                       
,`process_steps_id`                 
,`currency_code`                    
,`event`                            
,`amount`                           
,nvl(from_unixtime(cast(`posting_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`posting_date`) as posting_date
,`invoice_no`                       
,`debit_account`                    
,`credit_account`                   
,`account_no`                       
,`cost_centre`                      
,`third_party_provider`             
,`product`                          
,`investor`                         
,`buyer`                            
,`supplier`                         
,`investment_id`                    
,`project_id`                       
,`sychronized_status`               
,`sychronized_type`                 
,`error_msg`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`send_email_flag`                  
,`push_type`                        
,account_trad_type
from ods.ods_olea_pub_pub_dynamics_receipt;