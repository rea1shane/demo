--drop table if exists dw_uat.dw_olea_pub_olea_bank_info;
create table if not exists dw_uat.dw_olea_pub_olea_bank_info
(`id`                                string               comment '                                                  '
,`bank_name`                         string               comment '银行名称                                              '
,`branch_name`                       string               comment '支行名称                                              '
,`swiftcode`                         string               comment '                                                  '
,`connection`                        string               comment '                                                  '
,`country`                           string               comment '国家                                                '
,`city`                              string               comment '城市                                                '
,`address`                           string               comment '地址                                                '
,`postcode`                          string               comment '                                                  '
,`money_transfer`                    string               comment '                                                  '
,`receive_money`                     string               comment '                                                  '
,`bank_url`                          string               comment '                                                  '
,`country_code`                      string               comment '国家编码                                              '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_by`                         string               comment '                                                  '
,`create_time`                       timestamp            comment '                                                  '
,`update_by`                         string               comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment '银行信息表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_olea_bank_info partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`bank_name`                        
,`branch_name`                      
,`swiftcode`                        
,`connection`                       
,`country`                          
,`city`                             
,`address`                          
,`postcode`                         
,`money_transfer`                   
,`receive_money`                    
,`bank_url`                         
,`country_code`                     
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_pub_olea_bank_info;