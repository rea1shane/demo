create table if not exists dw_uat.dw_olea_cust_olea_limit_update_history
( 
   id                     string       comment'primary key id'
  ,limit_management_id    string       comment'link to olea_limit_management.id'
  ,currency               string       comment'currency'
  ,old_limit_amount       double       comment'The previous limit'
  ,new_limit_amount       double       comment'current limit amout'
  ,internal_comments      string       comment'for internal comments'
  ,documents_key          string       comment'Limit adjustment opinion attachment file key'
  ,create_by              string       comment'creator id'
  ,create_by_name         string       comment'creator name'
  ,create_time            timestamp    comment'create time'
  ,update_by              string       comment'updator id'
  ,update_by_name         string       comment'updator name'
  ,update_time            timestamp    comment'update time'
 )
 COMMENT'Risk Management Modification History Table'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_limit_update_history partition(data_date='${hiveconf:DATA_DATE}')
select 
   id
  ,limit_management_id
  ,currency
  ,old_limit_amount
  ,new_limit_amount
  ,internal_comments
  ,documents_key
  ,create_by 	 			
  ,create_by_name 			
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
  ,update_by 
  ,update_by_name	  
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
  ,shared_group_limit_id_all_json
	,shared_group_limit_id_add_json
	,shared_group_limit_id_del_json
	,old_shared_group_limit_id_all_json
	,type
	,old_status
	,new_status
	,reason
	,issue_status
from ods.ods_olea_cust_olea_limit_update_history a 
;





































































