--drop table if exists dw_uat.dw_olea_cust_olea_agreement;
create table if not exists dw_uat.dw_olea_cust_olea_agreement
(`id`                                string               comment '                                                  '
,`company_id`                        string               comment 'company ID                                            '
,`file_id`                           string               comment 'archive attachment id    '
,`program_id`                        string               comment 'programid  '
,`contract_id`                       string               comment 'Contract NO.  '
,`name`                              string               comment 'Contract name '
,`agreement_in_use`                  string               comment 'agreement in use '
,`executed_on`                       date                 comment 'executedOn   '
,`first_submit`                      string               comment ' Is or is`t the first submission  '
,`linked_template_no`                string               comment 'Associated template number' 
,`linked_template_name`              string               comment 'Associated template name'
,`status`                            string               comment 'Contract status  '
,`agreement_temp_type`               string               comment 'Contract template typer   '
,`agreement_type`                    string               comment 'Contract type   '
,`upload_time`                       timestamp            comment 'upload time   '
,`audit_time`                        timestamp            comment 'audit time   '
,`create_time`                       timestamp            comment 'creator time   '
,`create_by`                         string               comment 'creator id    '
,`update_time`                       timestamp            comment 'update time '
,`update_by`                         string               comment 'updater id  '
) comment 'Investor Contract Information Form'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_agreement partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`company_id`                       
,`file_id`                          
,`program_id`                       
,`contract_id`                      
,`name`                             
,`agreement_in_use`                 
,nvl(from_unixtime(cast(`executed_on`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`executed_on`) as executed_on
,`first_submit`                     
,`linked_template_no`               
,`linked_template_name`             
,`status`                           
,`agreement_temp_type`              
,`agreement_type`                   
,nvl(from_unixtime(cast(`upload_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`upload_time`) as upload_time
,nvl(from_unixtime(cast(`audit_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`audit_time`) as audit_time
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        

from ods.ods_olea_cust_olea_agreement;