--drop table if exists dw_uat.dw_olea_workorder_work_order_info;
create table if not exists dw_uat.dw_olea_workorder_work_order_info
(`id`                                string               comment '                                                  '
,`order_number`                      string               comment '工单编号                                              '
,`order_type`                        string               comment '工单类型：New Enquiry-询问、Suggestion-建议、Others-其他       '
,`order_title`                       string               comment '工单标题                                              '
,`order_state`                       string               comment '工单状态：1-重新打回处理、2-受理中、3-已解决、4-已关闭、5-尚未受理            '
,`first_solve_time`                  timestamp            comment '首次响应时间                                            '
,`last_solve_time`                   timestamp            comment '最后回复时间                                            '
,`priority`                          string               comment '优先级：1-高、2-中、3-低                                   '
,`close_order_time`                  timestamp            comment '关单时间                                              '
,`time_reply`                        string               comment '回复所需时间                                            '
,`time_close`                        string               comment '关闭所需时间                                            '
,`first_name`                        string               comment 'first客户姓名                                         '
,`last_name`                         string               comment 'last客户名称                                          '
,`client_contact_info`               string               comment '客户联系方式(手机号)                                       '
,`client_contact_mail`               string               comment '客户联系邮箱                                            '
,`company_client_name`               string               comment '企业客户名称                                            '
,`company_client_id`                 string               comment '企业olea-id 唯一标识                                    '
,`handler_name`                      string               comment '处理人员名称                                            '
,`handler_id`                        string               comment '处理人员ID                                            '
,`handler_contact_info`              string               comment '处理人员联系方式                                          '
,`handler_mail`                      string               comment '处理人员邮件                                            '
,`order_evaluate`                    string               comment '工单评价                                              '
,`order_evaluate_opinion`            string               comment '工单评价意见                                            '
,`auto_off_state`                    string               comment '自动关闭标识：auto-系统自动关闭、manual-人工关闭                    '
,`order_repulse_state`               string               comment '工单打回标识：Y-重新打回                                     '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '更新时间                                              '
,`platform_name`                     string               comment '平台名称                                              '
,`urge_state`                        string               comment '是否已经发送一封催办邮件：1-否、2-是                              '
,`client_type`                       string               comment '客户类型：a corporate-企业、an investor-投资者               '
,`last_advisory_time`                timestamp            comment '客户最后咨询时间                                          '
) comment '工单信息表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_workorder_work_order_info partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`order_number`                     
,`order_type`                       
,`order_title`                      
,`order_state`                      
,nvl(from_unixtime(cast(`first_solve_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`first_solve_time`) as first_solve_time
,nvl(from_unixtime(cast(`last_solve_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`last_solve_time`) as last_solve_time
,`priority`                         
,nvl(from_unixtime(cast(`close_order_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`close_order_time`) as close_order_time
,`time_reply`                       
,`time_close`                       
,`first_name`                       
,`last_name`                        
,`client_contact_info`              
,`client_contact_mail`              
,`company_client_name`              
,`company_client_id`                
,`handler_name`                     
,`handler_id`                       
,`handler_contact_info`             
,`handler_mail`                     
,`order_evaluate`                   
,`order_evaluate_opinion`           
,`auto_off_state`                   
,`order_repulse_state`              
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`platform_name`                    
,`urge_state`                       
,`client_type`                      
,nvl(from_unixtime(cast(`last_advisory_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`last_advisory_time`) as last_advisory_time

from ods.ods_olea_workorder_work_order_info;