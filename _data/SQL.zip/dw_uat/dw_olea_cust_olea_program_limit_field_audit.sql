create table if not exists dw_uat.dw_olea_cust_olea_program_limit_field_audit
( 
  id                  string    comment '唯一主键，自增雪花id'
 ,program_limit_id    string    comment 'Program Limit Id，关联olea_program_limit表主键id'
 ,field               string    comment 'Field，动态扩展字段'
 ,field_desc          string    comment 'Field Desc，动态扩展字段说明'
 ,field_value         string    comment 'Field Value，动态扩展字段值'
 ,field_condition     string    comment 'Condition，条件：< <= = >= >'
 ,create_by           string    comment '创建人userId'
 ,create_by_name      string    comment '创建人名称'
 ,create_time         timestamp comment '创建时间'
 ,update_by           string    comment '更新人userId'
 ,update_by_name      string    comment '更新人名称'
 ,update_time         timestamp comment '最后更新时间'
)
COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;


insert overwrite table dw_uat.dw_olea_cust_olea_program_limit_field_audit partition(data_date='${hiveconf:DATA_DATE}')
select 
     id
    ,program_limit_id
    ,field
    ,field_desc
    ,field_value
    ,field_condition
    ,create_by 	 			
    ,create_by_name 			
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 	
    ,update_by 
    ,update_by_name	  
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 	
from ods.ods_olea_cust_olea_program_limit_field_audit
;


































