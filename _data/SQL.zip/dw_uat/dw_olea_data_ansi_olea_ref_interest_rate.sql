create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_interest_rate
( 
    id               string       comment 'RFR记录表'
   ,currency_code    string       comment '3 digit iso currency code'
   ,curve            string       comment 'Name of the interest rate curve'
   ,tenor            string       comment 'Tenor of the interest rate i.e., 1M'
   ,rate             double       comment 'Interest rate in decimal'
   ,day_counts       int          comment 'day_counts'
   ,fixing_date      date         comment 'fixing_date'
   ,update_date      timestamp    comment 'Update date of the data'
   ,data_date_rds    date         comment 'Date of the data content'
 )
 COMMENT'会计详情统计状态表'
partitioned by (data_date string)                   
stored as parquet
;


insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_interest_rate partition(data_date='${hiveconf:DATA_DATE}')
select 
	  id            
	 ,currency_code 
	 ,curve          
	 ,tenor         
	 ,rate         
     ,day_counts
     ,from_unixtime(cast(fixing_date/1000 as bigint),'yyyy-MM-dd')           as fixing_date	 
	 ,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_date   
	 ,from_unixtime(cast(data_date  /1000 as bigint),'yyyy-MM-dd')           as data_date_rds   	
from ods.ods_olea_data_ansi_olea_ref_interest_rate a 
;























