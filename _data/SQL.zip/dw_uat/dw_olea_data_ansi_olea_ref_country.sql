create table if not exists dw_uat.dw_olea_data_ansi_olea_ref_country
(
    id					      string  	comment	'id'
    ,country_code             string  	comment	'CountryCode'
    ,country_name             string  	comment	'CountryName'
    ,phone_country_code       string  	comment	'PhoneCountryCode'
    ,isoa2_code               string  	comment	'ISOA2Code'
    ,isoa3_code               string  	comment	'ISOA3Code'
    ,iso_numeric_code         string  	comment	'ISONumericCode'
    ,region                   string  	comment	'Region'
    ,sub_region               string    comment 'sub_region'
	,high_risk_jurisdiction  string     comment 'high_risk_jurisdiction'
    ,update_date             string  	comment	'update_date'
    ,create_by			     string  	comment	'create_by'
    ,create_time             string     comment 'create_time'
)partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_data_ansi_olea_ref_country partition(data_date='${hiveconf:DATA_DATE}')
select 
	id					
	,country_code         as countrycode      
	,country_name         as countryname      
	,phone_country_code   as phonecountrycode 
	,isoa2_code           as isoa2code
	,isoa3_code           as isoa3code
	,iso_numeric_code     as isonumericcode
	,region      
	,sub_region
	,high_risk_jurisdiction
	,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_date      
	,create_by
	,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time
    ,country_name_system	
 from ods.ods_olea_data_ansi_olea_ref_country
;

--alter table dw_uat.dw_olea_data_ansi_olea_ref_country  change   update_date   update_date  date      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_olea_ref_country  change   create_time   create_time timestamp      comment'' ;