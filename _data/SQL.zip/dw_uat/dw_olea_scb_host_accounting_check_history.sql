create table if not exists dw_uat.dw_olea_scb_host_accounting_check_history
(
 id						string	
,bank_account			string		
,subledger_amount		double	
,bank_statement_amount	double	
,`difference`			double	
,report_time			timestamp	
,aging					int		
,counterparty_name		string	
,counterparty_type		string	
,status					string		
,remark					string		
,opt_user_id			string	
,opt_user_name			string	
,solved_time			timestamp	
,create_time			timestamp	
,update_time			timestamp	
,last_difference		double	
,record_date			date		
,reconcile_amount		double	
,source_bank_account	string	
,source_name			string	
)partitioned by(data_date string)  
stored as parquet
;
 
insert overwrite table  dw_uat.dw_olea_scb_host_accounting_check_history partition(data_date='${hiveconf:DATA_DATE}')
select
 id						
,bank_account			
,subledger_amount		
,bank_statement_amount	
,`difference`			
,report_time			
,aging					
,counterparty_name		
,counterparty_type		
,status					
,remark					
,opt_user_id			
,opt_user_name			
,from_unixtime(cast(solved_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as solved_time			
,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time			
,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time			
,last_difference		
,from_unixtime(cast(record_date/1000 as bigint),'yyyy-MM-dd') as record_date			
,reconcile_amount		
,source_bank_account	
,source_name			
from ods.ods_olea_scb_host_accounting_check_history;