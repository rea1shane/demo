create table if not exists dw_uat.dw_olea_pub_olea_internal_bank_account
(              
id               string
,company_name    string 
,account_no      string                          
)
partitioned by(data_date string)  
stored as parquet
;


insert overwrite table  dw_uat.dw_olea_pub_olea_internal_bank_account partition(data_date='${hiveconf:DATA_DATE}')
select
id           
,company_name
,account_no  
from ods.ods_olea_pub_olea_internal_bank_account
;