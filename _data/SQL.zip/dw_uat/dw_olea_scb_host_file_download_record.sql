--drop table if exists dw_uat.dw_olea_scb_host_file_download_record;
create table if not exists dw_uat.dw_olea_scb_host_file_download_record
(`id`                                string               comment '                                                  '
,`host_file_id`                      string               comment 'host 文件id 关联 host_file.id                         '
,`file_key`                          string               comment '文件标识                                              '
,`file_name`                         string               comment '文件名                                               '
,`file_size`                         string               comment '文件大小                                              '
,`user_id`                           string               comment '用户id                                              '
,`user_name`                         string               comment '用户姓名                                              '
,`create_time`                       timestamp            comment '创建时间                                              '
) comment '文件下载记录'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_scb_host_file_download_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`host_file_id`                     
,`file_key`                         
,`file_name`                        
,`file_size`                        
,`user_id`                          
,`user_name`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time

from ods.ods_olea_scb_host_file_download_record;