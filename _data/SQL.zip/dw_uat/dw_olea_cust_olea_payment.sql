--alter table dw_uat.dw_olea_cust_olea_payment add columns(excess_return_package_id  string comment'excess_return_package_id')
--alter table dw_uat.dw_olea_cust_olea_payment  change   disbursement_date disbursement_date  				date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_payment  change   disbursement_time disbursement_time  				timestamp comment'' ;
--alter table dw_uat.dw_olea_cust_olea_payment  change   fund_date   		fund_date          				date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_payment  change   estimated_financing_date estimated_financing_date date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_payment  change   actual_financing_date    actual_financing_date    date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_payment  change   financing_maturity_date  financing_maturity_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_payment  change   invoice_maturity_date    invoice_maturity_date    date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_payment  change   create_time   create_time  					    timestamp  comment'' ;
--alter table dw_uat.dw_olea_cust_olea_payment  change   update_time   update_time  					    timestamp  comment'' ;


create table if not exists  dw_uat.dw_olea_cust_olea_payment
( 
     id                                 string      comment ''                                            --'投资人充值包id'               
    ,fund_package_id                    string      comment 'fund package ID'                             --'放款给供应商包id'
    ,paid_package_id                    string      comment 'paID package ID'                             --'投资人项目id'
    ,investor_program_id                string      comment 'investor program ID'                         --'融资项目id'
    ,financing_program_id               string      comment 'financing program ID'                        --'状态： fund/paid'
    ,status                             string      comment 'status :fund or paID'                        --'资产id'
	,fee_change_flag                    string      comment 'flag that show if fee has changed'           --''
    ,financing_id                       string      comment 'financing ID'                                --'投资人名称'
    ,investor                           string      comment 'investor'                                    --'买方'
    ,buyer                              string      comment 'buyer'                                       --'供应商/卖方 名称'
    ,supplier                           string      comment 'supplier'                                    --'项目名称'
    ,program_name                       string      comment 'program name'                                --'发票编号'
    ,invoice_no                         string      comment 'invoice No.'                                 --'融资金额'
    ,financing_amount                   string      comment 'financing amount'                            --'币种'
    ,currency                           string		comment 'currency'                                    --'融资本金'
    ,principal_amount                   string      comment 'principal amount'                            --'应放款金额'
    ,net_financing_amount               string      comment 'net financing amount'                        --'手续费'
    ,processing_fee                     string      comment 'processing fee'                              --'汇款费用类型'
    ,fees_type                          string		comment 'fees type'                                   --'调整金额'
    ,payment_adjust_amount              string      comment 'payment adjust amount'                       --'打款金额'
    ,net_paid_amount                    string      comment 'net paID amount'                             --'放款时间'
    ,disbursement_date                  string		comment 'disbursement date'                           --'充值金额'
	,disbursement_time                  string		comment 'disbursement time'                           --'充值金额'  
    ,funding_amount                     string      comment 'funding amount'                              --'充值时间'
    ,fund_date                          string		comment 'fund date'                                   --'名义利率'
    ,nominal_rate                       string      comment 'nominal rate'                                --'投资人利率'
    ,investor_interest_rate             string      comment 'investor interest rate'                      --'预计融资利息'
    ,estimated_interest                 string      comment 'estimated interest'                          --'实际融资利息'
    ,actual_interest                    string      comment 'actual interest'                             --'投资人利率金额'
    ,investor_interest_amount           string      comment 'investor interest amount'                    --'预计起息日'
    ,estimated_financing_date           string		comment 'estimated financing date'                    --'实际起息日'
    ,actual_financing_date              string		comment 'actual financing date'                       --'预计融资期限'
    ,estimated_tenor                    string		comment 'estimated tenor'                             --'实际融资期限'
    ,actual_tenor                       string		comment 'actual tenor'                                --'资产到期日'
    ,financing_maturity_date            string		comment 'financing maturity date'                     --'产品类型'
    ,product_type                       string		comment 'product type'                                --'融资利率'
	,model3_product_type                string      comment ''
    ,advance_ratio                      string      comment 'advance ratio'                               --'发票到期日'
    ,invoice_maturity_date              string      comment 'invoice maturity date'                       --'创建人id'
    ,create_by                          string      comment 'id of the person who created'                --'更新人id'
    ,update_by                          string      comment 'id of the person who updated'                --''
    ,create_time                        string      comment ''                                            --''
    ,update_time                        string      comment ''                                            --''
  )partitioned by (data_date string)
stored as parquet;

insert overwrite table dw_uat.dw_olea_cust_olea_payment partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                            
     ,fund_package_id               
     ,paid_package_id               
     ,investor_program_id           
     ,financing_program_id          
     ,status 
     ,fee_change_flag	 
     ,financing_id                  
     ,investor                      
     ,buyer                         
     ,supplier                      
     ,program_name                  
     ,invoice_no                    
     ,financing_amount              
     ,currency                      
     ,principal_amount              
     ,net_financing_amount          
     ,processing_fee                
     ,fees_type                     
     ,payment_adjust_amount         
     ,net_paid_amount               
     ,from_unixtime(cast(disbursement_date/1000 as bigint),'yyyy-MM-dd') 		  as disbursement_date 
     ,from_unixtime(cast(disbursement_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as disbursement_time	 
     ,funding_amount                
     ,from_unixtime(cast(fund_date/1000 as bigint),'yyyy-MM-dd') as fund_date                     
     ,nominal_rate                  
     ,investor_interest_rate        
     ,estimated_interest            
     ,actual_interest               
     ,investor_interest_amount      
     ,from_unixtime(cast(estimated_financing_date/1000 as bigint),'yyyy-MM-dd') as estimated_financing_date      
     ,from_unixtime(cast(actual_financing_date/1000 as bigint),'yyyy-MM-dd')    as actual_financing_date         
     ,estimated_tenor               
     ,actual_tenor                  
     ,from_unixtime(cast(financing_maturity_date/1000 as bigint),'yyyy-MM-dd') as financing_maturity_date       
     ,product_type  
     ,model3_product_type	 
     ,advance_ratio                 
     ,from_unixtime(cast(invoice_maturity_date/1000 as bigint),'yyyy-MM-dd') as invoice_maturity_date         
     ,create_by                     
     ,update_by                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time                    
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time    
	 ,excess_return_package_id
	 ,estimated_funding_amount
	 ,actual_received_amount  
	 ,shortage                
	 ,available_float         
	 ,investor_id             
	 ,supplier_id             
	 ,buyer_id                	 
	 ,process_fee_per_invoice
	 ,unfunded_package_id		
	 ,unfunded_processing_fee	
	 ,estimated_disbursed_amount
	 ,net_settled_amount
 from ods.ods_olea_cust_olea_payment
 ;
 
 
 
 