--drop table if exists dw_uat.dw_olea_pub_olea_country;
create table if not exists dw_uat.dw_olea_pub_olea_country
(`id`                                string               comment '高风险国家主键id                                         '
,`country_name`                      string               comment '国家名称(中文)                                          '
,`country_name_eng`                  string               comment '国家名称(英文)                                          '
,`country_code`                      string               comment '国家编码                                              '
,`type`                              string               comment '类型                                                '
,`phone_code`                        string               comment '手机区号                                              '
,`dbs_code`                          string               comment 'dbs country code                                  '
,`region`                            string               comment 'Region                                            '
,`sub_region`                        string               comment 'subRegion                                         '
,`high_risk_jurisdiction`            string               comment 'HighRiskJurisdiction                              '
,`create_time`                       timestamp            comment '创建时间                                              '
,`create_by`                         string               comment '创建人                                               '
) comment '国家或地区基表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_olea_country partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`country_name`                     
,`country_name_eng`                 
,`country_code`                     
,`type`                             
,`phone_code`                       
,`dbs_code`                         
,`region`                           
,`sub_region`                       
,`high_risk_jurisdiction`           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,regulated_market
,fatf
,elrj
from ods.ods_olea_pub_olea_country;