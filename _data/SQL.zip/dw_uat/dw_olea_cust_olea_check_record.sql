--drop table if exists dw_uat.dw_olea_cust_olea_check_record;
create table if not exists dw_uat.dw_olea_cust_olea_check_record
(`id`                                string               comment '    '
,`financing_ref_no`                  string               comment 'financing ref no '
,`check_no`                          string               comment 'check NO. '
,`check_field`                       string               comment 'check field name '
,`check_value`                       string               comment 'check value '
,`status`                            string               comment 'status'
,`auto_check_result`                 string               comment 'auto check result '
,`error_msg`                         string               comment 'error message  '
,`check_date`                        timestamp            comment 'check date '
,`manual_check_result`               string               comment 'manual check result'
,`manual_check_opinion`              string               comment 'manual check opinion'
,`enable`                            string               comment '   '
,`remark`                            string               comment '  '
,`create_by`                         string               comment '  '
,`create_time`                       timestamp            comment '  '
,`update_by`                         string               comment '  '
,`update_time`                       timestamp            comment '   '
) comment 'checklist table'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_check_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`financing_ref_no`                 
,`check_no`                         
,`check_field`                      
,`check_value`                      
,`status`                           
,`auto_check_result`                
,`error_msg`                        
,nvl(from_unixtime(cast(`check_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`check_date`) as check_date
,`manual_check_result`              
,`manual_check_opinion`             
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_cust_olea_check_record;