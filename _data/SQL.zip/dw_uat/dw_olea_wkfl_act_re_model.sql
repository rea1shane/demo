--drop table if exists dw_uat.dw_olea_wkfl_act_re_model;
create table if not exists dw_uat.dw_olea_wkfl_act_re_model
(`ID_`                               string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`KEY_`                              string               comment '                                                  '
,`CATEGORY_`                         string               comment '                                                  '
,`CREATE_TIME_`                      timestamp            comment '                                                  '
,`LAST_UPDATE_TIME_`                 timestamp            comment '                                                  '
,`VERSION_`                          string               comment '                                                  '
,`META_INFO_`                        string               comment '                                                  '
,`DEPLOYMENT_ID_`                    string               comment '                                                  '
,`EDITOR_SOURCE_VALUE_ID_`           string               comment '                                                  '
,`EDITOR_SOURCE_EXTRA_VALUE_ID_`     string               comment '                                                  '
,`TENANT_ID_`                        string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_re_model partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`REV_`                             
,`NAME_`                            
,`KEY_`                             
,`CATEGORY_`                        
,nvl(from_unixtime(cast(`CREATE_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`CREATE_TIME_`) as CREATE_TIME_
,nvl(from_unixtime(cast(`LAST_UPDATE_TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`LAST_UPDATE_TIME_`) as LAST_UPDATE_TIME_
,`VERSION_`                         
,`META_INFO_`                       
,`DEPLOYMENT_ID_`                   
,`EDITOR_SOURCE_VALUE_ID_`          
,`EDITOR_SOURCE_EXTRA_VALUE_ID_`    
,`TENANT_ID_`                       

from ods.ods_olea_wkfl_act_re_model;