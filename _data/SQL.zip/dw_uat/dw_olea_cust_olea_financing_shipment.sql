create table if not exists dw_uat.dw_olea_cust_olea_financing_shipment
( 
 id                               string      comment'发票表主键ID,自增雪花ID'
 ,data_source                     string      comment'数据来源'
 ,financing_invoice_id            string      comment'发票表ID'
 ,invoice_olea_id                 string      comment'发票表oleaId'
 ,invoice_no                      string      comment'发票编号'
 ,incoterms                       string      comment'国贸条规，Incoterms'
 ,delivery_mode                   string      comment'运输方式，Delivery Mode (Sea/Air/Land)' 
 ,shipment_document               string      comment'运输单号，BL/AWB/Receipt No.'
 ,shipment_date                   date        comment'运输日期，Shipment/AWB/Receipt Date'
 ,country_of_loading              string      comment'装箱地（国家），Port/Airport/Place of Loading (Country)' 
 ,place_of_loading                string      comment'装箱地（城市/港口/机场）,Port/Airport/Place of Loading' 
 ,country_of_destination          string      comment'目的地（国家），Port/Airport/Place of Destination (Country)' 
 ,place_of_destination            string      comment'目的地（城市/港口/机场）,Port/Airport/Place of Destination (Country)' 
 ,vessel_name                     string      comment'船名/航班号/货车名，Vessel Name/Flight/Plate No.'
 ,shipping_company                string      comment'航运公司/航空公司，Shipping Agent/Carrier Name'
 ,remark                          string      comment'备注'
 ,create_by                       string      comment'创建人' 
 ,create_by_name                  string      comment'创建人名字'
 ,create_time                     timestamp   comment'创建时间' 
 ,update_by                       string      comment'更新人'
 ,update_by_name                  string      comment'更新人名字'
 ,update_time                     timestamp   comment'更新时间'
 )
 COMMENT'融资运输单据表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_shipment partition(data_date='${hiveconf:DATA_DATE}')
select 
    id                         
    ,data_source               
    ,financing_invoice_id      
    ,invoice_olea_id           
    ,invoice_no                
    ,incoterms                 
    ,delivery_mode             
    ,shipment_document         
    ,from_unixtime(cast(shipment_date/1000 as bigint),'yyyy-MM-dd')  as   shipment_date         
    ,country_of_loading        
    ,place_of_loading          
    ,country_of_destination    
    ,place_of_destination      
    ,vessel_name               
    ,shipping_company          
    ,remark                    
    ,create_by                 
    ,create_by_name            
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time               
    ,update_by                 
    ,update_by_name            
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time
    ,project_code	
from ods.ods_olea_cust_olea_financing_shipment 
;


















