--alter table dw_uat.dw_olea_pub_olea_email_log 		  		  add columns (bcc_addrs 						string  comment'bcc接收方邮箱地址');


--drop table if exists dw_uat.dw_olea_pub_olea_email_log;
create table if not exists dw_uat.dw_olea_pub_olea_email_log
(`id`                                string               comment '                                                  '
,`serial_no`                         string               comment '流水号                                               '
,`business_key`                      string               comment '业务主键                                              '
,`type`                              string               comment '类型                                                '
,`title`                             string               comment '邮箱标题                                              '
,`to_addrs`                          string               comment '接收方邮箱地址                                           '
,`from_addrs`                        string               comment '发送方邮箱地址                                           '
,`content_param`                     string               comment '内容填充参数                                            '
,`content`                           string               comment '邮箱内容                                              '
,`att_file`                          string               comment '附件文件json                                          '
,`status`                            string               comment '状态                                                '
,`remark`                            string               comment '备注                                                '
,`create_time`                       timestamp            comment '                                                  '
,`create_by`                         string               comment '                                                  '
,`create_by_name`                    string               comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
,`update_by`                         string               comment '                                                  '
,`update_by_name`                    string               comment '                                                  '
) comment '邮箱表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_olea_email_log partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`serial_no`                        
,`business_key`                     
,`type`                             
,`title`                            
,`to_addrs`                         
,`from_addrs`                       
,`content_param`                    
,`content`                          
,`att_file`                         
,`status`                           
,`remark`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        
,`update_by_name`                   
,bcc_addrs
,cc_addrs
,retry_times
from ods.ods_olea_pub_olea_email_log;