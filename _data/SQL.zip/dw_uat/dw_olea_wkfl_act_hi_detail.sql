--drop table if exists dw_uat.dw_olea_wkfl_act_hi_detail;
create table if not exists dw_uat.dw_olea_wkfl_act_hi_detail
(`ID_`                               string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  '
,`EXECUTION_ID_`                     string               comment '                                                  '
,`TASK_ID_`                          string               comment '                                                  '
,`ACT_INST_ID_`                      string               comment '                                                  '
,`NAME_`                             string               comment '                                                  '
,`VAR_TYPE_`                         string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`TIME_`                             timestamp            comment '                                                  '
,`BYTEARRAY_ID_`                     string               comment '                                                  '
,`DOUBLE_`                           string               comment '                                                  '
,`LONG_`                             string               comment '                                                  '
,`TEXT_`                             string               comment '                                                  '
,`TEXT2_`                            string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_hi_detail partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`TYPE_`                            
,`PROC_INST_ID_`                    
,`EXECUTION_ID_`                    
,`TASK_ID_`                         
,`ACT_INST_ID_`                     
,`NAME_`                            
,`VAR_TYPE_`                        
,`REV_`                             
,nvl(from_unixtime(cast(`TIME_`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`TIME_`) as TIME_
,`BYTEARRAY_ID_`                    
,`DOUBLE_`                          
,`LONG_`                            
,`TEXT_`                            
,`TEXT2_`                           

from ods.ods_olea_wkfl_act_hi_detail;