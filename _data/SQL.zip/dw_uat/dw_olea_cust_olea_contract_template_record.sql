--drop table if exists dw_uat.dw_olea_cust_olea_contract_template_record;
create table if not exists dw_uat.dw_olea_cust_olea_contract_template_record
(`id`                                string               comment '   '
,`template_no`                       string               comment 'Contract unique numbe '
,`template_name`                     string               comment 'contract title'
,`platform_template_id`              string               comment 'mid platform contract record id '
,`platform_template_no`              string               comment 'mid platform contract record NO.'
,`platform_external_key`             string               comment 'The unique external identification of mid platform Contract'
,`file_external_key`                 string               comment 'file unique external identifier                                          '
,`agreement_id`                      string               comment 'agreement id                                              '
,`agreement_name`                    string               comment 'agreement name                                              '
,`agreement_type`                    string               comment 'agreement type                                              '
,`remark`                            string               comment 'remark                                                '
,`create_time`                       timestamp            comment '                                                  '
,`create_by`                         string               comment '                                                  '
,`create_by_name`                    string               comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
,`update_by`                         string               comment '                                                  '
,`update_by_name`                    string               comment '                                                  '
) comment 'Contract Template Record Form'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_contract_template_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`template_no`                      
,`template_name`                    
,`platform_template_id`             
,`platform_template_no`             
,`platform_external_key`            
,`file_external_key`                
,`agreement_id`                     
,`agreement_name`                   
,`agreement_type`                   
,`remark`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        
,`update_by_name`                   

from ods.ods_olea_cust_olea_contract_template_record;