--202101新增字段package_type
alter table dw_uat.dw_olea_cust_olea_payment_package add columns(package_type string comment'package_type')
alter table dw_uat.dw_olea_cust_olea_payment_package add columns(total_suspense_amount double comment'total_suspense_amount')

alter table dw_uat.dw_olea_cust_olea_payment_package  add  columns (model_type  		 	string     comment '' );
alter table dw_uat.dw_olea_cust_olea_payment_package  add  columns (credit_available  	  	string     comment '' );
alter table dw_uat.dw_olea_cust_olea_payment_package  add  columns (shortage_excess   	  	string     comment '' );
alter table dw_uat.dw_olea_cust_olea_payment_package  add  columns (total_received_amount  string     comment '' );
alter table dw_uat.dw_olea_cust_olea_payment_package  add  columns (complete_time  		timestamp  comment '' );
--1
