create table if not exists dw_uat.dw_olea_cust_olea_supplier_bank_account
( 	
	 id 				 		   string  	  comment 'primary key id'
	,app_no 					   string     comment 'app no'
	,busi_key 			 	   	   string     comment 'Business primary key, used to upload images'
	,status 			 		   string     comment 'account status'
	,dd_state 			 	   	   string     comment 'Approval Status waiT_SUBMIT:Pending Submission | IN_PROGRESS:Under Review | APPROVED:Approved | REJECTED:Rejected'
	,company_id 		 		   string     comment 'Company table id, you can query company information by associating the id in the table olea_company'
	,participant_id	 		   	   string     comment 'participant id'
	,account_name 		 	   	   string     comment 'account name'
	,currency   		 		   string     comment 'currency: usd'
	,account_no 		 		   string     comment 'account no'
	,bank_swift_code    		   string     comment 'bank swiftcode'
	,bank_address 		 	   	   string     comment 'bank address'
	,bank_name    		 	   	   string     comment 'bank name'
	,bank_branch  		 	   	   string     comment 'bank branch'
	,intermediary_swift_code       string     comment 'intermediary swiftcode'
	,scb_onboard_status 		   string     comment 'account creation status:NA、Pending、Completed'
	,enable 					   string  	  comment 'is effect,y：yes N: no'
	,remark 					   string     comment 'remark'
	,create_by 				   	   string     comment 'creator userid'
	,create_by_name 			   string     comment 'creator'
	,create_time   			   	   timestamp  comment 'create time'
	,update_by 				   	   string  	  comment 'updator userid'
	,update_by_name    		   	   string     comment 'updator name'
	,update_time 			   	   timestamp  comment 'update time'
)
comment 'Supplier bank account table can be used to create supplier bank account information'
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_supplier_bank_account  partition(data_date='${hiveconf:DATA_DATE}')
select 
	  id
	 ,app_no	  
     ,busi_key 			 	
	 ,status 			 	
	 ,dd_state 			 	
	 ,company_id 		 	
	 ,participant_id	 		
     ,account_name 		 	
     ,currency   		 	
     ,account_no 		 	
     ,bank_swift_code    	
     ,bank_address 		 	
     ,bank_name    		 	
     ,bank_branch  		 	
     ,intermediary_swift_code
     ,scb_onboard_status 	
     ,enable 				
     ,remark 				
     ,create_by                          
     ,create_by_name                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                        
     ,update_by                          
     ,update_by_name                     
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time   
     ,ffc_account_name
	   ,ffc_account_no
  from ods.ods_olea_cust_olea_supplier_bank_account
;










