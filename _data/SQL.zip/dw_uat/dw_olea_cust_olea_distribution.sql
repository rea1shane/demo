--alter table dw_uat.dw_olea_cust_olea_distribution   	add columns (buyer_corres_bankfee             double  comment'买方打款给olea时的银行手续费');
--alter table dw_uat.dw_olea_cust_olea_distribution  	add columns (investor_final_invoice_return    double  comment'InvestorInterestAmount');




--alter table dw_uat.dw_olea_cust_olea_distribution 	    add columns(estimated_funding_date timestamp   comment'投资到期日');


--drop table if exists dw_uat.dw_olea_cust_olea_distribution;
create table if not exists dw_uat.dw_olea_cust_olea_distribution
(
   id                           string comment ''                
  ,program_id                   string comment 'program ID'
  ,investor_id                  string comment 'investor ID'
  ,supplier_discount_amt        string comment 'supplier discount amt'
  ,investor_return_rate         string comment 'investor return rate'
  ,investor_return              string comment 'investor return'
  ,frozen_amount                string comment 'frozen amount'
  ,execution_id                 string comment 'execution ID'
  ,financing_id                 string comment 'financing ID'
  ,pair_id                      string comment 'pair ID'
  ,trigger_type                 string comment 'trigger type'
  ,paired_status                string comment 'paired status'
  ,email_status                 string comment 'email status'
  ,trigger_by                   string comment 'trigger by'
  ,paired_on                    string comment 'paired on time'
  ,email_send_time              string comment 'email send time'
  ,consent_status               string comment 'consent status'
  ,consent_on                   string comment 'consent on'
  ,consent_rejected_on          string comment 'consent rejected on'
  ,error_msg                    string comment 'error message'
  ,enable                       string comment ''
  ,create_by                    string comment 'id of the person who created'
  ,update_by                    string comment 'id of the person who updated'
  ,create_by_name               string comment 'name of the person who created'
  ,update_by_name               string comment 'name of the person who updated'
  ,create_time                  string comment ''
  ,update_time                  string comment ''
)partitioned by (data_date string)
stored as parquet;

--alter table dw_uat.dw_olea_cust_olea_distribution  add  columns (investor_yield  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_distribution  add  columns (estimated_tenor  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_distribution  add  columns (estimated_funding_amount  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_distribution  add  columns (infonex_platfee  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_distribution  add  columns (llsi_svcfee  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_distribution  add  columns (supplier_disbursefee  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_distribution  add  columns (esco_annfee_per_inv  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_distribution  change   paired_on   paired_on  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_distribution  change   email_send_time   email_send_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_distribution  change   consent_on   consent_on  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_distribution  change   consent_rejected_on   consent_rejected_on  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_distribution  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_distribution  change   update_time   update_time  timestamp      comment'' ;


insert overwrite table dw_uat.dw_olea_cust_olea_distribution partition(data_date='${hiveconf:DATA_DATE}')
 select 
       id                        
      ,program_id                
      ,investor_id               
      ,supplier_discount_amt     
      ,investor_return_rate      
      ,investor_return           
      ,frozen_amount             
      ,execution_id              
      ,financing_id              
      ,pair_id                   
      ,trigger_type              
      ,paired_status             
      ,email_status              
      ,trigger_by                
      ,from_unixtime(cast(paired_on/1000 as bigint),'yyyy-MM-dd')  as paired_on                 
      ,from_unixtime(cast(email_send_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as email_send_time           
      ,consent_status            
      ,from_unixtime(cast(consent_on/1000 as bigint),'yyyy-MM-dd') as consent_on                
      ,from_unixtime(cast(consent_rejected_on/1000 as bigint),'yyyy-MM-dd')   as consent_rejected_on       
      ,error_msg                 
      ,enable                    
      ,create_by                 
      ,update_by                 
      ,create_by_name            
      ,update_by_name            
	  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time             
      ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
      ,investor_yield
      ,estimated_tenor
      ,estimated_funding_amount
      ,infonex_platfee
      ,llsi_svcfee
      ,supplier_disbursefee
      ,esco_annfee_per_inv	  
	  ,from_unixtime(cast(estimated_funding_date/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as estimated_funding_date 
      ,buyer_corres_bankfee
	  ,investor_final_invoice_return
	  ,supplier_procfee
	  ,net_financing_amount_investor
	  ,net_financing_amount_supplier
	  ,supplier_discamt			
      ,adjusted_advance_ratio    
	  ,estimated_principal_amount
   from ods.ods_olea_cust_olea_distribution
  ;
  























































