--alter table dw_uat.dw_olea_scb_host_accounting_check  add  columns (counterparty_name  string  comment '' );
--alter table dw_uat.dw_olea_scb_host_accounting_check  add  columns (counterparty_type  string  comment '' );


--drop table if exists dw_uat.dw_olea_scb_host_accounting_check;
create table if not exists dw_uat.dw_olea_scb_host_accounting_check
(`id`                                string               comment '                                                  '
,`bank_account`                      string               comment '银行账号                                              '
,`subledger_amount`                  string               comment '科目金额                                              '
,`bank_statement_amount`             string               comment '银行返回金额                                            '
,`difference`                        string               comment '差异                                                '
,`last_difference`                   string               comment '上一次差异                                             '
,`report_time`                       timestamp            comment '报告时间                                              '
,`aging`                             string               comment '天数                                                '
,`status`                            string               comment '状态：Solved/Reopen                                  '
,`remark`                            string               comment '备注                                                '
,`opt_user_id`                       string               comment '操作人id                                             '
,`opt_user_name`                     string               comment '操作人姓名                                             '
,`solved_time`                       timestamp            comment 'solved时间                                          '
,`create_time`                       timestamp            comment '                                                  '
,`update_time`                       timestamp            comment '                                                  '
) comment '对账记录'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_scb_host_accounting_check partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`bank_account`                     
,`subledger_amount`                 
,`bank_statement_amount`            
,`difference`                       
,`last_difference`                  
,nvl(from_unixtime(cast(`report_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`report_time`) as report_time
,`aging`                            
,`status`                           
,`remark`                           
,`opt_user_id`                      
,`opt_user_name`                    
,nvl(from_unixtime(cast(`solved_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`solved_time`) as solved_time
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,counterparty_name
,counterparty_type
,nvl(from_unixtime(cast(`record_date`/1000 as bigint),'yyyy-MM-dd'),`record_date`) as record_date        
,reconcile_amount   
,source_bank_account
,source_name        
from ods.ods_olea_scb_host_accounting_check;