--drop table if exists dw_uat.dw_olea_pub_pub_number_seq;
create table if not exists dw_uat.dw_olea_pub_pub_number_seq
(`id`                                string               comment '                                                  '
,`prefix`                            string               comment '前缀                                                '
,`type`                              string               comment '类型                                                '
,`seq_no`                            string               comment '序号                                                '
,`increment`                         string               comment '增量                                                '
,`digit_count`                       string               comment '序号位数                                              '
,`is_need_date`                      string               comment '是否需要日期                                            '
,`date_format`                       string               comment '日期格式                                              '
,`remark`                            string               comment '备注                                                '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment '编码序号'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_pub_number_seq partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`prefix`                           
,`type`                             
,`seq_no`                           
,`increment`                        
,`digit_count`                      
,`is_need_date`                     
,`date_format`                      
,`remark`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_pub_pub_number_seq;