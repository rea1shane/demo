--drop table if exists dw_uat.dw_olea_wkfl_wkfl_ext_data;
create table if not exists dw_uat.dw_olea_wkfl_wkfl_ext_data
(`app_no`                            string               comment '申请件编号                                             '
,`app_type`                          string               comment '流程类型                                              '
,`business_id`                       string               comment '关键业务id (与流程类型相关)                                  '
,`ext1`                              string               comment '                                                  '
,`ext2`                              string               comment '                                                  '
,`ext3`                              string               comment '                                                  '
,`ext4`                              string               comment '                                                  '
,`ext5`                              string               comment '                                                  '
,`ext6`                              string               comment '                                                  '
,`ext7`                              string               comment '                                                  '
,`ext8`                              string               comment '                                                  '
,`ext9`                              string               comment '                                                  '
,`ext10`                             string               comment '                                                  '
,`ext11`                             string               comment '                                                  '
,`ext12`                             string               comment '                                                  '
,`ext13`                             string               comment '                                                  '
,`ext14`                             string               comment '                                                  '
,`ext15`                             string               comment '                                                  '
,`ext16`                             string               comment '                                                  '
,`ext17`                             string               comment '                                                  '
,`ext18`                             string               comment '                                                  '
,`ext19`                             string               comment '                                                  '
,`ext20`                             string               comment '                                                  '
,`ext21`                             string               comment '                                                  '
,`ext22`                             string               comment '                                                  '
,`ext23`                             string               comment '                                                  '
,`ext24`                             string               comment '                                                  '
,`ext25`                             string               comment '                                                  '
,`ext26`                             string               comment '                                                  '
,`ext27`                             string               comment '                                                  '
,`ext28`                             string               comment '                                                  '
,`ext29`                             string               comment '                                                  '
,`ext30`                             string               comment '                                                  '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '                                                  '
,`create_user`                       string               comment '创建人名称                                             '
,`create_by`                         string               comment '创建人id                                             '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_user`                       string               comment '修改人名称                                             '
,`update_by`                         string               comment '修改人id                                             '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_wkfl_ext_data partition(data_date='${hiveconf:DATA_DATE}')
select
`app_no`                           
,`app_type`                         
,`business_id`                      
,`ext1`                             
,`ext2`                             
,`ext3`                             
,`ext4`                             
,`ext5`                             
,`ext6`                             
,`ext7`                             
,`ext8`                             
,`ext9`                             
,`ext10`                            
,`ext11`                            
,`ext12`                            
,`ext13`                            
,`ext14`                            
,`ext15`                            
,`ext16`                            
,`ext17`                            
,`ext18`                            
,`ext19`                            
,`ext20`                            
,`ext21`                            
,`ext22`                            
,`ext23`                            
,`ext24`                            
,`ext25`                            
,`ext26`                            
,`ext27`                            
,`ext28`                            
,`ext29`                            
,`ext30`                            
,`enable`                           
,`remark`                           
,`create_user`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_user`                      
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_wkfl_wkfl_ext_data;