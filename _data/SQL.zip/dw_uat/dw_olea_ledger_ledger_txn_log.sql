--drop table if exists dw_uat.dw_olea_ledger_ledger_txn_log;
create table if not exists dw_uat.dw_olea_ledger_ledger_txn_log
(`id`                                string               comment '主键id                                              '
,`loan_no`                           string               comment '借据编号                                              '
,`contract_no`                       string               comment '合同号                                               '
,`bill_no`                           string               comment '单据号                                               '
,`txn_id`                            string               comment '交易编号                                              '
,`org_id`                            string               comment '入账机构                                              '
,`bank_code_no`                      string               comment '资金方                                               '
,`body`                              string               comment '发送内容                                              '
,`status`                            string               comment '处理状态（json串）                                       '
,`cust_id`                           string               comment '客户编号                                              '
,`cust_name`                         string               comment '客户名称                                              '
,`cust_type`                         string               comment '客户类型                                              '
,`trans_date`                        timestamp            comment '交易日期                                              '
,`txn_type`                          string               comment '交易类型                                              '
,`enable`                            string               comment '                                                  '
,`remark`                            string               comment '备注                                                '
,`create_by`                         string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人                                               '
,`update_time`                       timestamp            comment '更新时间                                              '
) comment '记录发生交易接口传送信息'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_ledger_ledger_txn_log partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`loan_no`                          
,`contract_no`                      
,`bill_no`                          
,`txn_id`                           
,`org_id`                           
,`bank_code_no`                     
,`body`                             
,`status`                           
,`cust_id`                          
,`cust_name`                        
,`cust_type`                        
,nvl(from_unixtime(cast(`trans_date`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`trans_date`) as trans_date
,`txn_type`                         
,`enable`                           
,`remark`                           
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_ledger_ledger_txn_log;