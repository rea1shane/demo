create external table if not exists dw_uat.dw_olea_cust_olea_standing_instruction_history
(
     id                   bigint   comment 'primary key'
    ,instruction_id       bigint   comment ''
    ,old_instruction_text string   comment 'Standing Instruction '
    ,new_instruction_text string   comment 'Standing Instruction '
    ,old_selected_module  string   comment ''
    ,new_selected_module  string   comment ''
    ,old_valid            string   comment ''
    ,new_valid            string   comment ''
    ,create_by            string   comment ''
    ,create_by_id         bigint   comment ''
    ,create_time          timestamp comment ''
    ,update_by            string    comment ''
    ,update_by_id         bigint    comment ''
    ,update_time          timestamp  comment ''
)partitioned by (data_date string)
stored as parquet
;
insert overwrite table dw_uat.dw_olea_cust_olea_standing_instruction_history  partition(data_date='${hiveconf:DATA_DATE}')
select 
     	id                  
		 ,instruction_id      
		 ,old_instruction_text
		 ,new_instruction_text
		 ,old_selected_module 
		 ,new_selected_module 
		 ,old_valid           
		 ,new_valid           
		 ,create_by           
		 ,create_by_id        
		 ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time         
		 ,update_by           
		 ,update_by_id        
		 ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time
from  ods.ods_olea_cust_olea_standing_instruction_history  
;     