--drop table if exists dw_uat.dw_olea_workorder_feedback_record;
create table if not exists dw_uat.dw_olea_workorder_feedback_record
(`id`                                string               comment '                                                  '
,`order_number`                      string               comment '工单编号                                              '
,`node_name`                         string               comment '节点名称                                              '
,`feedback_type`                     string               comment '反馈类型：1-用户反馈、2-客服岗                                 '
,`problem_description`               string               comment '问题描述                                              '
,`send_mail_status`                  string               comment '发送邮件状态：1-发送成功、2-发送失败                              '
,`time_span`                         string               comment '时效统计                                              '
,`handler_name`                      string               comment '处理人员名称                                            '
,`handler_id`                        string               comment '处理人员ID                                            '
,`start_time`                        timestamp            comment '处理开始时间（提交时间）                                      '
,`end_time`                          timestamp            comment '处理结束时间                                            '
,`reassign_name`                     string               comment '转让业务经理名称                                          '
) comment '反馈记录信息表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_workorder_feedback_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`order_number`                     
,`node_name`                        
,`feedback_type`                    
,`problem_description`              
,`send_mail_status`                 
,`time_span`                        
,`handler_name`                     
,`handler_id`                       
,nvl(from_unixtime(cast(`start_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`start_time`) as start_time
,nvl(from_unixtime(cast(`end_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`end_time`) as end_time
,`reassign_name`                    

from ods.ods_olea_workorder_feedback_record;