CREATE TABLE if not EXISTS dw_uat.dw_olea_cust_olea_buyer_invoices 
(
	 invoice_no 	    string   COMMENT 'Invoice No'
	,invoice_date 	  date     COMMENT 'Invoice date'
	,invoice_status   string   COMMENT 'invoice status'
	,supplier_id 	    int   	 COMMENT 'supplier id'
	,supplier_name    string 	 COMMENT 'supplier name'
	,buyer_id 		    int   	 COMMENT 'buyer id'
	,buyer_name 	    string   COMMENT 'buyer name'
	,invoice_amount   double   COMMENT 'Invoice Amount'
	,currency 		    string   COMMENT 'Currency'
	,invoice_maturity    date  	  COMMENT 'Invoice Maturity date'
	,payment_terms 	     int 	 	  COMMENT 'Payment Term（days）'
	,payment_terms_date  date  	  COMMENT 'payment_terms_date'
	,payment_terms_from  string   COMMENT 'free text，Payment Term（from）'
	,remark 						 string   COMMENT 'remark'
	,create_by 					 int      COMMENT 'creator id'
	,create_by_name 		 string   COMMENT 'creator name'
	,create_time 				 timestamp  COMMENT 'create time'
	,update_by 					 int        COMMENT 'updator id'
	,update_by_name 		 string     COMMENT 'updator name'
	,update_time 				 timestamp  COMMENT 'update time'
)
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_buyer_invoices  partition(data_date='${hiveconf:DATA_DATE}')
select 
     invoice_no 	    
    ,from_unixtime(cast(invoice_date/1000 as bigint),'yyyy-MM-dd') as invoice_date 	    
    ,invoice_status     
    ,supplier_id 	    
    ,supplier_name      
    ,buyer_id 		    
    ,buyer_name 	    
    ,invoice_amount     
    ,currency 		    
    ,from_unixtime(cast(invoice_maturity/1000 as bigint),'yyyy-MM-dd') as invoice_maturity   
    ,payment_terms 	    
    ,from_unixtime(cast(payment_terms_date/1000 as bigint),'yyyy-MM-dd') as payment_terms_date 
    ,payment_terms_from 
    ,remark 			
    ,create_by 			
    ,create_by_name 	
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 		
    ,update_by 			
    ,update_by_name 	
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 
    ,goods_description_category
    ,goods_description	
    ,app_no  --20230215
		,comment
    ,from_unixtime(cast(return_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as return_time
    ,return_by_name
    ,audit_type
    ,company_person_role_option
    ,olea_id
    ,project_code
    ,buyer_program
from ods.ods_olea_cust_olea_buyer_invoices 	
;
