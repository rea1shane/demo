create table if not exists dw_uat.dw_olea_cust_chekk_file_request
(
    id             bigint  comment 'primary key id',
    app_no         string  comment 'process application NO.',
    company_id     bigint  comment 'company id',
    company_name   string  comment 'company name',
    log_ids        string  comment 'olea_pub.pub_invoke_third_log.id',
    chekk_id       bigint  comment 'When the chekk response id is empty, it represents phase 1 (requestFile)',
    aws_file_key   string  comment 'aws file key',
    status         string  comment 'status',
    error_message  string  comment 'error message',
    `timestamp`      TIMESTAMP    comment 'end time',
    manual_result  string       comment 'manual check result',
    manual_time    TIMESTAMP    comment 'manual operator time',
    update_by_name string      comment 'Manual operator name (redundant field will not change)）',
    update_by_id   bigint      comment 'manual operator id',
    `comment`        string      comment 'comment ',
    retry_times    bigint      comment 'retry times',
    create_time    TIMESTAMP   comment 'create time',
    create_by_id   bigint      comment 'creator id'
) comment 'Task to request chekk to get files'
partitioned by(data_date date)  
stored as parquet
;
      
insert overwrite table dw_uat.dw_olea_cust_chekk_file_request  partition(data_date='${hiveconf:DATA_DATE}')   
	 select   
        id            
       ,app_no        
       ,company_id    
       ,company_name  
       ,log_ids       
       ,chekk_id      
       ,aws_file_key  
       ,status        
       ,error_message 
       ,`timestamp`     
       ,manual_result 
       ,nvl(from_unixtime(cast(manual_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),manual_time) as manual_time   
       ,update_by_name
       ,update_by_id  
       ,`comment`       
       ,retry_times   
       ,nvl(from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),create_time) as create_time   
       ,create_by_id 
  from ods.ods_olea_cust_chekk_file_request 
  ;