--drop table if exists dw_uat.dw_olea_cust_olea_bank_account_record;
create table if not exists dw_uat.dw_olea_cust_olea_bank_account_record
(`id`                                string               comment '                                                  '
,`program_id`                        string               comment 'program id      '
,`bank_account_id`                   string               comment 'bank account id   '
,`description`                       string               comment 'Account adjustment description      '
,`manual_flag`                       string               comment 'manual flag   '
,`accounting_type`                   string               comment 'account type      '
,`type`                              string               comment 'operator type      '
,`invoice_no`                        string               comment 'invoice no     '
,`buyer_name`                        string               comment 'buyer name      '
,`supprier_name`                     string               comment 'supprier name     '
,`amount`                            string               comment 'amount      '
,`pre_total_amount`                  string               comment 'Total Amount berfore operator    '
,`post_total_amount`                 string               comment 'Total Amount after operator    '
,`pre_balance`                       string               comment 'pre balance   '
,`post_balance`                      string               comment 'post balance     '
,`currency`                          string               comment 'currency        '
,`delete_flag`                       string               comment 'delete flag      '
,`create_by`                         string               comment 'creator id '
,`create_time`                       timestamp            comment '          '
,`update_by`                         string               comment 'updator id '
,`update_time`                       timestamp            comment '          '
) comment 'Bank Account Operation Record Form'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_bank_account_record partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`program_id`                       
,`bank_account_id`                  
,`description`                      
,`manual_flag`                      
,`accounting_type`                  
,`type`                             
,`invoice_no`                       
,`buyer_name`                       
,`supprier_name`                    
,`amount`                           
,`pre_total_amount`                 
,`post_total_amount`                
,`pre_balance`                      
,`post_balance`                     
,`currency`                         
,`delete_flag`                      
,`create_by`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,package_olea_id        
,data_record_create_type
,nvl(from_unixtime(cast(`posting_date`/1000 as bigint),'yyyy-MM-dd'),`update_time`) as posting_date           
from ods.ods_olea_cust_olea_bank_account_record;