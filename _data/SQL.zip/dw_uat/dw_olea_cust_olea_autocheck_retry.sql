--drop table if exists dw_uat.dw_olea_cust_olea_autocheck_retry;
create table if not exists dw_uat.dw_olea_cust_olea_autocheck_retry
(`id`                                string               comment '   '
,`company_audit_id`                  string               comment 'Enterprise audit id '
,`param`                             string               comment 'request param '
,`interface_type`                    string               comment 'interface type '
,`enable`                            string               comment '  '
,`remark`                            string               comment 'remark '
,`create_time`                       timestamp            comment 'create time'
,`create_by`                         string               comment ' '
,`update_time`                       timestamp            comment 'update time'
,`update_by`                         string               comment ' '
) comment 'Automated Verification Retry Table'
 partitioned by(data_date string)  stored as parquet;
 
insert overwrite table  dw_uat.dw_olea_cust_olea_autocheck_retry partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`company_audit_id`                 
,`param`                            
,`interface_type`                   
,`enable`                           
,`remark`                           
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`create_by`                        
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,`update_by`                        
from ods.ods_olea_cust_olea_autocheck_retry;