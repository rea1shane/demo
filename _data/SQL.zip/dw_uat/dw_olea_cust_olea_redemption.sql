--alter table dw_uat.dw_olea_cust_olea_redemption  add  columns (overdue_interest  string  comment '' );
--alter table dw_uat.dw_olea_cust_olea_redemption  change   redemption_date   redemption_date  date      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_redemption  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_cust_olea_redemption  change   update_time   update_time  timestamp      comment'' ;


--drop table if exists dw_uat.dw_olea_cust_olea_redemption;
create table if not exists dw_uat.dw_olea_cust_olea_redemption
(
    id                               string                comment ''
   ,financing_id                     string                comment 'financing ID'
   ,repayment_id                     string                comment 'repayment ID'
   ,redemption_package_id            string                comment 'redemption package ID'
   ,redemption_status                string                comment 'redemption status'
   ,redemption_date                  string                comment 'redemption date'
   ,actual_received_amount           string                comment 'actual received amount'
   ,funding_amount                   string                comment 'funding amount'
   ,investor_program_id              string                comment 'investor program ID'
   ,investor_program_name            string                comment 'investor program name'
   ,investor_interest_amount         decimal(20,8)         comment 'investor interest amount'
   ,investor_interest_rate           string                comment 'investor interest rate'
   ,redemption_adjustment_amount     decimal(20,8)         comment 'redemption adjustment amount'
   ,estimated_redemption_amount      decimal(20,8)         comment 'estimated redemption amount'
   ,actual_redemption_amount         decimal(20,8)         comment 'actual redemption amount'
   ,residual_redemption_amount       decimal(20,8)         comment 'residual redemption amount'
   ,remark                           string                comment 'remark'
   ,create_by                        string                comment 'id of the person who created'
   ,update_by                        string                comment 'id of the person who updated'
   ,create_time                      string                comment ''
   ,update_time                      string                comment ''
)
partitioned by (data_date string)
stored as parquet;


insert overwrite table dw_uat.dw_olea_cust_olea_redemption partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                           
     ,financing_id                 
     ,repayment_id                 
     ,redemption_package_id        
     ,redemption_status            
     ,from_unixtime(cast(redemption_date/1000 as bigint),'yyyy-MM-dd') as redemption_date              
     ,actual_received_amount       
     ,funding_amount               
     ,investor_program_id          
     ,investor_program_name        
     ,investor_interest_amount     
     ,investor_interest_rate       
     ,redemption_adjustment_amount 
     ,estimated_redemption_amount  
     ,actual_redemption_amount     
     ,residual_redemption_amount   
     ,remark                       
     ,create_by                    
     ,update_by                    
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as  create_time                   
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as  update_time     
	 ,overdue_interest	 
	 ,extension_id
	 ,outstanding_amount
	 ,`type`
	 ,overdue_record_id
	 ,net_settlement_opt   
	 ,net_settlement_enable
	 ,net_settled_amount   
 from ods.ods_olea_cust_olea_redemption
;



