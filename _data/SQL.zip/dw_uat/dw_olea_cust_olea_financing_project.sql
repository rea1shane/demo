create table if not exists dw_uat.dw_olea_cust_olea_financing_project
( 
     id                         string    			    	 comment '唯一主键，自增雪花id'
    ,financing_id               string                       comment '关联financing表ID 与financing记录一同创建，不再变更'
    ,project_code               string                       comment '平台唯一code编号，project code码'
    ,project_name               string                       comment 'Project Name'
    ,platform_name              string                       comment 'Platform Name'
    ,primary_relationship       string                       comment 'Primary Relationship'
    ,payee_type                 string                       comment '付款方式（Payee Type）'
    ,payer_type                 string                       comment '还款方式（Payer Type）'
    ,status                     string                       comment '状态'
    ,trade_validation_level     string                       comment 'Trade Validation Level'
    ,trade_validation_outsource string                       comment 'Trade Validation Outsource'
    ,fr_template                string                       comment 'FR Template'
    ,maturity_date              string                       comment 'Maturity Date'
    ,financing_start_date       string                       comment 'Financing Start Date'
    ,tiered_interest_rate       string                       comment 'Tiered interest rate'
    ,onboarding_process         string                       comment 'Onboarding Process'
    ,sc_portal_access           string                       comment 'SC Portal Access'
    ,sc_portal_f_r              string                       comment 'SC Portal (FR)'
    ,extension_applicability    string                       comment 'Extension Applicability'
    ,invoice_amount_min         double                       comment 'Min.Invoice Amount'
    ,fr_amount_min              double                       comment 'Min.FR Amount'
    ,tenor_min                  int                          comment 'Min.Tenor'
    ,tenor_max                  int                          comment 'Max.Tenor'
    ,create_by                  string                       comment '创建人userId'
    ,create_by_name             string                       comment '创建人'
    ,create_time                timestamp    				 comment '创建时间'
    ,update_by                  string                       comment '更新人userId'
    ,update_by_name             string                       comment '更新人'
    ,update_time                timestamp    				 comment '修改时间'
    ,platform_config_id         string                       comment '平台基础配置id（已废弃）'
    ,account_name               string                       comment '账户名（已废弃）'
    ,bank_address               string                       comment '银行地址（已废弃）'
    ,bank_branch                string                       comment '银行分支行（已废弃）'
    ,bank_name                  string                       comment '银行名称（已废弃）'
    ,swift_code                 string                       comment 'Swift code（已废弃）'
    ,account_no                 string                       comment '账号名（已废弃）'
    ,account_currency           string                       comment '账户币种（已废弃）'
 )
 COMMENT'financing配置表'
partitioned by (data_date string)                   
stored as parquet
;

insert overwrite table dw_uat.dw_olea_cust_olea_financing_project partition(data_date='${hiveconf:DATA_DATE}')
select 
  id                        
  ,financing_id              
  ,project_code              
  ,project_name              
  ,platform_name             
  ,primary_relationship      
  ,payee_type                
  ,payer_type                
  ,status                    
  ,trade_validation_level    
  ,trade_validation_outsource
  ,fr_template               
  ,maturity_date             
  ,financing_start_date      
  ,tiered_interest_rate      
  ,onboarding_process        
  ,sc_portal_access          
  ,sc_portal_f_r             
  ,extension_applicability   
  ,invoice_amount_min        
  ,fr_amount_min             
  ,tenor_min                 
  ,tenor_max                 
  ,create_by                 
  ,create_by_name            
  ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time               
  ,update_by                 
  ,update_by_name            
  ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time               
  ,platform_config_id        
  ,account_name              
  ,bank_address              
  ,bank_branch               
  ,bank_name                 
  ,swift_code                
  ,account_no                
  ,account_currency          
from ods.ods_olea_cust_olea_financing_project a 
;













