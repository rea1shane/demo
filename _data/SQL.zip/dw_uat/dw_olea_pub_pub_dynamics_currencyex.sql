--drop table if exists dw_uat.dw_olea_pub_pub_dynamics_currencyex;
create table if not exists dw_uat.dw_olea_pub_pub_dynamics_currencyex
(`id`                                string               comment '                                                  '
,`currency_code`                     string               comment '币种                                                '
,`rel_currency_code`                 string               comment '关联币种                                              '
,`exchange_rate_amount`              string               comment '币种兑换比                                             '
,`start_time`                        timestamp            comment '开始时间                                              '
,`status`                            string               comment '状态                                                '
,`error_msg`                         string               comment '同步到dynamics错误信息                                   '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_time`                       timestamp            comment '修改时间                                              '
) comment 'dynamics 币种转换率同步表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_pub_pub_dynamics_currencyex partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`currency_code`                    
,`rel_currency_code`                
,`exchange_rate_amount`             
,nvl(from_unixtime(cast(`start_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`start_time`) as start_time
,`status`                           
,`error_msg`                        
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time

from ods.ods_olea_pub_pub_dynamics_currencyex;