
create table if not exists  dw_uat.dw_olea_sys_center_sys_user_terms_conditions_sign_record 
 (
   id  				     bigint    COMMENT 'primary key id',
   company_id       bigint    COMMENT 'company id',
   user_name        string    COMMENT 'user name',
   ip_address        string    COMMENT 'ip address',
   sign_time          timestamp  COMMENT 'sign time',
   remark  		     string    COMMENT 'remark',
   create_by          bigint   COMMENT 'creator id',
   create_by_name  string    COMMENT 'creator name',
   create_time  	 	  timestamp  COMMENT 'create time',
   update_by  		  bigint    COMMENT 'updator id',
   update_by_name  string    COMMENT 'updator name',
   update_time  	 	timestamp  COMMENT 'update time'
 )comment 'User Terms Signing Record Form'
partitioned by(data_date date)  
stored as parquet
;


insert overwrite table dw_uat.dw_olea_sys_center_sys_user_terms_conditions_sign_record partition(data_date='${hiveconf:DATA_DATE}')
  select 
       id  				    
      ,company_id      
      ,user_name       
      ,ip_address      
      ,nvl(from_unixtime(cast(sign_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),sign_time) as sign_time       
      ,remark  		    
      ,create_by       
      ,create_by_name  
      ,nvl(from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),create_time) as create_time  	  
      ,update_by  		  
      ,update_by_name  
      ,nvl(from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),update_time) as update_time  	  
  from ods.ods_olea_sys_center_sys_user_terms_conditions_sign_record
  ;