--drop table if exists dw_uat.dw_olea_wkfl_act_hi_identitylink;
create table if not exists dw_uat.dw_olea_wkfl_act_hi_identitylink
(`ID_`                               string               comment '                                                  '
,`GROUP_ID_`                         string               comment '                                                  '
,`TYPE_`                             string               comment '                                                  '
,`USER_ID_`                          string               comment '                                                  '
,`TASK_ID_`                          string               comment '                                                  '
,`PROC_INST_ID_`                     string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_hi_identitylink partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`GROUP_ID_`                        
,`TYPE_`                            
,`USER_ID_`                         
,`TASK_ID_`                         
,`PROC_INST_ID_`                    

from ods.ods_olea_wkfl_act_hi_identitylink;