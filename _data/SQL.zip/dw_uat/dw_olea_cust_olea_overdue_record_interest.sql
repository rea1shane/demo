create table if not exists dw_uat.dw_olea_cust_olea_overdue_record_interest
( 
     id                    string             
    ,financing_id          string                   comment 'olea_financing表id'
    ,repayment_id          string                   comment 'olea_repayment表id'
    ,overdue_record_id     string                   comment 'olea_overdue_record表id'
    ,currency              string                   comment '币种'
    ,year_size             int                      comment '一年的天数'
    ,principal_amount      double                   comment 'repayment本次还款金额'
    ,date_start            date                     comment '起始时间'
    ,date_end              date                     comment '结束时间'
    ,date_period           int                      comment '间隔天数'
    ,rate_date_start       date                     comment '浮动计算开始时间'
    ,rate_date_end         date                     comment '浮动计算结束时间'
    ,nominal_rate_type     string                   comment '浮动类型'
    ,risk_free_rate_option string                   comment '最低风险利率选项：TermsSofa'
    ,rate_float            double                   comment '浮动利率 当rate_type为浮动类型时才有值'
    ,rate                  double                   comment '利率'
    ,interest              double                   comment '利息'
    ,create_by             string                   comment '创建人id'
    ,create_by_name        string                   comment '创建人名称'
    ,create_time           timestamp 				comment '创建时间'
    ,update_by             string                   comment '修改人id'
    ,update_by_name        string                   comment '修改人名称'
    ,update_time           timestamp 				comment '修改时间'

)
comment '逾期利息详情'
partitioned by (data_date string)
stored as parquet
;


insert overwrite table dw_uat.dw_olea_cust_olea_overdue_record_interest  partition(data_date='${hiveconf:DATA_DATE}')
select 
      id                   
     ,financing_id         
     ,repayment_id         
     ,overdue_record_id    
     ,currency             
     ,year_size            
     ,principal_amount     
     ,from_unixtime(cast(date_start/1000 as bigint),'yyyy-MM-dd')        as date_start           
     ,from_unixtime(cast(date_end /1000  as bigint),'yyyy-MM-dd')        as date_end             
     ,date_period                
     ,from_unixtime(cast(rate_date_start/1000 as bigint),'yyyy-MM-dd')   as rate_date_start      
     ,from_unixtime(cast(rate_date_end  /1000 as bigint),'yyyy-MM-dd')   as rate_date_end        
     ,nominal_rate_type    
     ,risk_free_rate_option
     ,rate_float           
     ,rate                 
     ,interest                  
     ,create_by                          
     ,create_by_name                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                        
     ,update_by                          
     ,update_by_name                     
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time  
	 ,parent_id
	 ,sort     
  from ods.ods_olea_cust_olea_overdue_record_interest
;




