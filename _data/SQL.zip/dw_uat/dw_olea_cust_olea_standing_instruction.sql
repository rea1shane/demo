-- 现行指令主表
create external table if not exists dw_uat.dw_olea_cust_olea_standing_instruction
(
    id               bigint  comment 'primary key'
   ,company_id       bigint  comment 'company_id'
   ,instruction_text string  comment 'Standing Instruction content'
   ,selected_module  string  comment ''
   ,is_valid         string  comment ''
   ,create_by        string  comment ''
   ,create_by_id     bigint     comment ''
   ,create_time      timestamp  comment ''
   ,update_by        string     comment ''
   ,update_by_id     bigint     comment ''
   ,update_time      timestamp  comment ''
)partitioned by (data_date string)
stored as parquet
;
insert overwrite table dw_uat.dw_olea_cust_olea_standing_instruction  partition(data_date='${hiveconf:DATA_DATE}')
select
     id 
    ,company_id     
		,instruction_text
		,selected_module
		,is_valid       
		,create_by      
		,create_by_id   
		,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time    
		,update_by      
		,update_by_id   
		,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time  
from  ods.ods_olea_cust_olea_standing_instruction 
;
