--alter table dw_uat.dw_olea_cust_olea_tpp_client_mapping  add  columns (status  string  comment '' );

--drop table if exists dw_uat.dw_olea_cust_olea_tpp_client_mapping;
create table if not exists dw_uat.dw_olea_cust_olea_tpp_client_mapping
(`id`                                string               comment '                                                  '
,`tpp_name`                          string               comment 'TPP Name                                          '
,`type`                              string               comment 'client type                                       '
,`tpp_client_name`                   string               comment 'TPP Client Name                                   '
,`tpp_client_id`                     string               comment 'TPP Client ID                                     '
,`olea_id`                           string               comment 'Olea ID                                           '
,`olea_company_id`                   string               comment 'Olea Company Id                                   '
,`remark`                            string               comment '备注                                                '
,`enable`                            string               comment '是否已被关联                                            '
,`create_by`                         string               comment '创建人userId                                         '
,`create_by_name`                    string               comment '创建人                                               '
,`create_time`                       timestamp            comment '创建时间                                              '
,`update_by`                         string               comment '更新人userId                                         '
,`update_by_name`                    string               comment '更新人                                               '
,`update_time`                       timestamp            comment '最后更新时间                                            '
) comment 'TPP Client Mapping管理'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_cust_olea_tpp_client_mapping partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`tpp_name`                         
,`type`                             
,`tpp_client_name`                  
,`tpp_client_id`                    
,`olea_id`                          
,`olea_company_id`                  
,`remark`                           
,`enable`                           
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,status
from ods.ods_olea_cust_olea_tpp_client_mapping;