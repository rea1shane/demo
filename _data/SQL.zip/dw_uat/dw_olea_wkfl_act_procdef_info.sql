--drop table if exists dw_uat.dw_olea_wkfl_act_procdef_info;
create table if not exists dw_uat.dw_olea_wkfl_act_procdef_info
(`ID_`                               string               comment '                                                  '
,`PROC_DEF_ID_`                      string               comment '                                                  '
,`REV_`                              string               comment '                                                  '
,`INFO_JSON_ID_`                     string               comment '                                                  ') comment ''
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_wkfl_act_procdef_info partition(data_date='${hiveconf:DATA_DATE}')
select
`ID_`                              
,`PROC_DEF_ID_`                     
,`REV_`                             
,`INFO_JSON_ID_`                    

from ods.ods_olea_wkfl_act_procdef_info;