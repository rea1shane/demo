--drop table if exists dw_uat.dw_olea_data_ansi_invoice_program;


create table if not exists dw_uat.dw_olea_data_ansi_invoice_program
(
 index_key              									  string comment ''
,invoice_no             									  string comment 'Invoice no'
,investor_program_id    									  string comment 'Program name'
,selection              									  string comment 'Binary outcome for Program '
,pair_runtime    											  string comment 'run time of the pairing'
,create_time                                                  string comment ''
,update_time                                                  string comment ''
)partitioned by(data_date string) 
stored as parquet
;

--alter table dw_uat.dw_olea_data_ansi_invoice_program  change  index_key     id  string  comment '' ;
--alter table dw_uat.dw_olea_data_ansi_invoice_program  change   pair_runtime   pair_runtime timestamp      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_invoice_program  change   create_time   create_time timestamp      comment'' ;
--alter table dw_uat.dw_olea_data_ansi_invoice_program  change   update_time   update_time  timestamp      comment'' ;



insert overwrite table dw_uat.dw_olea_data_ansi_invoice_program partition(data_date='${hiveconf:DATA_DATE}') 
select 
        id
	   ,invoice_no             	
       ,investor_program_id    	
       ,selection              	
	   ,from_unixtime(cast(pair_runtime/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as pair_runtime
	   ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')   as create_time
	   ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')   as update_time	  							              	     
  from ods.ods_olea_data_ansi_invoice_program
;





