--drop table if exists dw_uat.dw_olea_workorder_work_order_file_info;
create table if not exists dw_uat.dw_olea_workorder_work_order_file_info
(`id`                                string               comment '                                                  '
,`order_number`                      string               comment '工单编号                                              '
,`feedback_record_id`                string               comment '反馈记录信息表id                                         '
,`file_key`                          string               comment 'aws文件服务key                                        '
,`file_name`                         string               comment '文件url                                             '
,`local_url`                         string               comment '本地url                                             '
,`upload_state`                      string               comment '文件是否上传成功：1-保存本地成功、2-上传aws成功、3-失败                  '
,`file_type`                         string               comment '文件类型                                              '
) comment '工单文件信息表'
 partitioned by(data_date string)  stored as parquet;
insert overwrite table  dw_uat.dw_olea_workorder_work_order_file_info partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`order_number`                     
,`feedback_record_id`               
,`file_key`                         
,`file_name`                        
,`local_url`                        
,`upload_state`                     
,`file_type`                        

from ods.ods_olea_workorder_work_order_file_info;