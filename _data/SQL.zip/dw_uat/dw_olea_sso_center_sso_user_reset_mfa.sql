create table if not exists dw_uat.dw_olea_sso_center_sso_user_reset_mfa
(
  `id` 			       string     COMMENT ''  
  ,`token` 		       string     COMMENT 'token'
  ,`login_name`        string     COMMENT 'login_name'
  ,`sys_channel`       string     COMMENT 'sys_channel'
  ,`status` 		   string     COMMENT 'status'
  ,`expire_time`       timestamp  COMMENT 'expire_time'
  ,`today_reset_times` int        COMMENT 'today reset times'
  ,`create_by` 		   int        COMMENT 'create by'
  ,`create_time` 	   timestamp  COMMENT 'create time'
  ,`update_by` 		   int        COMMENT 'update by'
  ,`update_time` 	   timestamp  COMMENT 'update time'
)partitioned by (data_date date)
stored as parquet;

insert overwrite table dw_uat.dw_olea_sso_center_sso_user_reset_mfa partition(data_date='${hiveconf:DATA_DATE}')
  select 
	   `id` 			      
	   ,`token` 		      
	   ,`login_name`       
	   ,`sys_channel`      
	   ,`status` 		  
	   ,from_unixtime(cast(expire_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as expire_time      
	   ,`today_reset_times`
	   ,`create_by` 		  
	   ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time   	  
	   ,`update_by` 		    
	   ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 	        
     from ods.ods_olea_sso_center_sso_user_reset_mfa
   ;

