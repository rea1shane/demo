--alter table dw_uat.dw_olea_cust_olea_account_internal_transfer add columns (`type` 							string  comment'internal transfer type');


--alter table dw_uat.dw_olea_cust_olea_account_internal_transfer add columns(olea_id string	   comment'olea_id');
--alter table dw_uat.dw_olea_cust_olea_account_internal_transfer add columns(export_status string comment'导出状态');


create table if not exists dw_uat.dw_olea_cust_olea_account_internal_transfer
 (
   id 										string			        
  ,from_subject 					string       comment 'from subject name'
  ,from_subject_id 				string       comment 'from subject id'
  ,to_subject 				    string       comment 'to subject'                 
  ,to_subject_id 			    string       comment 'to subject id'              
  ,debit 					    	  string       comment 'debit'                      
  ,debit_id 				      string       comment 'debit id'                   
  ,credit 					      string       comment 'credit'                     
  ,credit_id 				      string       comment 'credit id'                  
  ,generated_amount		    		string       comment 'generated amount'           
  ,manual_overwrite_amount 		string       comment 'manual overwrite amount'    
  ,amount 		 						string       comment 'The actual amount'                     
  ,process_step 					string       comment 'process step'               
  ,submitted_by_id   			string       comment 'submitted by id'            
  ,submitted_by_name 		  string       comment 'submitted by name'          
  ,submitted_time 				string       comment 'submitted time'             
  ,create_by   			    	string       comment 'creator id'                  
  ,update_by   			    	string       comment 'modifier id'                  
  ,create_time 			    	timestamp    comment 'create time'                    
  ,update_time 			    	timestamp    comment 'update time'                    
) 
COMMENT'Internal Transfer Record Form'
partitioned by (data_date string)                   
stored as parquet
;


insert overwrite table dw_uat.dw_olea_cust_olea_account_internal_transfer partition(data_date='${hiveconf:DATA_DATE}')
select 
	 id 						
    ,from_subject 			
    ,from_subject_id 			
    ,to_subject 				
    ,to_subject_id 			
    ,debit 					
    ,debit_id 				
    ,credit 					
    ,credit_id 				
    ,generated_amount		    
    ,manual_overwrite_amount 	
    ,amount 		 			
    ,process_step 			
    ,submitted_by_id   		
    ,submitted_by_name 		
    ,submitted_time 			
    ,create_by   			    
    ,update_by   			    
    ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as create_time 			    
    ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss') as update_time 	
    ,olea_id
	,export_status
	,`type`
	,currency
from ods.ods_olea_cust_olea_account_internal_transfer
;