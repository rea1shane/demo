create table if not exists dw_qa.dw_olea_cust_olea_supplier_bank_account
( 	
	 id 				 		   string  	  comment '唯一主键，自增雪花id'
	,app_no 					   string     comment '流程编号'
	,busi_key 			 	   	   string     comment '业务主键，用于上传影像'
	,status 			 		   string     comment '账户状态'
	,dd_state 			 	   	   string     comment '审核状态waiT_SUBMIT:Pending Submission | IN_PROGRESS:Under Review | APPROVED:Approved | REJECTED:Rejected'
	,company_id 		 		   string     comment '公司表id, 可关联表olea_company中的id查询公司信息'
	,participant_id	 		   	   string     comment '参与者id'
	,account_name 		 	   	   string     comment '账户名称'
	,currency   		 		   string     comment '币种: usd'
	,account_no 		 		   string     comment '银行账号'
	,bank_swift_code    		   string     comment '银行swiftcode'
	,bank_address 		 	   	   string     comment '银行地址'
	,bank_name    		 	   	   string     comment '银行名称'
	,bank_branch  		 	   	   string     comment 'bank branch'
	,intermediary_swift_code       string     comment '中间人swiftcode'
	,scb_onboard_status 		   string     comment 'account建档状态:NA、Pending、Completed'
	,enable 					   string  	  comment '是否生效,y：生效 N: 不生效'
	,remark 					   string     comment '备注'
	,create_by 				   	   string     comment '创建人userid'
	,create_by_name 			   string     comment '创建人'
	,create_time   			   	   timestamp  comment '创建时间'
	,update_by 				   	   string  	  comment '更新人userid'
	,update_by_name    		   	   string     comment '更新人'
	,update_time 			   	   timestamp  comment '更新时间'
)
comment '供应商银行账户表可用于创建供应商银行账户信息'
partitioned by (data_date date)
stored as parquet
;

insert overwrite table dw_qa.dw_olea_cust_olea_supplier_bank_account  partition(data_date='${hiveconf:DATA_DATE}')
select 
	  id
	 ,app_no	  
     ,busi_key 			 	
	 ,status 			 	
	 ,dd_state 			 	
	 ,company_id 		 	
	 ,participant_id	 		
     ,account_name 		 	
     ,currency   		 	
     ,account_no 		 	
     ,bank_swift_code    	
     ,bank_address 		 	
     ,bank_name    		 	
     ,bank_branch  		 	
     ,intermediary_swift_code
     ,scb_onboard_status 	
     ,enable 				
     ,remark 				
     ,create_by                          
     ,create_by_name                     
     ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time                        
     ,update_by                          
     ,update_by_name                     
     ,from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as update_time   
     ,ffc_account_name
	   ,ffc_account_no
  from ods.ods_olea_cust_olea_supplier_bank_account
;










