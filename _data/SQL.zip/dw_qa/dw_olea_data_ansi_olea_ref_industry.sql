
create external table dw_qa.dw_olea_data_ansi_olea_ref_industry
(
    `id`                                bigint     COMMENT 'primary key id'
    ,`industry_level1_id`               string     COMMENT 'Industry_Level1_id'
    ,`industry_level1_name`             string     COMMENT 'Industry_Level1_name'
    ,`industry_level2_id`               string     COMMENT 'Industry_Level2_id'
    ,`industry_level2_name`             string     COMMENT 'Industry_Level2_name'
    ,`industry_level3_id`               string     COMMENT 'Industry_Level3_id'
    ,`industry_level3_name`             string     COMMENT 'Industry_Level3_name'
    ,`nace_equivalent`                  string     COMMENT 'nace_equivalent'
    ,`prohibited`                       string     COMMENT 'prohibited'
    ,`update_date`                      date       COMMENT 'update_date'
    ,`create_by`                        bigint     COMMENT 'creator id'
    ,`create_time`                      timpstamp  COMMENT 'create time'
)COMMENT '行业信息表'
partitioned by (data_date date) 
stored  as parquet
;

insert overwrite table dw_qa.dw_olea_data_ansi_olea_ref_industry partition(data_date='${hiveconf:DATA_DATE}')
  select 
         `id`                         
         ,`industry_level1_id`        
         ,`industry_level1_name`      
         ,`industry_level2_id`        
         ,`industry_level2_name`      
         ,`industry_level3_id`        
         ,`industry_level3_name`      
         ,`nace_equivalent`           
         ,`prohibited`                
         ,from_unixtime(cast(update_date/1000 as bigint),'yyyy-MM-dd') as update_date               
         ,`create_by`                 
         ,from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as create_time              
    from ods.ods_olea_data_ansi_olea_ref_industry
    ;