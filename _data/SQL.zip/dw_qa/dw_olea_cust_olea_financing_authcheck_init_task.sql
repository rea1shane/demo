CREATE external TABLE if not exists dw_qa.dw_olea_cust_olea_financing_authcheck_init_task
 (
	`id` 					   BIGINT    COMMENT 'primary key',
	`project_code`   string    COMMENT 'project code',
	`financing_id`   BIGINT    COMMENT '',
	`status`         string    COMMENT 'status:（0 undo，1 done）',
	`create_by`      bigint    COMMENT 'creator id',
	`create_by_name` string    COMMENT 'creator name',
	`create_time`    timestamp  COMMENT 'create time',
	`update_by` 		 bigint     COMMENT 'updator id',
	`update_by_name` string     COMMENT 'updator name',
	`update_time` 	 timestamp  COMMENT 'update time'
)
partitioned by(data_date string) 
stored as parquet
;

insert overwrite table  dw_qa.dw_olea_cust_olea_bank_account_audit partition(data_date='${hiveconf:DATA_DATE}')
select 
    `id` 					  
	 ,`project_code`  
	 ,`financing_id`  
	 ,`status`        
	 ,`create_by`     
	 ,`create_by_name`
	 ,from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as `create_time`   
	 ,`update_by` 		
	 ,`update_by_name`
	 ,from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss')  as `update_time` 	
from ods.ods_olea_cust_olea_bank_account_audit
;
                
