--alter table dw_qa.dw_olea_cust_olea_bank_account_audit add columns(participant_id     string comment'参与者Id');


--drop table if exists dw_qa.dw_olea_cust_olea_bank_account_audit;
create table if not exists dw_qa.dw_olea_cust_olea_bank_account_audit
(`id`                                string               comment '    '
,`company_id`                        string               comment 'company id '
,`account_id`                        string               comment 'account master table id '
,`audit_id`                          string               comment 'company_audit.id '
,`app_no`                            string               comment 'process application NO. '
,`program_id`                        string               comment 'program id'
,`dd_state`                          string               comment 'approval status'
,`bank_type`                         string               comment 'account type such as supplier or inverstor'
,`account_name`                      string               comment 'account_name'
,`account_currency`                  string               comment 'account currency'
,`account_no`                        string               comment 'account_no'
,`bank_swift_code`                   string               comment 'bank swift code'
,`bank_address`                      string               comment 'bank address '
,`bank_name`                         string               comment 'bank name '
,`intermediary_swift_code`           string               comment 'intermediary swiftcode '
,`transfer_amount`                   string               comment 'transfer amount '
,`withdraw_amount`                   string               comment 'withdraw amount '
,`total_balance`                     string               comment 'total balance  '
,`funded_amount`                     string               comment 'funded amount '
,`frozen_amount`                     string               comment 'frozen amount '
,`available_balance`                 string               comment 'available balance '
,`bank_branch`                       string               comment 'bank branch  '
,`enable`                            string               comment 'Is it in effect'
,`create_by`                         string               comment 'creator '
,`create_by_name`                    string               comment '  '
,`create_time`                       timestamp            comment '  '
,`update_by`                         string               comment 'updator id '
,`update_by_name`                    string               comment ' '
,`update_time`                       timestamp            comment '  '
) comment 'bank account record'
partitioned by(data_date string) 
stored as parquet
;
 
insert overwrite table  dw_qa.dw_olea_cust_olea_bank_account_audit partition(data_date='${hiveconf:DATA_DATE}')
select
`id`                               
,`company_id`                       
,`account_id`                       
,`audit_id`                         
,`app_no`                           
,`program_id`                       
,`dd_state`                         
,`bank_type`                        
,`account_name`                     
,`account_currency`                 
,`account_no`                       
,`bank_swift_code`                  
,`bank_address`                     
,`bank_name`                        
,`intermediary_swift_code`          
,`transfer_amount`                  
,`withdraw_amount`                  
,`total_balance`                    
,`funded_amount`                    
,`frozen_amount`                    
,`available_balance`                
,`bank_branch`                      
,`enable`                           
,`create_by`                        
,`create_by_name`                   
,nvl(from_unixtime(cast(`create_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`create_time`) as create_time
,`update_by`                        
,`update_by_name`                   
,nvl(from_unixtime(cast(`update_time`/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),`update_time`) as update_time
,participant_id    
,remark
,ffc_account_name
,ffc_account_no
from ods.ods_olea_cust_olea_bank_account_audit;