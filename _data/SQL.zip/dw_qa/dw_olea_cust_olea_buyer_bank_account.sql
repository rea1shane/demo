create table if not exists  dw_qa.dw_olea_cust_olea_buyer_bank_account
 (
	 id  					 		bigint      COMMENT 'primary key id',
	 app_no  					string      COMMENT 'process application no',
	 busi_key  				string      COMMENT 'Business primary key, used to upload images',
	 status  					string      COMMENT 'account status',
	 dd_state  				string      COMMENT 'Approval Status:WAIT_SUBMIT:Pending Submission | IN_PROGRESS:Under Review | APPROVED:Approved | REJECTED:Rejected',
	 company_id  			bigint      COMMENT 'company id',
	 company_type     string      COMMENT 'company type GROUP/Group、ENTITY/Entity',
	 participant_id   string      COMMENT 'participant id',
	 account_name  	  string      COMMENT 'account name',
	 currency  			  string      COMMENT 'currency: USD',
	 account_no  		  string      COMMENT 'account no',
	 bank_swift_code  string      COMMENT 'bank swiftCode',
	 bank_address  		string      COMMENT 'bank address',
	 bank_name  			string      COMMENT 'bank name',
	 bank_branch  		string      COMMENT 'bank branch',
	 intermediary_swift_code  string      COMMENT 'middleman swiftcode',
	 default_account  				string      COMMENT 'Whether it is the buyer`s default account',
	 enable  									string      COMMENT 'Is it effective, Y: effective N: not effective',
	 remark  									string      COMMENT 'remark',
	 create_by  							bigint      COMMENT 'creator id',
	 create_by_name  					string      COMMENT 'creator name',
	 create_time  						TIMESTAMP   COMMENT 'create time',
	 update_by  							bigint      COMMENT 'updator id',
	 update_by_name  					string      COMMENT 'updator name',
	 update_time  						TIMESTAMP   COMMENT 'update time'
)COMMENT 'Buyer Bank Account Form: Can be used to create buyer bank account information'
partitioned by(data_date date)  
stored as parquet;
;

insert overwrite table dw_qa.dw_olea_cust_olea_buyer_bank_account partition(data_date='${hiveconf:DATA_DATE}')
select 
    id  					 		
	 ,app_no  					
	 ,busi_key  				
	 ,status  					
	 ,dd_state  				
	 ,company_id  			
	 ,company_type     
	 ,participant_id   
	 ,account_name  	  
	 ,currency  			  
	 ,account_no  		  
	 ,bank_swift_code  
	 ,bank_address  		
	 ,bank_name  			
	 ,bank_branch  		
	 ,intermediary_swift_code  
	 ,default_account  				
	 ,enable  									
	 ,remark  									
	 ,create_by  							
	 ,create_by_name  					
	 ,nvl(from_unixtime(cast(create_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),create_time) as create_time  						
	 ,update_by  							
	 ,update_by_name  					
	 ,nvl(from_unixtime(cast(update_time/1000 as bigint),'yyyy-MM-dd HH:mm:ss'),update_time) as update_time 
	 ,ffc_account_name
	 ,ffc_account_no
from ods.ods_olea_cust_olea_buyer_bank_account	
;			