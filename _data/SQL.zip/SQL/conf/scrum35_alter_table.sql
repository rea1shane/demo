alter table dw_qa.dw_olea_cust_olea_company add columns (`country_of_incorporation` string COMMENT 'Country of Incorporation' );

alter table dw_qa.dw_olea_cust_olea_company_audit  add columns( `country_of_incorporation` string COMMENT 'Country of Incorporation' );

alter table dw_qa.dw_olea_cust_olea_supplier_bank_account  add columns (`ffc_account_name` string COMMENT 'FFC Account Name' );
alter table dw_qa.dw_olea_cust_olea_supplier_bank_account  add columns (`ffc_account_no`   string COMMENT 'FFC Account No' ) ;

alter table dw_qa.dw_olea_cust_olea_supplier_bank_account_audit add columns (`ffc_account_name` string  COMMENT 'FFC Account Name' );
alter table dw_qa.dw_olea_cust_olea_supplier_bank_account_audit add columns (`ffc_account_no` string    COMMENT 'FFC Account No' );

alter table dw_qa.dw_olea_cust_olea_bank_account add columns (`ffc_account_name` string COMMENT 'FFC Account Name' );
alter table dw_qa.dw_olea_cust_olea_bank_account add columns (`ffc_account_no`   string COMMENT 'FFC Account No' );

alter table dw_qa.dw_olea_cust_olea_bank_account_audit add columns (`ffc_account_name` string  COMMENT 'FFC Account Name' );
alter table dw_qa.dw_olea_cust_olea_bank_account_audit add columns (`ffc_account_no` string   COMMENT 'FFC Account No' );

alter table dw_qa.dw_olea_cust_olea_buyer_bank_account add columns (`ffc_account_name` string COMMENT 'FFC Account Name' );
alter table dw_qa.dw_olea_cust_olea_buyer_bank_account add columns (`ffc_account_no`   string COMMENT 'FFC Account No' );

alter table dw_qa.dw_olea_cust_olea_buyer_bank_account_audit add columns (`ffc_account_name` string COMMENT 'FFC Account Name' );
alter table dw_qa.dw_olea_cust_olea_buyer_bank_account_audit add columns (`ffc_account_no` string   COMMENT 'FFC Account No' );

alter table dw_qa.dw_olea_cust_olea_financing_bank_account add columns ( `ffc_account_name` string COMMENT 'FFC Account Name' );
alter table dw_qa.dw_olea_cust_olea_financing_bank_account add columns (`ffc_account_no` string  COMMENT 'FFC Account No' );